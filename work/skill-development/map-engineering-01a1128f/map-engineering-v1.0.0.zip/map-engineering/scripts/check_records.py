"""Check exported audit records, not GIS geometry, source truth or actual acceptance.

Python 3.10+ standard library only. See references/records-tool.md for the contract.
All project locators are local files under --project-root; no writes or network calls.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

SKILL = Path(__file__).resolve().parents[1]
ID_KEYS = {k: k + '_id' for k in ('feature', 'source', 'claim', 'issue', 'check', 'review', 'batch', 'decision')}
COUNTS = ('pass', 'fail', 'blocked', 'error', 'not_applicable', 'unchecked')
MODES = ('create', 'rebuild', 'resume', 'local_repair', 'read_only', 'display')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_bundle(bundle, root, mode='integrity'):
    root = Path(root).resolve()
    findings = []
    def fail(code, locator, detail):
        findings.append({'code': code, 'locator': locator, 'detail': detail})
    def local(locator):
        if not isinstance(locator, str) or not locator.strip():
            raise ValueError('missing local file locator')
        p = (root / locator).resolve()
        if not p.is_relative_to(root) or not p.is_file():
            raise ValueError('locator is not an existing file inside project root')
        return p
    def ids(locator, owner):
        try:
            values = json.loads(local(locator).read_text(encoding='utf-8-sig'))
            if not isinstance(values, list) or any(not isinstance(x, str) or not x for x in values) or len(values) != len(set(values)):
                raise ValueError('ID file must be a JSON array of unique nonempty strings')
            return values
        except (ValueError, OSError) as e:
            fail('BAD_MEMBERSHIP', owner, str(e)); return []
    def placeholders(value, at):
        if isinstance(value, dict):
            if value.get('template_only') is True:
                fail('TEMPLATE', at, 'template records are not project evidence')
            for k, v in value.items(): placeholders(v, at + '.' + k)
        elif isinstance(value, list):
            for i, v in enumerate(value): placeholders(v, at + '[' + str(i) + ']')
        elif isinstance(value, str) and ('__UNSET__' in value or re.fullmatch(r'(?:TODO|PLACEHOLDER|DEMO|EXAMPLE)(?:[-_].*)?', value, re.I)):
            fail('PLACEHOLDER', at, 'uninstantiated value')
    placeholders(bundle, 'bundle')
    manifest = bundle.get('manifest', {})
    if not isinstance(manifest, dict): raise ValueError('manifest must be an object')
    versions = {'skill': json.loads((SKILL / 'version.json').read_text(encoding='utf-8'))['version'],
                'schema': digest(SKILL / 'assets/templates/audit_record.schema.json')}
    files = manifest.get('version_files', {})
    if not isinstance(files, dict): raise ValueError('version_files must be an object')
    for key, locator in files.items():
        if key in versions:
            fail('RESERVED_VERSION', 'manifest.version_files.' + key, 'skill/schema come from this installed tool')
            continue
        try: versions[key] = digest(local(locator))
        except (ValueError, OSError) as e: fail('VERSION_FILE', key, str(e))
    if mode == 'snapshot':
        return {'kind': 'VERSION_SNAPSHOT', 'current_versions': versions, 'findings': findings,
                'record_gate': 'BLOCKED' if findings else 'SNAPSHOT_AVAILABLE', 'map_truth': 'NOT_EVALUATED'}
    if manifest.get('template_only') is not False:
        fail('MANIFEST_TEMPLATE_FLAG', 'manifest', 'real export must explicitly set template_only=false')
    for key in ('scope_id', 'task_mode', 'task_scope', 'impact_scope', 'completion_scope', 'authorization_locator'):
        if not manifest.get(key): fail('SCOPE_MISSING', 'manifest.' + key, 'required scope/authorization declaration missing')
    if manifest.get('task_mode') not in MODES: fail('TASK_MODE', 'manifest.task_mode', 'unrecognized task mode')
    for key in ('data', 'rules'):
        if key not in versions: fail('VERSION_MISSING', key, 'bind current data and rule configuration files')
    records = bundle.get('records')
    if not isinstance(records, list) or not records:
        fail('EMPTY_RECORDS', 'records', 'empty exports cannot establish completed work'); records = []
    schema = json.loads((SKILL / 'assets/templates/audit_record.schema.json').read_text(encoding='utf-8'))
    required = {x['if']['properties']['record_type']['const']: x['then']['required'] for x in schema['allOf']}
    indexes = {k: {} for k in ID_KEYS}
    for n, record in enumerate(records):
        at = 'records[' + str(n) + ']'
        if not isinstance(record, dict): fail('RECORD_TYPE', at, 'record must be an object'); continue
        kind = record.get('record_type')
        if kind not in indexes: fail('RECORD_TYPE', at, 'unknown record_type'); continue
        missing = [k for k in required[kind] if k not in record]
        if missing: fail('REQUIRED_FIELDS', at, ','.join(missing))
        if record.get('template_only') is not False: fail('RECORD_TEMPLATE_FLAG', at, 'template_only must be false')
        value = record.get(ID_KEYS[kind])
        if not isinstance(value, str) or not value: fail('IDENTITY', at, 'real nonempty ID required'); continue
        if value in indexes[kind]: fail('DUPLICATE_ID', at, value)
        indexes[kind][value] = record
    ref_fields = {'source_refs': 'source', 'adopted_source_refs': 'source', 'claim_refs': 'claim',
                  'unresolved_issue_ids': 'issue', 'check_refs': 'check', 'closure_check_ids': 'check', 'review_refs': 'review'}
    for kind, index in indexes.items():
        for value, record in index.items():
            for field, target in ref_fields.items():
                refs = record.get(field, [])
                if not isinstance(refs, list): fail('REF_TYPE', value + '.' + field, 'must be a list'); continue
                for ref in refs:
                    if not isinstance(ref, str) or ref not in indexes[target]: fail('BROKEN_REF', value + '.' + field, str(ref))
            if kind == 'claim' and record.get('feature_id') not in indexes['feature']:
                fail('BROKEN_FEATURE_REF', value, 'claim feature_id is unresolved')
    population = ids(manifest.get('entity_ids_locator'), 'manifest.entity_ids_locator')
    if not population: fail('EMPTY_POPULATION', 'manifest', 'actual project entity denominator required')
    if set(population) != set(indexes['feature']): fail('DENOMINATOR', 'manifest', 'entity ID file differs from exported feature records')
    coverage = manifest.get('coverage', {})
    vals = [coverage.get(k) for k in ('baseline_count', 'added', 'merged_or_retired_with_evidence', 'final_count')]
    if any(type(v) is not int or v < 0 for v in vals) or vals[0] + vals[1] - vals[2] != vals[3] or vals[3] != len(population):
        fail('RECONCILIATION', 'manifest.coverage', 'baseline + added - evidenced merge/retire must equal current denominator')
    impact = ids(manifest.get('impact_ids_locator'), 'manifest.impact_ids_locator')
    completion = ids(manifest.get('completion_ids_locator'), 'manifest.completion_ids_locator')
    if not impact or not completion or not set(completion).issubset(impact) or not set(impact).issubset(population):
        fail('SCOPE_SETS', 'manifest', 'nonempty completion <= impact <= project population required')
    if manifest.get('task_mode') in ('create', 'rebuild') and set(completion) != set(population):
        fail('WHOLE_SCOPE_REDUCED', 'manifest', 'full task cannot silently become a partial denominator')
    bindings = manifest.get('rule_bindings', [])
    if not isinstance(bindings, list) or not bindings:
        fail('EMPTY_RULE_BINDINGS', 'manifest.rule_bindings', 'declare all applicable rules and their actual memberships'); bindings = []
    seen_rules = set(); required_check_ids = set(); executed = 0
    def fingerprint(record, deps, at):
        inputs = record.get('input_versions', {})
        for key in set(deps) | {'skill', 'schema', 'data', 'rules'}:
            if key not in versions: fail('DEPENDENCY_MISSING', at, key)
            elif inputs.get(key) != versions[key]: fail('STALE', at, 'changed or missing dependency: ' + key)
    for binding in bindings:
        if not isinstance(binding, dict): fail('BINDING_TYPE', 'rule_bindings', 'object required'); continue
        rule = binding.get('rule_id'); check_id = binding.get('check_id')
        if not isinstance(rule, str) or not re.fullmatch(r'Q(?:0[1-9]|1[0-9]|2[0-8])', rule) or rule in seen_rules:
            fail('RULE_ID', 'rule_bindings', 'unique Q01-Q28 binding required'); continue
        seen_rules.add(rule); required_check_ids.add(check_id)
        expected = ids(binding.get('expected_ids_locator'), rule)
        if not set(expected).issubset(impact): fail('BINDING_SCOPE', rule, 'members must be in declared impact set')
        if not expected:
            try: local(binding.get('nonexistence_evidence'))
            except (ValueError, OSError): fail('EMPTY_RULE_SCOPE', rule, 'empty query needs actual nonexistence evidence; never PASS')
        record = indexes['check'].get(check_id)
        if record is None: fail('CHECK_MISSING', rule, str(check_id)); continue
        if record.get('rule_id') != rule or record.get('rule_version') != binding.get('rule_version'):
            fail('RULE_VERSION', check_id, 'rule ID/version differs from binding')
        deps = binding.get('dependencies', [])
        if not isinstance(deps, list) or any(not isinstance(d, str) for d in deps): fail('DEPENDENCIES', rule, 'string list required'); deps = []
        fingerprint(record, deps, check_id)
        try:
            if digest(local(record.get('expected_ids_locator'))) != record.get('expected_ids_hash') or ids(record.get('expected_ids_locator'), check_id) != expected:
                fail('MEMBERSHIP_CHANGED', check_id, 'check membership/hash differs from current rule scope')
        except (ValueError, OSError): fail('MEMBERSHIP_CHANGED', check_id, 'check membership file unavailable')
        counts = record.get('counts', {}); outcomes = record.get('outcomes', {})
        partition = []
        for key in COUNTS:
            members = outcomes.get(key)
            if not isinstance(members, list) or any(not isinstance(x, str) for x in members):
                fail('OUTCOME_SET', check_id + '.' + key, 'explicit real ID list required'); members = []
            if type(counts.get(key)) is not int or counts.get(key) != len(members): fail('COUNT', check_id + '.' + key, 'count differs from outcome IDs')
            partition.extend(members)
        if len(partition) != len(set(partition)) or set(partition) != set(expected) or counts.get('expected') != len(expected):
            fail('CHECK_PARTITION', check_id, 'outcomes must partition expected IDs exactly, including unchecked and N_A')
        reasons = record.get('not_applicable_with_reasons', [])
        na_ids = {x.get('feature_id') for x in reasons if isinstance(x, dict) and x.get('reason') and x.get('object_type') and x.get('task_relation')}
        if na_ids != set(outcomes.get('not_applicable', [])): fail('NA_REASON', check_id, 'every N_A requires type and task relation')
        if record.get('result') == 'PASS' and (not expected or counts.get('pass', 0) <= 0 or any(counts.get(k, 0) for k in ('fail', 'blocked', 'error', 'unchecked'))):
            fail('FALSE_PASS', check_id, 'empty/unrun/error/blocked/failed scope cannot PASS')
        if record.get('result') == 'N_A' and (counts.get('not_applicable') != len(expected) or any(counts.get(k, 0) for k in ('pass', 'fail', 'blocked', 'error', 'unchecked'))):
            fail('FALSE_NA', check_id, 'N_A cannot conceal checked failures or unrun members')
        for key in ('scope_query', 'implementation_hash', 'command_or_steps', 'executor', 'executed_at', 'result_locator'):
            if not record.get(key): fail('EXECUTION_EVIDENCE', check_id + '.' + key, 'required execution detail missing')
        try: local(record.get('result_locator'))
        except (ValueError, OSError): fail('RESULT_MISSING', check_id, 'local result artifact unavailable')
        executed += sum(counts.get(k, 0) for k in ('pass', 'fail', 'blocked', 'error') if type(counts.get(k)) is int)
        if mode == 'preflight' and record.get('result') not in ('PASS', 'N_A'):
            fail('CHECK_NOT_READY', check_id, str(record.get('result')))
    if mode == 'preflight':
        if executed == 0: fail('NO_EXECUTED_CHECK', 'manifest', 'N_A-only/empty task does not establish completed work')
        required_claims = manifest.get('required_claim_ids', [])
        if manifest.get('task_mode') in ('create', 'rebuild', 'resume', 'local_repair'):
            for value in completion:
                feature = indexes['feature'].get(value, {})
                adopted = feature.get('adopted_geometry_claim')
                if not feature.get('source_refs') or not feature.get('claim_refs') or not adopted or adopted not in required_claims:
                    fail('FACT_BASELINE_MISSING', value, 'fact task needs declared sources and required adopted geometry evidence')
                geom = feature.get('geometry', {})
                try:
                    if digest(local(geom.get('locator'))) != geom.get('hash'): fail('GEOMETRY_VERSION', value, 'geometry file hash mismatch')
                except (ValueError, OSError): fail('GEOMETRY_VERSION', value, 'geometry file/record hash unavailable')
        for value in required_claims:
            claim = indexes['claim'].get(value, {})
            evidence_ok = claim.get('confidence') in ('E2', 'E3')
            # Preserve explicitly approved, located height estimates without promoting E1 geometry or unknowns.
            if claim.get('confidence') == 'E1' and claim.get('property') in ('height', 'height_m', 'height_interval') and claim.get('uncertainty'):
                decision = indexes['decision'].get(manifest.get('estimate_approval_refs', {}).get(value), {})
                try:
                    local(decision.get('actual_approval_locator'))
                    evidence_ok = (decision.get('type') == 'height_estimate' and decision.get('status') == 'APPROVED'
                                   and value in decision.get('related_ids', []) and bool(decision.get('independent_reviewer'))
                                   and bool(decision.get('new_evidence_refs')) and bool(decision.get('approved_at'))
                                   and bool(manifest.get('designated_acceptor')) and decision.get('approval_authority') == manifest.get('designated_acceptor'))
                except (ValueError, OSError): evidence_ok = False
            if claim.get('decision') != 'adopted' or not evidence_ok or claim.get('adopted_value') is None or not claim.get('adopted_source_refs') or not claim.get('source_locator') or not claim.get('reason') or not claim.get('reviewer') or not claim.get('reviewed_at'):
                fail('SOURCE_BLOCKED', value, 'required fact lacks adopted, located, reviewed E2/E3 evidence')
            for ref in claim.get('adopted_source_refs', []):
                rights = indexes['source'].get(ref, {}).get('rights', {})
                for use in manifest.get('required_source_uses', ['view']):
                    if rights.get(use) is not True or not rights.get('terms_locator'):
                        fail('RIGHTS_BLOCKED', ref, 'required use lacks declared permission/terms: ' + use)
        required_reviews = manifest.get('required_review_ids', [])
        if not required_reviews: fail('HUMAN_REVIEW_MISSING', 'manifest', 'required actual human review declarations missing')
        individual = set()
        for value in required_reviews:
            review = indexes['review'].get(value, {})
            deps = manifest.get('review_dependencies', [])
            fingerprint(review, deps, value)
            members = ids(review.get('member_ids_locator'), value)
            if not members or not set(members).issubset(impact): fail('REVIEW_SCOPE', value, 'review must cover real nonempty impact members')
            try:
                if digest(local(review.get('member_ids_locator'))) != review.get('membership_hash'): fail('REVIEW_MEMBERSHIP', value, 'membership changed')
            except (ValueError, OSError): fail('REVIEW_MEMBERSHIP', value, 'membership file missing')
            if review.get('verdict') != 'PASS' or not review.get('observations') or not review.get('questions') or not review.get('reviewer') or not review.get('reviewed_at') or review.get('not_reviewed'):
                fail('REVIEW_NOT_READY', value, 'observations, questions, identity and current completed verdict required')
            view = review.get('view', {})
            for key in ('id', 'center', 'scale_or_zoom', 'bearing', 'pitch', 'viewport_px', 'device_pixel_ratio', 'interaction_state'):
                if view.get(key) is None: fail('VIEW_MISSING', value, key)
            sampling = review.get('sampling', {})
            if sampling.get('mode') not in ('individual_human', 'sampled_human', 'rule_covered'):
                fail('REVIEW_MODE', value, 'declare individual_human, sampled_human or rule_covered')
            if sampling.get('mode') == 'sampled_human' and (sampling.get('seed') is None or set(sampling.get('sampled_ids', [])) != set(members) or type(sampling.get('population')) is not int or sampling.get('unsampled_count') != sampling.get('population') - len(members)):
                fail('SAMPLING', value, 'sample seed, IDs, population and unsampled count must reconcile')
            if sampling.get('mode') == 'individual_human': individual.update(members)
        if not set(manifest.get('required_individual_ids', [])).issubset(individual):
            fail('INDIVIDUAL_REVIEW_MISSING', 'manifest', 'sampled/rule-covered reviews cannot replace required individual reviews')
        for value, issue in indexes['issue'].items():
            if issue.get('state') not in ('closed', 'resolved', 'not_a_defect') and set(issue.get('feature_ids', [])) & set(impact):
                fail('OPEN_RISK', value, 'residual issues need external review/actual approval; tool never auto-accepts P2')
    return {'kind': 'AUDIT_RECORD_CHECK', 'mode': mode,
            'record_gate': 'BLOCKED' if findings else ('RECORD_PREFLIGHT_SATISFIED' if mode == 'preflight' else 'INTEGRITY_SATISFIED'),
            'map_truth': 'NOT_EVALUATED', 'actual_acceptance': 'NOT_EVALUATED',
            'limits': 'Declared record consistency only; no geometry checks, source reread, execution replay, exhaustive applicability proof or human approval verification.',
            'current_versions': versions, 'counts': {'records': len(records), 'entities': len(population), 'rule_bindings': len(bindings), 'findings': len(findings)}, 'findings': findings}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project-root', required=True)
    ap.add_argument('--bundle', required=True)
    ap.add_argument('--mode', choices=('snapshot', 'integrity', 'preflight'), default='integrity')
    args = ap.parse_args()
    try:
        bundle = json.loads(Path(args.bundle).read_text(encoding='utf-8-sig'))
        if not isinstance(bundle, dict): raise ValueError('bundle must be an object')
        result = check_bundle(bundle, args.project_root, args.mode)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if result['findings'] else 0
    except (ValueError, OSError, KeyError, TypeError, AttributeError) as e:
        print(json.dumps({'kind': 'AUDIT_RECORD_CHECK', 'record_gate': 'ERROR', 'map_truth': 'NOT_EVALUATED', 'error': str(e)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())

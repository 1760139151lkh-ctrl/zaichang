# 迁移映射与版本说明（按需）

版本1.0.0由2026-10-06原map-quality-pack v1.0通用化。51文件清单全部匹配，下载合订版与包内合订版byte-identical；Markdown正文归一后无实质差异，标题/合订排版不影响门槛。原336行TXT未附入包，按PLAN/ROOT_CAUSES记录保留有用要求、废止宽松完成条件。材料实施命令未授权本次改图。历史阅读S01—S33逐项保存，未在本次重新核验。

本文件用于技能升级/迁移复核，普通实施不强制加载。所有运行义务有SKILL入口的必读条件；专业模块、Q、流程与卡片随技能完整提供，不依赖原ZIP、机器路径或聊天。来源列是原文定位，不是运行依赖。

## Q01—Q28逐项对应

每行的完整输入/方法、合法例外、防误报、失败见证、修复与复查范围在链接的Q行原样保留；模块给出工程操作，范围适配在baseline-scope中。结构比较验证28行各四列文本与原文一致（只加可解析锚点）。必须执行动作不因profile或渐进加载变成建议。

|原文件/编号/行|技能落点|触发条件|必须执行|检查与阻塞|
|---|---|---|---|---|
|CHECK_RULES:13 / Q01|[Q01](check-rules.md#q01) + [coverage-state](coverage-state.md)|盘点、增删、合并或覆盖|对账源/规范/实例/候选和增删主ID|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:14 / Q02|[Q02](check-rules.md#q02) + [sources-alignment](sources-alignment.md)|来源/转换/单位/轴向变动|核验转换链、轴序单位和独立残差|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:15 / Q03|[Q03](check-rules.md#q03) + [sources-alignment](sources-alignment.md)|图片配准或模型变动|区分拟合/检验并比较模型与适用域|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:16 / Q04|[Q04](check-rules.md#q04) + [geometry-roads](geometry-roads.md)|平面几何修复|定位非法几何并比对修后结构/邻域|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:17 / Q05|[Q05](check-rules.md#q05) + [geometry-roads](geometry-roads.md)|交换/剖分/法线变动|检查格式环序、法线和院落剖分|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:18 / Q06|[Q06](check-rules.md#q06) + [geometry-roads](geometry-roads.md)|融合/覆盖/接边|查近重复、碎片和应共享边界|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:19 / Q07|[Q07](check-rules.md#q07) + [geometry-roads](geometry-roads.md)|道路实宽或路面变化|按真实米宽/里程与来源事件查突变|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:20 / Q08|[Q08](check-rules.md#q08) + [geometry-roads](geometry-roads.md)|道路显示/路口接缝|固定视角查cap/join/casing及单位|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:21 / Q09|[Q09](check-rules.md#q09) + [geometry-roads](geometry-roads.md)|断路/图连接变动|查端点、分量、边界端口和关键OD|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:22 / Q10|[Q10](check-rules.md#q10) + [geometry-roads](geometry-roads.md)|桥隧/交叉/层级|交叉候选按shared-node/层级/通行裁决|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:23 / Q11|[Q11](check-rules.md#q11) + [geometry-roads](geometry-roads.md)|路楼碰撞/架空/门洞|二维候选再查实占用/垂直区间/净空|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:24 / Q12|[Q12](check-rules.md#q12) + [geometry-roads](geometry-roads.md)|道路面/入口/导航|道路/通行域/权限/已核入口映射路图|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:25 / Q13|[Q13](check-rules.md#q13) + [buildings-grounds](buildings-grounds.md)|建筑身份/轮廓|分接地/屋顶口径核对翼/孔洞/身份|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:26 / Q14|[Q14](check-rules.md#q14) + [buildings-grounds](buildings-grounds.md)|建筑父子/生成器|核对父outline/parts、实例与重复体量|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:27 / Q15|[Q15](check-rules.md#q15) + [buildings-grounds](buildings-grounds.md)|高度/细节/复杂体量|逐参数解析claim、证据档与代理身份|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:28 / Q16|[Q16](check-rules.md#q16) + [buildings-grounds](buildings-grounds.md)|3D表示/网格|按真实Solid/MultiSurface等类型验证|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:29 / Q17|[Q17](check-rules.md#q17) + [geometry-roads](geometry-roads.md)|关系/邻域/区边界|按关系表查邻域和跨区接边|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:30 / Q18|[Q18](check-rules.md#q18) + [buildings-grounds](buildings-grounds.md)|操场/球场/标线|全类设施slot/标线规则/真实参数审查|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:31 / Q19|[Q19](check-rules.md#q19) + [buildings-grounds](buildings-grounds.md)|水陆/植被/未知面|每面追溯语义和ground occupancy|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:32 / Q20|[Q20](check-rules.md#q20) + [cartography-navigation](cartography-navigation.md)|主题/token/样式|语义token到实现/状态/光照映射审查|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:33 / Q21|[Q21](check-rules.md#q21) + [cartography-navigation](cartography-navigation.md)|标签/控件/尺度|实际投影框、UI遮挡与关键识别检查|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:34 / Q22|[Q22](check-rules.md#q22) + [cartography-navigation](cartography-navigation.md)|LOD/泛化/分块|规范/LOD/共享边/切分边界对照|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:35 / Q23|[Q23](check-rules.md#q23) + [cartography-navigation](cartography-navigation.md)|搜索/相机/选择/定位/路线|搜索/选中/卡片/入口/路线真实ID链|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:36 / Q24|[Q24](check-rules.md#q24) + [coverage-state](coverage-state.md)|输入/规则/技能/合并版本改变|比对依赖版本，STALE补验唯一集成版|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:37 / Q25|[Q25](check-rules.md#q25) + [sources-alignment](sources-alignment.md)|获取/使用/缓存/交付/发布|逐资产用途许可/署名/隐私/产物核对|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:38 / Q26|[Q26](check-rules.md#q26) + [qa-acceptance](qa-acceptance.md)|绑定或变更检查器|坏样本漏报与合法样本误报实际复查|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:39 / Q27|[Q27](check-rules.md#q27) + [coverage-state](coverage-state.md)|点名缺陷或系统样本失败|按规则指纹扩查同类和分区覆盖|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|
|CHECK_RULES:40 / Q28|[Q28](check-rules.md#q28) + [qa-acceptance](qa-acceptance.md)|严重性/例外/N_A/scope改变|对照降级/排除/例外史与实际审批|按本Q合法例外、见证和复查范围；缺输入/例外依据/执行/当前结果则阻塞，不能空PASS|

## 未编号约束与新增通用调度

|原文落点/迁移索引|技能落点|触发条件|必须执行|阻塞/复查|
|---|---|---|---|---|
|ENGINEERING_METHOD A / U01|[core](core.md)|任何事实/显示/导航工作|保留五层与源→实体→实例→标签→入口→路图链|样式不可修饰事实错误；身份链断不READY|
|B / U02|[sources](sources-alignment.md)|来源/属性/冲突|按属性E0—E3、独立组、时效、具体locator裁决|名称等级不给高度；同底图不算独立；重要冲突阻塞|
|B/MAIN许可 / U03|[sources](sources-alignment.md)、[Q25](check-rules.md#q25)|取数/描摹/缓存/发布|核对具体用途/产品/合同和署名；查实际产物|来源列表不等于授权；不扫受限公共瓦片|
|C / U04|[sources](sources-alignment.md)|基准/配准/融合|分提供方、投影、图片、渲染原点、高程；冻结阈值/域|独立检验、误差单位/口径/尺度，未核实不挪地物|
|C融合 / U05|[sources](sources-alignment.md)|多源对应|先匹配再属性裁决，留一对多/多对一源ID|不平均冲突坐标，不把匹配半径当吸附距离|
|D / U06|[roads](geometry-roads.md)|道路/桥/入口|三分实宽/显示、视觉/图、二维/实体；合法关系取证|未知层级不合法放行；虚设layer不消警|
|E / U07|[buildings](buildings-grounds.md)|体量/分部/细节|F/B/P/D、footprint口径、总高/底高、实体类型|错误盒子不可信LOD1，代理不计可信3D；真悬挑不误删|
|F / U08|[grounds](buildings-grounds.md)|设施/自然地物|组合slot、规则共享/参数实核、树冠/阴影/水陆分离|标准模板非实测；未知名称分unknown/not_applicable|
|G / U09|[cartography](cartography-navigation.md)、[profile](../profiles/zijingang.md)|制图/紫金港|语义token、项目风格；紫金港保留暗暖灰金|不强加其他地图，不用换主题逃检|
|H / U10|[cartography](cartography-navigation.md)|标签/LOD/交互|真实投影框/UI占用、四尺度、候选锚点/优先级、入口链|核心名称另有可达识别；不全隐标签；派生不改事实|
|I / U11|[state](coverage-state.md)|状态/版本/接续|保留主状态前提和四阻塞维度，当前依赖推导|缺检查、旧hash、邻域未知、冲突均不READY|
|J分母 / U12|[coverage](coverage-state.md)|盘点/覆盖/候选|唯一实体、增删/tombstone/候选裁决、三区维度|隐藏/LOD/重复来源不改变分母；排难区阻塞|
|J审查 / U13|[coverage](coverage-state.md)|自动/人工/抽样|自动全量、关键逐件、规则覆盖/样本分开，真实种子ID|未抽中不得逐件；系统问题扩全部机制成员|
|J统计例 / U14|[coverage](coverage-state.md)|选定统计抽样方案|59仅是特定95%/5%假设下可选校准，记录实际样本|不可用于关键对象或证明无缺陷；小集合全检|
|K / U15|[QA](qa-acceptance.md)|检查器/批次/视图|坏/合法样本、具体位置、增量QA、正常/ID/差异视图|视频/测试数量无证明力；不逐对象全流程回归|
|L风险 / U16|[core](core.md)、[final](qa-acceptance.md)|风险/残余/候选|保留P0/P1/P2、独立复核和实际指定批准|不能工作量降级/主实施自批；P0/P1零|
|MAIN/BASELINE / U17|[baseline](baseline-scope.md)|首次实施/接续|8项基线、真实栈/链/运行/分母/未知/授权；保存用户改动|未有真实数据不写零；基准未知只允许取证|
|COMMON与A—F / U18|[collaboration](collaboration.md)|实际独立平行对话|6类输入/写边界/动作/检查/产物/门槛和单写契约|缺实际契约仅只读；不sub-agent；跨域主对话裁决|
|phases README与01—12 / U19|[workflow](workflow.md)|流程执行/恢复|12段各有进入、动作、输出、退出、禁止跨越、回退|阶段9不是第一次测试；合并失效回上游补验|
|SCHEMA_GUIDE、原schema/examples / U20|[records](records.md)、[templates](../assets/templates/)|审计记录/批次|保留8种字段、template_only、真实ID/版本/未知、必要派生视图|一套事实账本；schema不证明现实正确|
|FINAL_ACCEPTANCE 1—22 / U21|[最终22门槛](qa-acceptance.md#final-card)|提交前|逐行实际值/观察+版本+定位+失败/N_A|分别报运行、规则、事实视觉、候选与接受；空/旧/演示不证据|
|REJECT R01—R12 / U22|[打回卡](qa-acceptance.md#rejection)|拒收/错误完成声明|撤销无依据READY，保留有效工作；恢复最后有效版本/根因/类/邻域/唯一版|不得靠补图/空计划恢复；仅回滚错或越权部分|
|GOAL_SEAL、MAIN退出 / U23|[core](core.md)、[QA](qa-acceptance.md)|目标模式/中断|真实阻塞、有效改动、当前版、未完成集、下一动作检查点|工具停止不是验收；不假称控制/goal内部|
|ADVERSARIAL_REVIEW / U24|[反规避](anti-evasion.md)|所有提交/放行|29种攻击逐项核对，正常成品和实际作用证据|空表/旧结果/隐藏/全P2/N_A/自填接受拒收|
|LIMITATIONS/PLAN/REPORT/S01—S33 / U25|[历史](research-history.md)、[sources](research-sources.json)|方法更新/依据查询|保留原网址、阅读范围/失败/未取数据，归属原研究轮次|本轮不冒充重新核验，不把入口当校园实测|
|用户第四部分 / U26|[baseline](baseline-scope.md)|每次调用|6模式，task/impact/completion三范围，有效复用与共享变动扩大依赖|局部不机械全图返工，全图不偷换局部|
|用户六/七部分 / U27|[record tool](records-tool.md)|记录检查|可运行stdlib工具，输入输出/exit0/1/2、有效与负例|只记录一致性/部分前提；不替Q/GIS/人工接受|
|用户协作/安装边界 / U28|[入口](../SKILL.md)|技能发现/协作|设计管UI，定位管日常位置，导航管入口；状态留项目|不万能化、不个人路径/账号、不改其他技能/模型/权限，不自动上传|

## 操作规格的具体落点

|原OPERATIONAL_PREDICATES节|实际落点|执行/阻塞|
|---|---|---|
|1 配准报告|[sources](sources-alignment.md)|独立r_i、均偏差、RMSE/P95/max、点/域/畸变；控制误差超过细节尺度不能判该细节准确|
|2 道路宽度|[roads](geometry-roads.md)|里程w(s)、单位/间距/阈值/事件候选；真实和显示分别编号，不能强恒宽|
|3 道路图|[roads](geometry-roads.md)|已知共享节点/语义构图；未知BLOCKED，距离近不等于可连|
|4 穿透|[roads](geometry-roads.md)|bbox候选→实占用/高程/关系精查；长度面积误差带，未知不自动放行|
|5 建筑证据|[buildings](buildings-grounds.md)|outline/parts/claims/净空/实体类型；数学、来源、邻域、可读性四结果分开|
|6 分区同类|[coverage](coverage-state.md)|并集AOI/缓冲接边、唯一ID、规则指纹全量+真实抽样；系统失败扩类|
|7 标签/合并|[cartography](cartography-navigation.md)、[state](coverage-state.md)、[collaboration](collaboration.md)|真实排版框、关键识别、依赖hash、唯一版关系，源码无冲突不说明空间正确|

模板仅必要通用变化：schema URN从原项目名改为map-engineering，字段契约不减少；style的preserved_direction留项目参数，dark_ground→project_ground、campus尺度名→full_extent；新增task.example是既有账本的导出/调度规格。原项目风格保存在profile。其他原example字段和未知保留。正式升级需更新version.json、本映射及规则失效说明；普通实施不得改技能规则。

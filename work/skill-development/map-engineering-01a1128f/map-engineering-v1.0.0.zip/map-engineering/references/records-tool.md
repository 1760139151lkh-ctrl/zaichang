# 记录检查工具：输入、输出与边界

准备导出审计或运行脚本前必读。实际入口为[scripts/check_records.py](../scripts/check_records.py)，Python 3.10+标准库，无第三方依赖、网络访问或项目写入。没有预装GIS引擎/地图适配器。

## 输入

从项目现有唯一账本导出一个JSON快照，不另建长期权威账本。[task.example.json](../assets/templates/task.example.json)是不可用于验收的模板；记录条目复用原[结构schema](../assets/templates/audit_record.schema.json)和对应example模板。真实ID、当前文件、版本和观察需来自实际项目。

- 顶层`manifest`和`records`（8种原record_type）。记录工具验证原schema的record_type、required字段和template_only契约以及下面限定的不变量；它不声称实现所有任意JSON Schema关键字。
- manifest：scope_id、template_only=false、task_mode（create/rebuild/resume/local_repair/read_only/display）、task_scope/impact_scope/completion_scope说明、authorization_locator、entity_ids_locator、impact_ids_locator、completion_ids_locator、增删coverage。
- 三个ID文件是当前项目内的JSON字符串数组；唯一、非空；completion⊆impact⊆项目分母，create/rebuild不得缩小成局部。该导出分母必须先经过实际源/规范/实例/候选枚举，工具不证明枚举真的完整。
- `version_files`将data/rules及实际依赖（alignment、source_decisions、geometry、attributes、membership、generator、style等）绑定项目内现有文件。工具重算SHA256；skill版本和schema hash从当前工具所在技能读取，禁止项目冒充这两项。
- `rule_bindings`每条：rule_id、rule_version、check_id、dependencies、expected_ids_locator；空集合需项目内nonexistence_evidence，不能空PASS。每个适用Q必须真实绑定，工具不证明适用性判断完整；按Q契约另留坏/合法样本及结果。
- check沿用原字段，新增`outcomes`：pass/fail/blocked/error/not_applicable/unchecked六个真实ID数组，精确分割expected；counts与数组一一对账。N_A逐项有feature_id、object_type、task_relation、reason，不是PASS。expected_ids_hash为所引用ID文件的字节SHA256；result_locator须指向本地真实结果文件。
- `input_versions`按当前snapshot填写。check至少包含skill/schema/data/rules与该binding全部dependencies；review包含相同基础项与manifest.review_dependencies。不能只填旧hash或更新日期。
- preflight另需required_claim_ids、required_source_uses、required_review_ids、required_individual_ids、review_dependencies。事实任务必须有采用的geometry claim及当前几何文件。required claim通常须有已裁决E2/E3、实际属性定位、采用值、来源、理由与审查记录。可审查E1高度估计保留合法例外：明确uncertainty，estimate_approval_refs映射到APPROVED的height_estimate decision，关联该claim，有新证据/独立审查/时间/本地实际批准定位，approval_authority等于manifest.designated_acceptor。E0/未解冲突及E1轮廓不获例外；不把代理或区间说成实测/可信3D完成。这些只是声明结构检查，不是工具重新阅读证据或核准批准。
- 原source rights字段按当前实际用途声明；工具只核对required_source_uses为true且有条款定位。它不验证合同法律效力/批准真伪。review必须有问题、观察、当前版本、完整view与成员；sampled_human有种子/成员/总体/未抽数量，不能替individual_human。

未知日期、非必需名称/高度保留null/unknown，不能null→0。状态字段是缓存，工具不以其done/ACCEPTED值作通过依据。未采用的争议记录可保留在integrity导出；preflight仍会阻塞所声明范围的必需事实、未完成检查和相关开放风险。残余P2也需外部指定验收；本工具保守地不自动接受任何开放风险。

## 命令

把下面占位路径换成实际项目/技能路径；这些是通用CLI规格，不是某地图已存在的命令。

```text
python <skill-dir>/scripts/check_records.py --project-root <actual-project> --bundle <actual-export.json> --mode snapshot
python <skill-dir>/scripts/check_records.py --project-root <actual-project> --bundle <actual-export.json> --mode integrity
python <skill-dir>/scripts/check_records.py --project-root <actual-project> --bundle <actual-export.json> --mode preflight
```

snapshot输出当前依赖指纹；integrity查结构/引用/计数/版本，不要求问题都已修好；preflight还查部分事实/人工/风险记录前提。脚本不写文件，stdout为JSON；退出码0=此模式限定检查满足，1=BLOCKED及具体findings，2=输入/执行ERROR。ERROR、缺文件和缺依赖不能当PASS。

## 输出及禁止推论

输出record_gate为SNAPSHOT_AVAILABLE、INTEGRITY_SATISFIED、RECORD_PREFLIGHT_SATISFIED、BLOCKED或ERROR；始终map_truth=NOT_EVALUATED，actual_acceptance=NOT_EVALUATED。findings含code/locator/detail；STALE列改变/缺失依赖。工具不修改对象状态或接受字段。

它不执行配准、拓扑、穿透、3D、投影标签检查；不重跑所声明检查、不证明日志真实、不核准例外、不覆盖全部外键/关系/分区联合/许可资产或适用性，也不证明人工逐件阅读。必须按[Q注册表](check-rules.md)、[覆盖与状态](coverage-state.md)、[最终卡](qa-acceptance.md)在真实项目绑定并执行。不能用此JSON工具替代28条地理规则，不能从结构成功推导ACCEPTANCE_READY/ACCEPTED。

本技能的脚本已通过有效合成记录、缺证据、旧数据/技能版本、模板/占位、空集、假PASS、错误、N_A和抽样冒充逐件等隔离检查；合成记录只验工具行为，不是地图或独立智能体自然触发验收。正式升级脚本后用相应坏/合法样本复查。

# 紫金港校园地图：研究驱动的 Codex 执行系统

版本：1.0 · 2026-10-06

这是一份研究报告、执行方法和提示词包，不是已修复的地图，也不是已完成的地图验收报告。输入为用户的七张截图、336行旧提示词及本轮任务书；没有取得实际代码仓库、地图矢量数据或实测资料。

## 使用入口

把本目录放入实际项目的 `map-quality-pack/`（或在启动时明确它的真实位置）。先把 `prompts/GOAL_SEAL.md` 作为开场约束，再给主对话 `prompts/MAIN.md` 与 `prompts/BASELINE.md`。主对话需读取 `policy/ENGINEERING_METHOD.md`、`policy/CHECK_RULES.md`、`templates/SCHEMA_GUIDE.md`，再按基线结果实例化分支契约。不要只发送短启动版。

分支文件是项目内独立对话的任务书。没有真实的平行对话控制能力时，由用户开启独立对话并发送对应文件；不得用 sub-agent 冒充，不得声称已开出并不存在的对话。文件独立性不足时改为只读研究和补丁建议，由主对话单写。

## 内容索引

- `research/PLAN.md`、`REPORT.md`、`ROOT_CAUSES.md`：研究计划、来源—结论—规则映射、根因分析与访问限制。
- `research/SOURCES.json`：来源定位、已读范围、限制、具体实施动作。
- `policy/ENGINEERING_METHOD.md`：统一事实模型、来源裁决、配准、状态、覆盖、分支和发布门槛。
- `policy/CHECK_RULES.md`：28条检查的失败模式、输入、方法、例外、输出和复查范围。
- `policy/OPERATIONAL_PREDICATES.md`：配准、路图、穿透、体量、覆盖和版本检查的操作规格。
- `prompts/MAIN.md`、`BASELINE.md`：总任务与第一轮启动。
- `prompts/branches/`：6类可实例化的平行对话任务书及共享契约。
- `prompts/phases/`：12个阶段，各含进入条件、工作、输出、退出门槛及禁止跨越项。
- `templates/`：结构化示例、字段定义和派生文档规则。模板不是项目数据，不得用于宣称通过。
- `prompts/FINAL_ACCEPTANCE.md`、`REJECT.md`、`GOAL_SEAL.md`：最终验收、打回、短启动。
- `review/ADVERSARIAL_REVIEW.md`、`LIMITATIONS.md`：对抗性自审、封堵方法及尚存风险。
- `COMPLETE_PACKAGE.md`：顺序合并的完整阅读版。

## 三个必须分开的结论

1. 代码能运行。
2. 数据通过已定义、已执行、版本一致的检查。
3. 当前范围的地图满足事实、空间、视觉和交互验收。

前两项不能替代第三项。允许诚实报告阻塞或阶段结束；不允许把它们称为全图完成。只有无阻塞的候选版本才能送用户验收；用户验收也不等于测绘精度认证。

本包不包含第三方地图瓦片、校园地图原图、论文原文、用户截图、账号信息或代码仓库副本。来源记录不代表数据使用授权。

原截图没有重复打包；`research/ROOT_CAUSES.md`已经记录七图可观察线索。Codex可据真实运行定位对象；原图不可得时不得声称已逐图阅读。

# 共享记录、字段与派生文档

## 只维护一套事实，不制造十份互相抄写的文档

优先复用仓库现有数据表/文件，通过稳定ID引用。审计层只保存现有数据没有的来源裁决、状态证据和检查结果；不能另建一套手工复制的“正确地图”。本目录所有`*.example.*`均为不可用于验收的模板，含`template_only: true`或`__UNSET__`。不要把示例行写入实际完成计数。生产记录必须来自实际枚举、实际执行和实际阅读。

推荐最小逻辑表如下；可存在同一个SQLite文件、现有数据库或JSONL日志中。格式按真实技术栈选一种，不同时维护多个权威版本。

|逻辑表|必须字段与用途|
|---|---|
|manifest|scope_id、AOI几何定位/hash、分区边界、baseline_commit、版本、全部对象/类别/关键对象集合hash、排除与增删映射、阈值定位、验收角色；冻结范围和真实分母|
|sources|source_id、具体产品/图层、类型、资料定位、采集/发布/访问日、示意性、CRS声明、空间精度及依据、独立来源组、按属性可信用途、许可/衍生/缓存/再发布权限和条款定位；约束取证用途|
|claims|claim_id、feature_id/批次、属性、候选值、source_id及具体定位、源坐标/单位、观察摘要、证据等级、冲突组、采用/拒绝/未知裁决、理由、审查人/时间；按属性而不是整对象给置信度|
|features|feature_id、源ID映射、名称及name_status、class/layer/zone、几何定位/hash、CRS链、parent/parts/relations、claim_refs、属性证据等级、冲突与疑点、表达档与体量依据、style_token、owner、适用检查/结果引用、当前推导状态；稳定追踪对象|
|issues|issue_id、rule_id、feature_ids、zone_ids、见证位置/视角、观测、原因候选、证据引用、P0/P1/P2、状态、责任人、交接、duplicate_of、修复提交、关闭检查与降级审批；解决具体缺陷|
|checks|check_id、规则/实现版本、scope_query、expected_ids/hash、实际count分解、输入版本、执行命令/时间/人、PASS/FAIL/BLOCKED/ERROR/N_A、失败见证、产物定位；证明实际执行|
|reviews|review_id、对象/批次/分区、成员集合、采样方法/种子、view_id/完整相机参数、数据/样式hash、审查问题、来源对照、观察与裁决、未检查项、审查人；证明人工判断的范围和依据|
|decisions|decision_id、关联issue/claim、原值/新值、理由和新增证据、影响集合、权限依据、独立审查和实际批准定位、到期条件；控制例外、降级、排除和残余风险接受|
|branch_contracts|分支真实目录/对话、基线、schema/align版本、对象范围、精确读写范围、问题前缀、上下游、交付与审查门槛；避免并行覆盖|

原始图像/地图许可不足时，表中保留允许的定位和观察摘要，不擅自缓存原件。几何与运行文件用现有路径定位，避免把大文件内嵌到每行。

## 对象记录的展开方式

所有对象都能解析出：来源列表与日期、最终几何依据、坐标链、冲突、置信度、几何/拓扑/邻域/同类/视觉状态、3D依据、样式、分区、负责分支和未解疑点。字段可以通过claim/source/check外键解析，不必在每个对象行重复复制所有来源说明。

批次仅用于共享生成规则的微对象。必须有`batch_id + generator_hash + membership_locator + membership_hash + member_count + parameters_range + sampled_member_ids`，并保持运行实例到批次/父对象映射。不能用“这一类全部检查”一句话代替成员集合。关键桥梁、主楼、运动场等不以批次隐藏逐件审查。审查覆盖类型须区分individual_human、sampled_human、rule_covered；未抽中的成员不得冒充人工逐件已看。JSON Schema只检查字段结构，跨表外键、范围、版本和事实门槛须由实际项目中的绑定检查完成。

## 状态的计算，不由模型随意填写

状态序列只描述已满足的前提；实际有效性由引用结果计算。`SOURCE_BLOCKED / CONFLICT_BLOCKED / FAILED / STALE`为阻塞维度。一个对象的所有适用检查，包括它参与的跨对象关系，都必须有当前版本结果；多个阶段可以并行取证，但不得越级形成READY。

示意算法：

```text
resolve canonical entity and full dependency fingerprint
if record is template or required identity/provenance missing: NOT_READY
if unresolved critical claim or issue: BLOCKED
for each applicable rule and required human review:
    if no result: UNCHECKED
    if result dependency fingerprint differs: STALE
    if result is ERROR/BLOCKED/FAIL: NOT_READY
    if N_A has no typed rationale and approval where needed: NOT_READY
if class coverage, neighborhood relations and zone coverage incomplete: NOT_READY
else: ACCEPTANCE_READY
ACCEPTED requires actual designated acceptance, never generated automatically
```

文件hash不能证明事实真；它只防止拿旧版本证据冒充新版本。人工评语也不能靠hash自动变真。检查器结果、资料裁决和最后审查仍需要可追溯执行。

## 必须成立的记录不变量

- `feature_id`唯一且源/派生映射可解析；所有claim/check/issue外键存在；演示ID不进入生产集合。
- 每条检查的expected集合可重算。PASS+FAIL+BLOCKED+ERROR+N_A+尚未检查集合等于其明确scope；不得将未检查并入PASS，N_A需要合法适用性解释。
- active期末数量=期初+新增-有证据的合并/退役；隐藏、降LOD和改类别不减少实体分母。
- 每个未知名称明确`unknown`还是`not_applicable`；每个未知高度明确`unknown`还是有据`estimated`；不得把null转0代表实测值。
- 来源日期未知用null；访问日期不冒充采集日期。精度未知用null，不随意写“高精度”。
- `state`是派生缓存；最终验收必须重新从当前claims/checks/reviews算，不能只读缓存。
- 问题关闭引用具体变更与复查；新证据证明不是缺陷可关闭，但原观测和裁决史不能被删除。
- 例外、改级、scope排除必须有实际批准定位；不能将模板中的reviewer字段当成授权事实。

## 十份用户可读文档如何从同一套记录生成

|派生文档|唯一数据依据|它回答什么|
|---|---|---|
|MAP_AUDIT_LEDGER.md|issues+当前checks|什么地方仍错，谁处理，关闭凭什么|
|MAP_SOURCE_MATRIX.md|sources+claims|每项属性依据哪个资料，冲突如何裁决|
|MAP_OBJECT_INVENTORY.md|features+manifest|到底有哪些对象，数量如何变化|
|MAP_CRS_AND_ALIGNMENT.md|alignment+控制点+checks|来源怎样进入共同基准，误差多大|
|MAP_TOPOLOGY_RULES.md|规则配置+Q07—Q17结果|什么关系合法，哪些对象违反|
|MAP_STYLE_SEMANTICS.md|token配置+Q20—Q22|颜色、材质、层级和标签的含义|
|MAP_ZONE_COVERAGE.md|manifest+features+checks+reviews|每区/类/对象已检、未检、阻塞、失效数量|
|MAP_UNCERTAINTY_REGISTER.md|未决claims+issues+decisions|不知道什么，影响什么，还能怎样取证|
|MAP_FIX_LOG.md|变更提交+issues+计数对账|实际改了什么，为什么，邻域复查怎样|
|MAP_FINAL_ACCEPTANCE.md|当前集成快照+最终验收卡|本范围为什么能/不能交付，残余风险谁接受|

这些可以是按需生成的视图，不强制十个长期手填文件。没有额外决策用途的字段不新增。生成器本身应短小、可复算，不能把几万行文档加工代码当地图质量工作。

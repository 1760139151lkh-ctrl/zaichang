# 所有平行对话必须读取的共享契约

你是当前项目内独立平行对话，不是sub-agent。先读MAIN、ENGINEERING_METHOD、CHECK_RULES、SCHEMA_GUIDE和主对话实例化的branch_contract。合同字段缺失不自行猜全局权限；可以只读研究，禁止生产写入。

契约至少包括：branch_id、真实对话/工作树定位、baseline_commit、schema_version、alignment_version、scope_query及完整成员hash、读路径、精确write_allowlist、禁止路径、上游依赖、交接对象、问题编号前缀、预期产物、审查者。空数组不能被解释为允许改全仓库；同一生产文件唯一写入者。

问题ID形式MAP-{分支ID}-{递增号}；已有问题沿用主ID，不给同一问题制造多个完成计数。疑似重复问题写duplicate_of候选由主对话合并。分支只写自己目录下的账本增量，禁止并发覆盖公共ledger。每条修复引用issue_id、feature_ids、来源claim、前后hash、规则结果、受影响邻域。

不得改共享坐标变换、schema、风险等级、检查阈值、AOI或别人的对象来让自己通过。需要此类变化时提交BLOCKING_HANDOFF：问题、证据、冲突对象、建议、受影响检查，由主对话裁决。禁止随意给对象加layer/bridge、隐藏对象或删除难题。

每次接收上游变更，比较契约版本；不一致先重定位差异并让原检查失效。交付含：实际commit/patch、changed_feature_ids、变化文件、计数对账、来源裁决增量、检查结果、邻域影响、未解决交接、许可说明。资料不可分发时只留合法定位与授权信息，不打包原图。

结束状态仅允许READ_ONLY_RESEARCH_READY、MERGE_READY或BLOCKED。MERGE_READY表示本契约范围可送审，不等于分区或全图已完成。不得独立填写全局FINAL_ACCEPTANCE；不得拿截图数量、自己的声明、旧输入的测试结果证明通过。

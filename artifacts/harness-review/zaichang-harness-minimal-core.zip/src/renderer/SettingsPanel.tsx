import { useEffect, useRef, useState, type MutableRefObject } from 'react';
import { ArrowLeft, Check, ChevronRight, Download, LoaderCircle, Pencil, Trash2, X } from 'lucide-react';
import { IconButton, Modal, Switch } from './ui';
import { MemoryPanelSimple, SourcePermissions } from './HarnessViews';
import type { Settings, State } from '../shared/types';

const api = window.zaichang;
export interface SettingsDraft {
  apiKey?: string;
  model?: string;
  guidance?: string;
}
interface Props {
  state: State;
  busy: boolean;
  onState: (s: State) => void;
  onClose: () => void;
  notify: (s: string) => void;
  onClear: () => void;
  draft: MutableRefObject<SettingsDraft>;
}
type Feedback = { action: string; text: string; error?: boolean } | null;
const tabs = ['连接', '记忆', '偏好'];
const date = (v: string) =>
  new Date(v).toLocaleString('zh-CN', {
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
const errorText = (e: unknown) =>
  String(e instanceof Error ? e.message : e)
    .replace(/^Error invoking remote method '[^']+': (Error: )?/, '')
    .replace(/^Error: /, '');

export function SettingsPanel({ state, busy, onState, onClose, notify, onClear, draft }: Props) {
  const [tab, setTab] = useState('连接');
  const [key, setKey] = useState(draft.current.apiKey || '');
  const [model, setModel] = useState(draft.current.model ?? state.settings.model);
  const [guidance, setGuidance] = useState(draft.current.guidance ?? state.settings.guidance);
  const [pending, setPending] = useState('');
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [memoryText, setMemoryText] = useState(''),
    [editId, setEditId] = useState<string>();
  const [sourceId, setSourceId] = useState(''),
    [clearConfirm, setClearConfirm] = useState(false);
  const testCancelled = useRef(false),
    pendingRef = useRef('');
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const sourceBackRef = useRef<HTMLButtonElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const disabled = busy || !!pending;
  useEffect(
    () => () => {
      if (pendingRef.current === 'test') void api.cancelConnection();
    },
    [],
  );
  useEffect(() => {
    if (tab !== '资料') return;
    const frame = requestAnimationFrame(() => sourceBackRef.current?.focus({ preventScroll: true }));
    return () => cancelAnimationFrame(frame);
  }, [tab]);
  function changeTab(value: string) {
    if (pendingRef.current === 'test') {
      testCancelled.current = true;
      void api.cancelConnection();
    }
    setTab(value);
    setFeedback(null);
    bodyRef.current?.scrollTo({ top: 0 });
  }
  async function perform(action: string, fn: () => Promise<void>) {
    if (pendingRef.current) return;
    pendingRef.current = action;
    setPending(action);
    setFeedback(null);
    try {
      await fn();
    } catch (e) {
      setFeedback({
        action,
        text:
          action === 'test' && testCancelled.current ? '已取消测试' : errorText(e).replace(/[。.!！]+$/, ''),
        error: !(action === 'test' && testCancelled.current),
      });
    } finally {
      pendingRef.current = '';
      setPending('');
    }
  }
  function result(actions: string[]) {
    return feedback && actions.includes(feedback.action) ? (
      <div
        className={`inline-status ${feedback.error ? 'error' : ''}`}
        role={feedback.error ? 'alert' : 'status'}
      >
        {feedback.text}
      </div>
    ) : null;
  }
  async function update(action: string, settings: Partial<Settings>) {
    await perform(action, async () => {
      onState(await api.saveSettings(settings));
    });
  }
  const connector = state.campusConnector;
  const connectorReady =
    !!connector?.configured && !!connector.available && connector.credentialsConfigured !== false;
  const connectorStatus = !connector?.configured
    ? '未连接'
    : !connector.available
      ? '暂时无法连接'
      : connector.credentialsConfigured === false
        ? '需要登录'
        : '已连接';
  return (
    <Modal title={tab === '资料' ? '校园资料' : '连接与偏好'} onClose={onClose} className="settings-panel">
      {tab === '资料' ? (
        <button ref={sourceBackRef} className="source-back text-button" onClick={() => changeTab('连接')}>
          <ArrowLeft size={14} />
          返回连接
        </button>
      ) : (
        <div className="panel-tabs" role="tablist" aria-label="在场设置">
          {tabs.map((t, i) => (
            <button
              key={t}
              id={`settings-tab-${i}`}
              ref={(el) => {
                tabRefs.current[i] = el;
              }}
              role="tab"
              aria-selected={tab === t}
              aria-controls={`settings-panel-${i}`}
              tabIndex={tab === t ? 0 : -1}
              onClick={() => changeTab(t)}
              onKeyDown={(e) => {
                let next: number | undefined;
                if (e.key === 'ArrowRight') next = (i + 1) % tabs.length;
                if (e.key === 'ArrowLeft') next = (i + tabs.length - 1) % tabs.length;
                if (e.key === 'Home') next = 0;
                if (e.key === 'End') next = tabs.length - 1;
                if (next !== undefined) {
                  e.preventDefault();
                  changeTab(tabs[next]);
                  tabRefs.current[next]?.focus();
                }
              }}
            >
              {t}
            </button>
          ))}
        </div>
      )}
      <div
        className="panel-body"
        ref={bodyRef}
        role={tab === '资料' ? 'region' : 'tabpanel'}
        id={tab === '资料' ? 'settings-source-panel' : `settings-panel-${tabs.indexOf(tab)}`}
        aria-label={tab === '资料' ? '资料来源设置' : undefined}
        aria-labelledby={tab === '资料' ? undefined : `settings-tab-${tabs.indexOf(tab)}`}
      >
        {busy && <p className="busy-note">连接设置需等本轮结束；停用记忆或资料权限会立即生效。</p>}
        {tab === '连接' && (
          <>
            <div className="section-heading">
              <div>
                <h3>DeepSeek</h3>
                <p>
                  {state.settings.mode === 'deepseek' && state.settings.hasKey
                    ? '已连接'
                    : '连接后即可开始对话'}
                </p>
              </div>
            </div>
            <label className="field-label">
              DeepSeek 密钥
              <input
                type="password"
                value={key}
                autoComplete="off"
                placeholder={state.settings.hasKey ? '已保存' : '输入密钥'}
                onChange={(e) => {
                  setKey(e.target.value);
                  draft.current.apiKey = e.target.value;
                }}
                disabled={disabled}
              />
            </label>
            <div className="field-buttons">
              <button
                className="primary-button"
                disabled={disabled || !(key || state.settings.hasKey)}
                onClick={() =>
                  void perform('save', async () => {
                    onState(
                      await api.saveSettings({ model, mode: 'deepseek', ...(key ? { apiKey: key } : {}) }),
                    );
                    setKey('');
                    draft.current.apiKey = '';
                    setFeedback({ action: 'save', text: '已连接' });
                  })
                }
              >
                {pending === 'save' && <LoaderCircle size={14} className="spin" />}连接 DeepSeek
              </button>
            </div>
            {result(['save', 'demo', 'remove'])}
            <details className="advanced connection-advanced">
              <summary>更多连接设置</summary>
              <div className="advanced-body">
                <label className="field-label">
                  模型
                  <select
                    value={model}
                    disabled={disabled}
                    onChange={(e) => {
                      setModel(e.target.value);
                      draft.current.model = e.target.value;
                    }}
                  >
                    <option value="deepseek-v4-flash">DeepSeek V4 Flash</option>
                    <option value="deepseek-v4-pro">DeepSeek V4 Pro</option>
                    {!['deepseek-v4-flash', 'deepseek-v4-pro'].includes(model) && (
                      <option value={model}>{model}</option>
                    )}
                  </select>
                </label>
                <label className="field-label">
                  自定义模型名称
                  <input
                    aria-label="自定义 DeepSeek 模型"
                    value={model}
                    disabled={disabled}
                    onChange={(e) => {
                      setModel(e.target.value);
                      draft.current.model = e.target.value;
                    }}
                  />
                </label>
                <div className="field-buttons">
                  <button
                    className="subtle-button"
                    disabled={disabled || !(key || state.settings.hasKey)}
                    onClick={() => {
                      testCancelled.current = false;
                      void perform('test', async () => {
                        const text = await api.testConnection({ model, ...(key ? { apiKey: key } : {}) });
                        setFeedback({
                          action: 'test',
                          text:
                            key || model !== state.settings.model || state.settings.mode !== 'deepseek'
                              ? '连接可用'
                              : `${text.replace(/[。.!！]+$/, '')}，连接可用`,
                        });
                      });
                    }}
                  >
                    {pending === 'test' && <LoaderCircle size={14} className="spin" />}
                    {pending === 'test' ? '正在测试…' : '测试连接'}
                  </button>
                  {pending === 'test' && (
                    <button
                      className="text-button"
                      onClick={() => {
                        testCancelled.current = true;
                        void api.cancelConnection();
                      }}
                    >
                      取消测试
                    </button>
                  )}
                  {state.settings.hasKey && (
                    <button
                      className="text-button"
                      disabled={disabled}
                      onClick={() =>
                        void perform('remove', async () => {
                          onState(await api.deleteKey());
                          setKey('');
                          draft.current.apiKey = '';
                          setFeedback({ action: 'remove', text: '连接密钥已移除' });
                        })
                      }
                    >
                      {pending === 'remove' && <LoaderCircle size={13} className="spin" />}移除密钥
                    </button>
                  )}
                </div>
                {result(['test'])}
              </div>
            </details>
            {state.settings.mode === 'deepseek' && (
              <button
                className="text-button use-demo"
                disabled={disabled}
                onClick={() =>
                  void perform('demo', async () => {
                    onState(await api.saveSettings({ mode: 'demo' }));
                    setFeedback({ action: 'demo', text: '已切换到本地示例' });
                  })
                }
              >
                使用本地示例
              </button>
            )}
            <button className="settings-navigation" onClick={() => changeTab('资料')}>
              <span>
                <strong>校园资料与天气</strong>
                <small>{connectorReady ? '已连接' : state.campus ? '已导入' : '需要时再连接'}</small>
              </span>
              <ChevronRight size={16} />
            </button>
          </>
        )}
        {tab === '资料' && (
          <>
            <SourcePermissions onState={onState} />
            <section className="campus-source-block">
              <div className="connector connector-primary">
                <div>
                  <div className="connector-title-line">
                    <strong>浙大校园资料</strong>
                    <span
                      className={`source-status ${connectorReady ? 'connected' : connector?.credentialsConfigured === false ? 'needs-login' : 'unavailable'}`}
                    >
                      {connectorStatus}
                    </span>
                  </div>
                  <p>
                    {connector?.configured
                      ? connectorReady
                        ? '课程、考试、成绩、实践、校园卡与预约'
                        : connector.credentialsConfigured === false
                          ? '登录后即可使用校园资料'
                          : '暂时无法连接校园资料'
                      : '课程、考试、成绩与实践'}
                  </p>
                </div>
                <button
                  className="subtle-button"
                  disabled={disabled}
                  onClick={() =>
                    void perform('connector', async () => {
                      onState(await api.configureCampusConnector());
                      setFeedback({ action: 'connector', text: '校园资料已连接' });
                    })
                  }
                >
                  {pending === 'connector' ? (
                    <LoaderCircle size={14} className="spin" />
                  ) : connector?.configured ? (
                    '更换'
                  ) : (
                    '连接'
                  )}
                </button>
              </div>
              {connector?.configured && !connectorReady && (
                <details className="connector-more">
                  <summary>连接设置</summary>
                  <div className="connector-actions" role="group" aria-label="校园资料连接设置">
                    <button
                      className="connector-action"
                      disabled={disabled}
                      onClick={() =>
                        void perform('credentials', async () => {
                          onState(await api.configureCampusCredentials());
                          setFeedback({ action: 'credentials', text: '登录信息已更新' });
                        })
                      }
                    >
                      {connector.credentialsConfigured === false ? '设置登录信息' : '更新登录信息'}
                    </button>
                    <button
                      className="connector-action connector-action-danger"
                      disabled={disabled}
                      onClick={() =>
                        void perform('connector-disconnect', async () => {
                          onState(await api.disconnectCampusConnector());
                          setFeedback({ action: 'connector-disconnect', text: '校园资料已断开' });
                        })
                      }
                    >
                      断开连接
                    </button>
                  </div>
                </details>
              )}
            </section>
            {result(['connector', 'connector-disconnect', 'credentials'])}
            {(!connectorReady || !connector?.configured || !state.campus) && (
              <section className="campus-import-block">
                <div className="connector">
                  <div>
                    <strong>导入资料</strong>
                    <p>课程、考试与校园资料</p>
                  </div>
                  <button
                    className="subtle-button"
                    disabled={disabled}
                    onClick={() =>
                      void perform('import', async () => {
                        const next = await api.importCampus();
                        if (next) {
                          onState(next);
                          setFeedback({ action: 'import', text: '资料已导入' });
                        }
                      })
                    }
                  >
                    {pending === 'import' ? (
                      <LoaderCircle size={14} className="spin" />
                    ) : state.campus ? (
                      '更新'
                    ) : (
                      '导入'
                    )}
                  </button>
                </div>
                {state.campus && (
                  <small className="campus-import-state">
                    已导入 · 更新于 {date(state.campus.updatedAt)}
                  </small>
                )}
                <details className="campus-more">
                  <summary>更多资料操作</summary>
                  <div className="field-buttons">
                    <button
                      className="text-button"
                      disabled={disabled}
                      onClick={() =>
                        void perform('template', async () => {
                          if (await api.campusTemplate())
                            setFeedback({ action: 'template', text: '模板已保存' });
                        })
                      }
                    >
                      <Download size={14} />
                      下载导入模板
                    </button>
                    {state.campus && (
                      <button
                        className="text-button"
                        disabled={disabled}
                        onClick={() =>
                          void perform('disconnect', async () => {
                            onState(await api.disconnectCampus());
                            setFeedback({ action: 'disconnect', text: '资料已移除' });
                          })
                        }
                      >
                        移除资料
                      </button>
                    )}
                  </div>
                </details>
              </section>
            )}
            <Switch
              checked={state.settings.weatherEnabled}
              onChange={(v) => void update('weather', { weatherEnabled: v })}
              label="杭州天气"
              detail="使用杭州城市参考坐标，不代表你的精确位置"
              disabled={!!pending || (busy && !state.settings.weatherEnabled)}
            />
            {result(['weather'])}
          </>
        )}
        {tab === '记忆' && <MemoryPanelSimple state={state} onState={onState} busy={busy} />}
        {tab === '偏好' && (
          <>
            <p className="panel-intro">决定在场何时提醒你，以及怎样回应你的请求。</p>
            <section className="preference-section">
              <h3 className="section-title">提醒</h3>
              <Switch
                checked={state.settings.remindersEnabled}
                onChange={(v) => void update('reminders', { remindersEnabled: v })}
                label="提醒安排"
                detail="仅在应用运行时提醒已设定时间的安排"
                disabled={!!pending || (busy && !state.settings.remindersEnabled)}
              />
              {result(['reminders'])}
            </section>
            <section className="preference-section">
              <h3 className="section-title">回复方式</h3>
              <label className="field-label behavior-label">
                回复偏好
                <textarea
                  value={guidance}
                  onChange={(e) => {
                    setGuidance(e.target.value);
                    draft.current.guidance = e.target.value;
                  }}
                  rows={3}
                  maxLength={4000}
                  placeholder="例如：说话简短一些，保留晚上的休息时间"
                />
              </label>
              <div className="field-buttons">
                <button
                  className="primary-button"
                  disabled={disabled || guidance === state.settings.guidance}
                  onClick={() =>
                    void perform('guidance', async () => {
                      onState(await api.saveSettings({ guidance }));
                      setFeedback({ action: 'guidance', text: '回复偏好已保存' });
                    })
                  }
                >
                  {pending === 'guidance' && <LoaderCircle size={14} className="spin" />}保存偏好
                </button>
                {guidance !== state.settings.guidance && <small className="setting-hint">未保存的修改</small>}
              </div>
              {result(['guidance'])}
            </section>
            <details className="data-controls">
              <summary className="section-title">本地资料与导出</summary>
              <div className="data-controls-body">
                <p>对话保存在本机；连接模型时，会发送本轮允许使用的资料。数据库暂未整体加密。</p>
                <button
                  className="text-button"
                  disabled={disabled}
                  onClick={() =>
                    void perform('export', async () => {
                      if (await api.exportData()) setFeedback({ action: 'export', text: '资料已导出' });
                    })
                  }
                >
                  {pending === 'export' ? (
                    <LoaderCircle size={14} className="spin" />
                  ) : (
                    <Download size={15} />
                  )}
                  导出我的资料
                </button>
                {result(['export'])}
                {clearConfirm ? (
                  <div className="clear-confirm">
                    <p>确定清空本机资料？这会删除对话、记忆、安排、校园资料和连接密钥，且无法撤销</p>
                    <button
                      className="danger-button"
                      disabled={disabled}
                      onClick={() =>
                        void perform('clear', async () => {
                          onState(await api.clearData());
                          draft.current = {};
                          onClear();
                          notify('本地资料已清空');
                        })
                      }
                    >
                      确认清空
                    </button>
                    <button className="text-button" onClick={() => setClearConfirm(false)}>
                      取消
                    </button>
                  </div>
                ) : (
                  <button
                    className="text-button danger-text"
                    disabled={disabled}
                    onClick={() => setClearConfirm(true)}
                  >
                    <Trash2 size={14} />
                    清空本地资料
                  </button>
                )}
                {result(['clear'])}
              </div>
            </details>
          </>
        )}
      </div>
    </Modal>
  );
}

import {
  app,
  BrowserWindow,
  clipboard,
  dialog,
  ipcMain,
  Menu,
  net,
  Notification,
  protocol,
  safeStorage,
  session,
  shell,
} from 'electron';
import { mkdirSync, existsSync, readFileSync, writeFileSync, unlinkSync, statSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { z } from 'zod';
import { Store } from './store';
import { Harness } from './harness';
import { ZjuAdapter } from './zjuAdapter';
import { CampusMapAdapter } from './mapService';
import { MapLocationProvider } from './mapLocation';
const mapLocation = new MapLocationProvider();
import { DeepSeekClient, friendlyError } from './provider';
import { actionSchema, campusSchema, settingsSchema } from '../shared/schemas';
import type { Settings } from '../shared/types';
import campusExample from '../../examples/campus.example.json';
import { LIMITS } from '../shared/limits';
import { assertTestDataDirectory } from './testBoundary';
import { isEphemeral } from './runtime/policy';
import { conditionSchema } from '../shared/harness';
import { hasCredentials } from './runtime/redaction';
import { NativeControls } from './runtime/controls';

assertTestDataDirectory();

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },
]);
// Explicit profile override also makes packaged verification independent of personal data.
if (process.env.ZAICHANG_DATA_DIR) app.setPath('userData', path.resolve(process.env.ZAICHANG_DATA_DIR));
app.setName('在场');
let window: BrowserWindow | undefined,
  store: Store,
  harness: Harness,
  zju: ZjuAdapter,
  map: CampusMapAdapter,
  keyPath = '';
let closing = false;
let connectionController: AbortController | undefined;
function getKey() {
  if (!existsSync(keyPath)) return '';
  try {
    return safeStorage.decryptString(readFileSync(keyPath));
  } catch {
    return '';
  }
}
function saveKey(key: string) {
  if (
    !safeStorage.isEncryptionAvailable() ||
    (process.platform === 'linux' && safeStorage.getSelectedStorageBackend() === 'basic_text')
  )
    throw new Error('系统密钥保护暂不可用，API Key 未保存。');
  writeFileSync(keyPath, safeStorage.encryptString(key), { mode: 0o600 });
}
function deleteKey() {
  if (existsSync(keyPath)) unlinkSync(keyPath);
}
function state() {
  return { ...store.state(!!getKey()), campusConnector: zju.describe() };
}
function trusted(event: Electron.IpcMainInvokeEvent | Electron.IpcMainEvent) {
  if (!window || event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame)
    throw new Error('无效的请求来源。');
  const url = new URL(event.senderFrame.url);
  if (
    !(url.protocol === 'app:' && url.hostname === 'zaichang') &&
    !(process.env.ZAICHANG_DEV === '1' && url.origin === 'http://127.0.0.1:5173')
  )
    throw new Error('无效的请求来源。');
}
function handle(name: string, fn: (data: any) => unknown | Promise<unknown>) {
  ipcMain.handle(name, async (event, data) => {
    trusted(event);
    try {
      return await fn(data);
    } catch (error) {
      if (error instanceof z.ZodError) throw new Error('请检查填写内容、长度和时间格式后重试。');
      throw error;
    }
  });
}
function noRun() {
  if (harness.running) throw new Error('请先停止当前处理，再修改连接或资料。');
}
const id = z.string().min(1).max(100);

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  const dataDir = app.getPath('userData');
  mkdirSync(dataDir, { recursive: true });
  keyPath = path.join(dataDir, 'deepseek-key.bin');
  store = new Store(path.join(dataDir, 'zaichang.sqlite'));
  zju = new ZjuAdapter(store);
  map = new CampusMapAdapter(path.join(app.getAppPath(), 'assets', 'map-v2'));
  harness = new Harness(
    store,
    getKey,
    (event) => {
      if (window && !window.isDestroyed()) window.webContents.send('zaichang:event', event);
    },
    undefined,
    zju,
    map,
  );
  const controls = new NativeControls(store, harness);
  handle('runtime:overview', () => controls.overview());
  handle('runtime:adopt-world', (value) => controls.adoptWorld(value));
  handle('runtime:evidence', (value) => controls.evidence(value));
  handle('runtime:goal', (value) => controls.goal(value));
  handle('runtime:feedback', (value) => controls.feedback(value));
  handle('runtime:retry', (value) => controls.retry(value));
  handle('runtime:reconcile', (value) => controls.reconcile(value));
  handle('runtime:action', (value) => {
    const actionId = id.parse(value),
      scope = store.runtime.policy.hostScope();
    return {
      action: store.runtime.actions.get(scope, actionId) || null,
      receipts: store.runtime.actions.receipts(scope, actionId),
    };
  });
  handle('runtime:permission', (value) => controls.permission(value));
  const root = path.join(app.getAppPath(), 'dist');
  protocol.handle('app', (request) => {
    const url = new URL(request.url);
    if (url.hostname !== 'zaichang') return new Response('Forbidden', { status: 403 });
    let decoded: string;
    try {
      decoded = decodeURIComponent(url.pathname);
    } catch {
      return new Response('Invalid path', { status: 400 });
    }
    const file = path.resolve(root, '.' + (decoded === '/' ? '/index.html' : decoded));
    if (!file.startsWith(root + path.sep) || !existsSync(file) || !statSync(file).isFile())
      return new Response('Not found', { status: 404 });
    return net.fetch(pathToFileURL(file).toString());
  });
  session.defaultSession.setPermissionRequestHandler((_w, _permission, callback) => callback(false));
  session.defaultSession.setPermissionCheckHandler(() => false);
  handle('state', state);
  handle('messages', (value) => store.messages(id.parse(value)));
  handle('draft', (value) => store.meta('draft:' + id.parse(value), { text: '', attachment: null }));
  handle('draft:save', (value) => {
    const input = z
      .object({
        id,
        retention: z.literal('session_only').optional(),
        draft: z.object({
          text: z.string().max(LIMITS.draftText),
          attachment: z
            .object({ name: z.string().max(LIMITS.fileName), text: z.string().max(LIMITS.attachmentText) })
            .nullable(),
        }),
      })
      .parse(value);
    if (
      input.retention === 'session_only' ||
      isEphemeral(input.draft.text) ||
      hasCredentials(input.draft.text) ||
      (input.draft.attachment && hasCredentials(input.draft.attachment.text))
    ) {
      store.db.prepare('DELETE FROM meta WHERE key=?').run('draft:' + input.id);
      store.kernel.checkpointPrivacy();
      return;
    }
    store.putMeta('draft:' + input.id, input.draft);
  });
  handle('send', (value) => {
    const input = z
      .object({
        sessionId: id.optional(),
        content: z.string().trim().min(1).max(LIMITS.message),
        controls: z
          .object({
            memoryMode: z.enum(['relevant', 'current_sources_only', 'session_only', 'none']).optional(),
            retention: z.enum(['purpose_scoped', 'history_no_inference', 'session_only']).optional(),
            audience: z.enum(['self', 'group', 'public']).optional(),
          })
          .strict()
          .optional(),
      })
      .strict()
      .parse(value);
    return harness.start(input.sessionId, input.content, input.controls);
  });
  handle('stop', () => harness.stop());
  handle('settings:save', (value) => {
    const { apiKey, ...settings } = settingsSchema.parse(value);
    const disablingOnly =
      !apiKey &&
      Object.entries(settings).every(
        ([key, val]) =>
          ['memoryEnabled', 'weatherEnabled', 'remindersEnabled'].includes(key) && val === false,
      );
    if (!disablingOnly) noRun();
    if (settings.mode === 'deepseek' && !(apiKey || getKey()))
      throw new Error('先填写 DeepSeek API Key，再开始连接。');
    if (apiKey) saveKey(apiKey);
    store.saveSettings(settings as Partial<Settings>);
    return state();
  });
  handle('connection:test', async (value) => {
    noRun();
    const input = z
      .object({
        apiKey: z.string().trim().max(512).optional(),
        model: z
          .string()
          .regex(/^deepseek-[a-z0-9.-]+$/)
          .max(80),
      })
      .parse(value);
    connectionController?.abort();
    const controller = new AbortController();
    connectionController = controller;
    try {
      await new DeepSeekClient(input.apiKey || getKey(), input.model).complete(
        [{ role: 'user', content: '请只回复：连接成功。' }],
        [],
        AbortSignal.any([controller.signal, AbortSignal.timeout(20000)]),
      );
      return 'DeepSeek 已响应。';
    } catch (e) {
      throw new Error(friendlyError(e));
    } finally {
      if (connectionController === controller) connectionController = undefined;
    }
  });
  handle('connection:cancel', () => {
    connectionController?.abort();
  });
  handle('key:delete', () => {
    noRun();
    deleteKey();
    store.saveSettings({ mode: 'demo' });
    return state();
  });
  handle('memory', (value) => {
    const input = z
      .object({
        action: z.enum(['save', 'delete', 'deactivate']),
        id: id.optional(),
        text: z.string().trim().min(1).max(4000).optional(),
        expectedRevision: z.number().int().positive().optional(),
        operation: z.enum(['CORRECT', 'SUPERSEDE', 'ADD_EXCEPTION', 'REFINE']).optional(),
        validFrom: z.string().datetime({ offset: true }).optional(),
        validTo: z.string().datetime({ offset: true }).optional(),
        conditions: conditionSchema.optional(),
      })
      .parse(value);
    if (input.action === 'delete' && input.id) store.deleteMemory(input.id);
    else if (input.action === 'deactivate' && input.id) store.runtime.memory.deactivate(input.id);
    else if (input.action === 'save' && input.text)
      store.runtime.memory.saveControl(input.text, input.id, input);
    else throw new Error('请填写记忆内容。');
    return state();
  });
  handle('conversation:delete', (value) => {
    noRun();
    const sessionId = id.parse(value);
    store.deleteSession(sessionId);
    harness.invalidateCampusCache(sessionId);
    return state();
  });
  handle('data:clear', () => {
    noRun();
    store.clear();
    deleteKey();
    harness.invalidateCampusCache();
    return state();
  });
  handle('campus:import', async () => {
    noRun();
    const result = await dialog.showOpenDialog(window!, {
      title: '导入校园资料',
      filters: [{ name: '校园资料 JSON', extensions: ['json'] }],
      properties: ['openFile'],
    });
    if (result.canceled) return null;
    const file = result.filePaths[0];
    if (statSync(file).size > 8_000_000) throw new Error('资料文件过大，请使用 8 MB 以内的 JSON 文件。');
    let parsed: unknown;
    try {
      parsed = JSON.parse(readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
    } catch {
      throw new Error('这不是有效的 JSON 文件。');
    }
    const data = campusSchema.safeParse(parsed);
    if (!data.success)
      throw new Error('资料格式不匹配：请包含来源、更新时间和含时区的逐次日程。项目 examples 中有模板。');
    // Last occurrence wins when an exported event is rescheduled or cancelled.
    data.data.schedule = [...new Map(data.data.schedule.map((e) => [e.id, e])).values()];
    data.data.exams = [...new Map(data.data.exams.map((e) => [e.id, e])).values()];
    store.runtime.domains.importSnapshot(data.data, Object.keys(parsed as object));
    harness.invalidateCampusCache();
    return state();
  });
  handle('campus:disconnect', () => {
    noRun();
    store.putMeta('campus', null);
    harness.invalidateCampusCache();
    return state();
  });
  handle('campus:template', async () => {
    const result = await dialog.showSaveDialog(window!, {
      title: '保存校园资料模板',
      defaultPath: '校园资料-格式示例.json',
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });
    if (result.canceled || !result.filePath) return false;
    writeFileSync(result.filePath, JSON.stringify(campusExample, null, 2), 'utf8');
    return true;
  });
  handle('campus:connector:configure', async () => {
    noRun();
    const result = await dialog.showOpenDialog(window!, {
      title: '选择浙大个人信息连接器目录',
      properties: ['openDirectory'],
    });
    if (result.canceled || !result.filePaths[0]) return state();
    zju.configure(result.filePaths[0]);
    harness.invalidateCampusCache();
    return state();
  });
  handle('campus:connector:disconnect', () => {
    noRun();
    zju.disconnect();
    harness.invalidateCampusCache();
    return state();
  });
  handle('campus:connector:credentials', async () => {
    noRun();
    await zju.configureCredentials();
    harness.invalidateCampusCache();
    return state();
  });
  handle('map:overview', () => map.overview());
  handle('map:search', (value) => {
    const input = z
      .object({ query: z.string().trim().min(1).max(100), limit: z.number().int().min(1).max(50).optional() })
      .parse(value);
    return map.search(input.query, input.limit || 20);
  });
  handle('map:location-status', () => map.locationStatus());
  handle('map:locate', () => mapLocation.read(map.overview()));
  handle('map:location-stop', () => mapLocation.cancel());
  handle('map:route', (value) => {
    const place = z.object({ kind: z.enum(['place', 'node']), id: z.string().min(1).max(100) });
    const input = z
      .object({
        from: z.union([place, z.object({ kind: z.literal('current') })]).optional(),
        to: place.optional(),
        avoidStairs: z.boolean().optional(),
        version: z.string().max(100).optional(),
      })
      .parse(value);
    return map.route(input);
  });
  handle('action', async (value) => {
    const input = z.object({ action: z.enum(['save', 'delete', 'done']), item: actionSchema }).parse(value);
    if (input.action === 'delete') {
      await store.runtime.actions.cancel(store.runtime.policy.hostScope(), input.item.id);
      store.deleteAction(input.item.id);
    } else
      await store.runtime.acceptLocal({ ...input.item, done: input.action === 'done' || input.item.done });
    return state();
  });
  handle('text:attach', async () => {
    const result = await dialog.showOpenDialog(window!, {
      title: '添加文字资料',
      filters: [{ name: '文字或 Markdown', extensions: ['txt', 'md'] }],
      properties: ['openFile'],
    });
    if (result.canceled) return null;
    const file = result.filePaths[0];
    if (statSync(file).size > 100_000) throw new Error('请选取 100 KB 以内的文字资料。');
    const text = readFileSync(file, 'utf8');
    if (text.length > LIMITS.attachmentText)
      throw new Error('这份文字太长，请先摘出 20,000 字以内的相关内容。');
    return { name: path.basename(file), text };
  });
  handle('data:export', async () => {
    const result = await dialog.showSaveDialog(window!, {
      title: '导出我的资料',
      defaultPath: '在场-我的资料.json',
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });
    if (result.canceled || !result.filePath) return false;
    writeFileSync(result.filePath, JSON.stringify(store.export(), null, 2), 'utf8');
    return true;
  });
  handle('link:open', async (value) => {
    const url = new URL(z.string().max(2500).parse(value));
    if (url.protocol !== 'https:' || url.username || url.password || !url.hostname)
      throw new Error('仅支持打开安全的 HTTPS 来源链接。');
    await shell.openExternal(url.toString());
  });
  handle('text:copy', (value) => {
    clipboard.writeText(z.string().max(100000).parse(value));
  });
  ipcMain.on('window', (event, value) => {
    trusted(event);
    if (value === 'close') window?.close();
    if (value === 'minimize') window?.minimize();
    if (value === 'maximize') window?.isMaximized() ? window.unmaximize() : window?.maximize();
  });
  window = new BrowserWindow({
    title: '在场',
    width: 1220,
    height: 850,
    minWidth: 680,
    minHeight: 570,
    backgroundColor: '#171918',
    frame: false,
    show: false,
    icon: path.join(app.getAppPath(), 'build/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
    },
  });
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event) => event.preventDefault());
  window.once('ready-to-show', () => window?.show());
  window.on('close', (event) => {
    if (!closing && harness.running) {
      event.preventDefault();
      closing = true;
      void harness.stop().finally(() => window?.close());
    }
  });
  window.on('closed', () => {
    window = undefined;
  });
  await window.loadURL(
    process.env.ZAICHANG_DEV === '1' ? 'http://127.0.0.1:5173' : 'app://zaichang/index.html',
  );
  store.runtime.reminders.port = {
    capabilities: {
      submitted: Notification.isSupported(),
      delivered: false,
      seen: false,
      stableId: false,
      closedApp: false,
    },
    submit: async (input, signal) => {
      signal.throwIfAborted();
      const notice = new Notification({ title: input.title, body: input.body, silent: true });
      notice.on('click', () => {
        window?.restore();
        window?.show();
        window?.focus();
      });
      notice.show();
      return { status: 'submitted_to_os' };
    },
  };
  store.runtime.reminders.configure({ enabled: store.settings().remindersEnabled });
  const reminderTimer = setInterval(() => {
    void store.runtime.reminders.runDue();
  }, 30000);
  const recoveryTimer = setInterval(() => {
    if (process.env.ZAICHANG_TEST !== '1') void harness.recoverPending();
  }, 30000);
  void store.runtime.reminders.runDue();
  app.on('will-quit', () => {
    clearInterval(reminderTimer);
    clearInterval(recoveryTimer);
    store.close();
  });
});
app.on('window-all-closed', () => app.quit());

app.on('before-quit', () => mapLocation.cancel());

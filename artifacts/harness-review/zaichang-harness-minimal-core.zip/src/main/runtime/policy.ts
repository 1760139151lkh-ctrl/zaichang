import { randomUUID } from 'node:crypto';
import {
  HarnessError,
  type ContextContract,
  type ScopeData,
  type ScopeHandle,
  type InterpretationProposal,
  type RequestFragment,
} from '../../shared/harness';
import type { KernelRepository } from '../storage/repository';
import { addDate, dateInZone, resolveLocalTime } from './semantics';
import { authoredControls, routeSpeechActs, type SpeechAct } from './discourse';
import { hasCredentials } from './redaction';

export interface InputControls {
  memoryMode?: ContextContract['memoryMode'];
  retention?: ContextContract['retention'];
  audience?: ContextContract['audience'];
  sources?: string[];
  subjectId?: string;
  worldId?: string;
  timeZone?: string;
  attachment?: { id: string; name: string; text: string };
  purpose?: string;
  budget?: Partial<ContextContract['budget']>;
}
export interface IngressDecision {
  text: string;
  authoredText: string;
  attachment?: { id: string; name: string; text: string };
  contract: ContextContract;
  restriction: boolean;
  scenario: boolean;
  corrections: string[];
  speechActs: SpeechAct[];
  interpretation: InterpretationProposal;
  requestFragments: RequestFragment[];
  localOnly: boolean;
}
const baseSources = [
  'current',
  'history:self',
  'profile:self',
  'work:self',
  'local-agenda',
  'campus:local',
  'map:local',
];

/**
 * Build a small host-side interpretation proposal from source spans.  This is
 * intentionally only a routing hint: it never creates a grant and every
 * subsequent read/write still passes through ScopeHandle validation.
 */
function proposeInterpretation(
  text: string,
  eventId: string,
  principalId: string,
  audience: ContextContract['audience'],
  listenRequested: boolean,
  otherMentioned: boolean,
  fictionalMentioned: boolean,
  scenarioMentioned: boolean,
) {
  const allSelf = /(?:^|[，。；\n])\s*(?:我|我的|本人)/.test(text) || /(?:我的|我本人)/.test(text);
  const rootSubject = otherMentioned && !allSelf
    ? 'other:' + eventId
    : fictionalMentioned && !allSelf
      ? 'fictional:' + eventId
      : principalId;
  const rootWorld = scenarioMentioned && !/(?:现实中|实际上|我(?:要|会|的))/.test(text)
    ? 'scenario:' + eventId
    : 'real';
  const acts = routeSpeechActs(text, principalId, rootSubject, rootWorld, 'other:' + eventId);
  const points = Array.from(text);
  const indexed = acts.map((act, index) => ({ act, index }));
  // Keep the proposal bounded without dropping end-of-message restrictions.
  const selected = indexed.length <= 64 ? indexed : [...indexed.slice(0, 32), ...indexed.slice(-32)];
  const fragments: RequestFragment[] = selected.map(({ act, index }) => {
    const clause = points.slice(act.startCodePoint, act.endCodePoint).join('');
    const localWrite = /(?:顺手|帮我|请帮我|麻烦(?:你)?|记(?:一下|到|在)|登记|加到(?:我的)?(?:安排|日程|待办)|放进(?:我的)?(?:安排|日程|待办)|提醒我|设个提醒|加入日程)/.test(
      clause,
    ) && /(?:会|会议|讨论|事项|安排|日程|待办|提醒|活动|预约|记一下|记到)/.test(clause);
    const retrieve = /(?:查(?:一下|下)?|查询|看看|看一下|读一下|问问|课表|课程|考试|成绩|绩点|校园卡|天气|路线|导航|空闲|有空)/.test(
      clause,
    );
    const hypothesis =
      !localWrite && (act.worldId !== 'real' || /假设|假如|反事实|如果|虚构|假想/.test(clause));
    const correction = /说错|记错|更正|不是.*是|其实/.test(clause);
    const listen = /只是.*(?:吐槽|聊聊)|先(?:让我|听我)(?:吐槽|说|讲)|先别给建议|别(?:给我)?(?:做|排|提).*?(?:计划|建议)|不(?:要)?(?:立刻|马上)?做完整计划|只想.*(?:倾听|吐槽)|不要(?:急着)?安慰/.test(
      clause,
    ) || (listenRequested && !localWrite && !retrieve && !hypothesis);
    const plan = !listen && /安排|下一步|接下来|比较|规划|方案|路线|怎么走|去哪/.test(clause);
    const intents = new Set<RequestFragment['intents'][number]>();
    if (listen) {
      intents.add('listen');
      intents.add('reflect');
    }
    if (localWrite) intents.add('record_local');
    if (retrieve) intents.add('retrieve');
    if (plan) intents.add('plan');
    if (hypothesis) intents.add('hypothesis');
    if (correction) intents.add('correction');
    if (act.kind === 'quote') intents.add('quote');
    if (!intents.size) intents.add('other');
    const constraints = [
      ...(/别(?:给我)?(?:做|排|提).*?(?:计划|建议)/.test(clause) ? ['no_unsolicited_plan'] : []),
      ...(/先别.*(?:保存|发送|执行)|只.*草稿|不要执行/.test(clause) ? ['no_effect'] : []),
      ...(/地点.*(?:先别|未知|不填)/.test(clause) ? ['location_unknown'] : []),
    ];
    const unresolvedReferences = [...clause.matchAll(/(?:刚才|之前|那个|这个|它|他|她|第二个)/g)].map(
      (m) => m[0],
    );
    const readSources: RequestFragment['readSources'] = retrieve
      ? [
          ...(/课表|课程|考试|成绩|绩点|校园卡|学校|校园|教室|空闲|有空/.test(clause) ? (['campus'] as const) : []),
          ...(/天气|下雨|预报|温度/.test(clause) ? (['weather'] as const) : []),
          ...(/地图|路线|导航|怎么走|位置|地点/.test(clause) ? (['map'] as const) : []),
          ...(/安排|日程|待办|提醒/.test(clause) && !localWrite ? (['local'] as const) : []),
          ...(/之前|以前|上次|历史|记得/.test(clause) ? (['history'] as const) : []),
        ]
      : [];
    return {
      id: eventId.slice(0, 140) + ':fragment-' + index,
      startCodePoint: act.startCodePoint,
      endCodePoint: act.endCodePoint,
      text: clause,
      subjectId: act.subjectId,
      worldId: hypothesis ? (act.worldId === 'real' ? 'scenario:' + eventId : act.worldId) : 'real',
      intents: [...intents],
      readSources: [...new Set(readSources)],
      participation: listen ? 'listen' : localWrite ? 'act' : retrieve ? 'analyze' : plan ? 'analyze' : undefined,
      audience,
      constraints,
      unresolvedReferences,
      confidence:
        unresolvedReferences.length ||
        (localWrite && !/(?:今天|今晚|明天|明晚|明早|后天|下周|周[一二三四五六日天]|\d+月\d+日)/.test(clause))
          ? 'ambiguous'
          : 'clear',
    } satisfies RequestFragment;
  });
  return {
    fragments,
    hasListen: fragments.some((f) => f.intents.includes('listen')),
    hasRetrieval: fragments.some((f) => f.intents.includes('retrieve')),
    explicitLocalWrite: fragments.some((f) => f.intents.includes('record_local')),
    directLocalWrite: false as boolean,
  } satisfies InterpretationProposal;
}
export class PolicyKernel {
  private scopes = new WeakMap<ScopeHandle, ScopeData>();
  private listeners = new Set<() => void>();
  constructor(readonly repo: KernelRepository) {
    repo.bindPolicy((handle) => this.validate(handle));
  }
  onBarrier(callback: () => void) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }
  signalBarrier() {
    for (const fn of this.listeners) fn();
  }
  revoked() {
    return this.repo.getMeta<string[]>('revoked', []);
  }
  grants() {
    return this.repo.getMeta<string[]>('grants', [
      'local:write',
      'evidence:read',
      'memory:write',
      'work:write',
      'campus:read',
      'map:read',
    ]);
  }
  /** Called only by trusted host UI/configuration, never a tool argument or provider response. */
  grant(scope: string) {
    this.repo.write(() => {
      this.repo.setMeta('grants', [...new Set([...this.grants(), scope])]);
      this.repo.setMeta(
        'revoked',
        this.revoked().filter((s) => s !== scope),
      );
      this.repo.setMeta('policy_revision', this.repo.policyRevision + 1);
    });
    this.repo.persistPolicyState();
    this.signalBarrier();
  }
  revoke(scope: string) {
    if (this.revoked().includes(scope) && !this.grants().includes(scope)) {
      this.signalBarrier();
      return;
    }
    this.repo.establishFence({ kind: 'revoke', objectIds: [], sourceIds: [], scope });
    this.repo.write(() => {
      this.repo.setMeta('revoked', [...new Set([...this.revoked(), scope])]);
      this.repo.setMeta(
        'grants',
        this.grants().filter((s) => s !== scope),
      );
      this.repo.invalidate('grant:' + scope, 'permission_revoked');
    });
    this.repo.persistPolicyState();
    this.repo.revalidatePrivacyJobs();
    this.signalBarrier();
  }
  hostScope(
    overrides: Partial<
      Omit<ScopeData, keyof typeof this.repo.identity | 'privacyEpoch' | 'policyRevision'>
    > = {},
  ): ScopeHandle {
    const sources = [...baseSources, ...this.repo.getMeta<string[]>('registered_sources', [])];
    const data: ScopeData = {
      ...this.repo.identity,
      subjectId: this.repo.identity.principalId,
      worldId: 'real',
      sources,
      currentEventIds: [],
      purposes: ['personal_assistance'],
      audience: 'self',
      grants: this.grants().filter((g) => !this.revoked().includes(g)),
      privacyEpoch: this.repo.epoch,
      policyRevision: this.repo.policyRevision,
      retention: 'purpose_scoped',
      infer: true,
      expiresAt: new Date(Date.parse(this.repo.clock.now()) + 240000).toISOString(),
      child: false,
      ...overrides,
    };
    return this.mint(data);
  }
  private mint(data: ScopeData): ScopeHandle {
    const handle = Object.freeze({ id: randomUUID() }) as ScopeHandle;
    this.scopes.set(
      handle,
      Object.freeze({
        ...data,
        sources: Object.freeze([...data.sources]),
        currentEventIds: Object.freeze([...data.currentEventIds]),
        purposes: Object.freeze([...data.purposes]),
        grants: Object.freeze([...data.grants]),
      }),
    );
    return handle;
  }
  validate(handle: ScopeHandle): ScopeData {
    const data = this.scopes.get(handle);
    if (!data) throw new HarnessError('forged_scope', '请求没有可信作用域。');
    if (data.privacyEpoch !== this.repo.epoch || data.policyRevision !== this.repo.policyRevision)
      throw new HarnessError('stale_scope', '资料使用范围已改变，旧处理已停止。');
    if (Date.parse(data.expiresAt) <= Date.parse(this.repo.clock.now()))
      throw new HarnessError('scope_expired', '本轮资料授权已到期。');
    return data;
  }
  narrow(
    parent: ScopeHandle,
    changes: Partial<
      Pick<ScopeData, 'sources' | 'currentEventIds' | 'purposes' | 'grants' | 'infer' | 'child' | 'expiresAt'>
    >,
  ): ScopeHandle {
    const current = this.validate(parent);
    for (const key of ['sources', 'currentEventIds', 'purposes', 'grants'] as const)
      if (changes[key]?.some((value) => !current[key].includes(value)))
        throw new HarnessError('scope_escalation', '子任务不能扩大资料使用范围。');
    if (changes.infer && !current.infer) throw new HarnessError('scope_escalation', '不能扩大推断权限。');
    if (changes.expiresAt && Date.parse(changes.expiresAt) > Date.parse(current.expiresAt))
      throw new HarnessError('scope_escalation', '不能延长授权期限。');
    return this.mint({ ...current, ...changes });
  }
  require(handle: ScopeHandle, grant: string) {
    const s = this.validate(handle);
    if (!s.grants.includes(grant) || this.revoked().includes(grant))
      throw new HarnessError('forbidden', '这项能力未获本轮授权。');
    return s;
  }
  can(handle: ScopeHandle, grant: string) {
    try {
      this.require(handle, grant);
      return true;
    } catch {
      return false;
    }
  }
  registerSource(id: string) {
    this.repo.write(() =>
      this.repo.setMeta('registered_sources', [
        ...new Set([...this.repo.getMeta<string[]>('registered_sources', []), id]),
      ]),
    );
  }
  ingress(
    text: string,
    eventId: string,
    settings: { memoryEnabled: boolean; weatherEnabled: boolean; timeZone?: string },
    controls: InputControls = {},
  ): IngressDecision {
    // Existing renderer embeds text attachments. The typed field takes precedence; the legacy boundary is conservative.
    let attachment = controls.attachment,
      authoredText = text;
    if (!attachment) {
      const marker = text.match(/\n\n\[用户附上的文字资料：([^\]]+)\]\n/);
      if (marker?.index !== undefined) {
        authoredText = text.slice(0, marker.index);
        attachment = {
          id: eventId + ':file',
          name: marker[1],
          text: text.slice(marker.index + marker[0].length),
        };
      }
    } else authoredText = text;
    const policyText = authoredControls(authoredText);
    const localOnly = hasCredentials(authoredText) || (!!attachment && hasCredentials(attachment.text));
    const temporary =
        localOnly ||
        isEphemeral(policyText) ||
        controls.memoryMode === 'session_only' ||
        controls.retention === 'session_only',
      noInference =
        /不(?:要)?(?:写进|写入|保存为|记录为|存入)?长期(?:记忆|记录)|不要记住|不用于长期|不记录这段|do not (?:remember|infer)|don't remember/i.test(
          policyText,
        );
    const sourceOnly =
      /只(?:根据|用|按|依据|看|读).*(?:附件|材料|文件|这里|当前|这份)|不(?:要)?(?:使用|带入).*(?:以前|历史|了解)|不读.*(?:记忆|历史)/.test(
        authoredText,
      ) ||
      (!!attachment && /总结|分析|翻译|材料|附件|引用/.test(authoredText)) ||
      /(?:翻译|translate|润色|改写).*(?:这段|以下|当前|:|：)/i.test(policyText) ||
      (policyText !== authoredText && /分析|总结|翻译|引用|示例/.test(policyText));
    const otherMentioned = /替(?:我)?(?:室友|同学|朋友)|代问|他的限制|给他安排|(?:室友|同学|朋友)的/.test(
      authoredText,
    );
    const fictionalMentioned = /假想|虚构|角色|产品.*画像|项目.*画像/.test(authoredText);
    const scenarioMentioned = /假设|假如|反事实|如果.*(?:搬|转专业|没通过|不参加)|先.*两套比较/.test(
      authoredText,
    );
    const audience =
      controls.audience ||
      (/给(?:小组|同学|家人|父母|朋友|老师|室友|辅导员).*?(?:写|回复|发|近况)|发到群|群(?:里|中|聊|消息|文案|公告)|投屏|公共活动|公开.*(?:版本|方案|总结)/.test(
        authoredText,
      )
        ? 'group'
        : 'self');
    const listen =
      /只是.*(?:吐槽|聊聊)|先(?:让我|听我)(?:吐槽|说|讲)|先别给建议|别(?:给我)?(?:做|排|提).*?(?:计划|建议)|不(?:要)?(?:立刻|马上)?做完整计划|只想.*(?:倾听|吐槽)|不要(?:急着)?安慰/.test(
        authoredText,
      );
    const hint = /只给(?:一|一个|个)?提示|只要提示|先.*提示|让我自己讲/.test(authoredText);
    const direct = /直接.*(?:答案|回答|告诉)|今天.*要答案/.test(authoredText);
    const clarify = /不知道想|说不清|脑子很乱|既想.*又怕|不确定.*怎么/.test(authoredText);
    const plan = /安排|下一步|接下来|比较|规划|怎么走|路线|怎么去|去哪/.test(authoredText);
    const exploration = /不.*按.*(?:以前|旧|历史|习惯)|试试.*不一样|探索|以前的自己不会选|和平时不一样/.test(
      authoredText,
    );
    const purpose =
      controls.purpose ||
      (audience !== 'self' ? 'outbound_draft' : sourceOnly ? 'analyze_document' : 'personal_assistance');
    const retention = temporary
      ? 'session_only'
      : controls.retention || (noInference ? 'history_no_inference' : 'purpose_scoped');
    let restriction = false;
    if (/(?:撤回|撤销|停止使用|禁用).*定位|别用.*位置/.test(policyText)) {
      this.revoke('location:read');
      restriction = true;
    }
    if (/(?:撤回|撤销|停止使用).*健康|别用健康数据/.test(policyText)) {
      this.revoke('health:use');
      restriction = true;
    }
    if (/(?:撤回|撤销|停止).*外发|不再.*发送权限/.test(policyText)) {
      this.revoke('external:send');
      restriction = true;
    }
    const interpretation = proposeInterpretation(
      authoredText,
      eventId,
      this.repo.identity.principalId,
      audience,
      listen,
      otherMentioned,
      fictionalMentioned,
      scenarioMentioned,
    );
    const speechActs = routeSpeechActs(
      authoredText,
      this.repo.identity.principalId,
      this.repo.identity.principalId,
      'real',
      'other:' + eventId,
    );
    const selfFragments = interpretation.fragments.filter((f) => f.subjectId === this.repo.identity.principalId);
    // Keep a clearly other-subject task as the root when the owner only adds a
    // side comment.  An explicit owner-local write promotes the root to self
    // so the action can be checked and committed in the owner's scope.
    const other =
      interpretation.fragments.length > 0 &&
      otherMentioned &&
      (!interpretation.explicitLocalWrite || selfFragments.length === 0);
    const fictional =
      interpretation.fragments.length > 0 &&
      fictionalMentioned &&
      (!interpretation.explicitLocalWrite || selfFragments.length === 0);
    const scenario =
      interpretation.fragments.length > 0 &&
      interpretation.fragments.every((f) => f.worldId !== 'real') &&
      scenarioMentioned;
    const worldId = controls.worldId || (scenario ? 'scenario:' + eventId : 'real');
    const subjectId =
      controls.subjectId ||
      (other ? 'other:' + eventId : fictional ? 'fictional:' + eventId : this.repo.identity.principalId);
    interpretation.directLocalWrite =
      interpretation.explicitLocalWrite &&
      interpretation.fragments.some(
        (f) =>
          f.intents.includes('record_local') &&
          f.subjectId === this.repo.identity.principalId &&
          f.worldId === 'real' &&
          f.audience === 'self' &&
          f.confidence === 'clear' &&
          !f.unresolvedReferences.length &&
          !f.constraints.includes('no_effect'),
      ) &&
      (!controls.subjectId || controls.subjectId === this.repo.identity.principalId) &&
      (!controls.worldId || controls.worldId === 'real') &&
      !temporary &&
      !sourceOnly &&
      !scenario;
    const requestedReadSources = new Set(
      interpretation.fragments
        .filter(
          (f) =>
            f.intents.includes('retrieve') &&
            f.subjectId === this.repo.identity.principalId &&
            f.worldId === 'real',
        )
        .flatMap((f) => f.readSources),
    );
    const memoryMode = temporary
      ? 'session_only'
      : controls.memoryMode ||
        (sourceOnly || other || fictional || otherMentioned || fictionalMentioned || scenarioMentioned || audience !== 'self'
          ? 'current_sources_only'
          : !settings.memoryEnabled
            ? 'none'
            : 'relevant');
    let sources =
      memoryMode === 'current_sources_only' || other || fictional || otherMentioned || fictionalMentioned || scenarioMentioned || audience !== 'self'
        ? ['current']
        : baseSources.filter((s) => settings.memoryEnabled || (s !== 'profile:self' && s !== 'history:self'));
    if (memoryMode === 'none')
      sources = sources.filter((source) => !['profile:self', 'history:self', 'work:self'].includes(source));
    if (listen)
      sources = sources.filter(
        (source) =>
          source === 'current' ||
          (requestedReadSources.has('history') && ['history:self', 'profile:self'].includes(source)) ||
          (requestedReadSources.has('local') && source === 'local-agenda') ||
          (requestedReadSources.has('campus') && source.startsWith('campus')) ||
          (requestedReadSources.has('map') && source.startsWith('map')),
      );
    if (
      settings.weatherEnabled &&
      (!listen || requestedReadSources.has('weather')) &&
      !sourceOnly &&
      !other &&
      audience === 'self'
    )
      sources.push('weather:open-meteo');
    if (memoryMode === 'relevant') sources.push(...this.repo.getMeta<string[]>('registered_sources', []));
    if (controls.sources) sources = sources.filter((s) => controls.sources!.includes(s));
    const timeZone = controls.timeZone || settings.timeZone || 'Asia/Shanghai',
      now = this.repo.clock.now(),
      today = dateInZone(now, timeZone);
    const resolvedDates = [
      ...(/今天/.test(authoredText) ? [today] : []),
      ...(/明天/.test(authoredText) ? [addDate(today, 1)] : []),
      ...(/昨天/.test(authoredText) ? [addDate(today, -1)] : []),
    ];
    const temporalAmbiguities: string[] = [];
    const local = authoredText.match(
      /(20\d{2})年(\d{1,2})月(\d{1,2})日(?:凌晨|上午|下午|晚上)?(\d{1,2})点(?:(\d{1,2})分)?/,
    );
    if (local) {
      const stamp = `${local[1]}-${local[2].padStart(2, '0')}-${local[3].padStart(2, '0')}T${local[4].padStart(2, '0')}:${(local[5] || '00').padStart(2, '0')}:00`;
      const result = resolveLocalTime(stamp, timeZone);
      if (result.status !== 'resolved')
        temporalAmbiguities.push(result.status + ':' + stamp + ':' + timeZone);
    }
    if (
      /下周.*搬|下周.*开始/.test(authoredText) &&
      !/(?:\d+月\d+日|星期[一二三四五六日天])/.test(authoredText)
    )
      temporalAmbiguities.push('unresolved_future_date');
    const currentEventIds = [eventId, ...(attachment ? [attachment.id] : [])];
    // Listen is a participation posture, not a blanket capability denial.
    // Only source-anchored, owner/real, explicitly requested reads and local
    // writes can survive it; memory/work/external grants remain excluded.
    const allowListenRead = interpretation.hasRetrieval &&
      interpretation.fragments.some(
        (f) => f.intents.includes('retrieve') && f.subjectId === this.repo.identity.principalId && f.worldId === 'real',
      );
    const allowListenLocal = interpretation.directLocalWrite;
    const hasHypothesis = interpretation.fragments.some((f) => f.intents.includes('hypothesis'));
    const grants = this.grants().filter(
      (g) =>
        !this.revoked().includes(g) &&
        (!listen ||
          ['evidence:read'].includes(g) ||
          (allowListenRead &&
            ((g === 'campus:read' && requestedReadSources.has('campus')) ||
              (g === 'map:read' && requestedReadSources.has('map')) ||
              (g === 'weather:read' && requestedReadSources.has('weather')))) ||
          (allowListenLocal && g === 'local:write')) &&
        ((!other && !fictional && !scenario && !hasHypothesis) || g === 'evidence:read' || (interpretation.directLocalWrite && g === 'local:write')) &&
        (audience === 'self' || g === 'evidence:read') &&
        (!sourceOnly || g === 'evidence:read'),
    );
    // Campus-wide read consent is narrowed to the sensitive domain explicitly requested in this trusted input.
    const broadCampus = /全部.*校园资料|所有.*校园资料|完整.*校园资料|校园资料总览/.test(policyText);
    if (
      grants.includes('campus:read') &&
      (!listen || allowListenRead) &&
      !other &&
      !fictional &&
      !otherMentioned &&
      !fictionalMentioned &&
      !scenarioMentioned &&
      !sourceOnly &&
      audience === 'self'
    ) {
      const requested: Record<string, boolean> = {
        grades: /成绩|成绩单/.test(policyText) || broadCampus,
        gpa: /绩点|gpa/i.test(policyText) || broadCampus,
        card: /校园卡|饭卡|卡.*余额/.test(policyText) || broadCampus,
        transactions: /流水|消费记录/.test(policyText) || broadCampus,
        profile: /我的个人资料|学生资料/.test(policyText) || broadCampus,
      };
      for (const [domain, wanted] of Object.entries(requested))
        if (wanted && !this.revoked().includes('campus:' + domain + ':read'))
          grants.push('campus:' + domain + ':read');
    }
    const scope = this.hostScope({
      sources: [...new Set(sources)],
      currentEventIds,
      subjectId,
      worldId,
      audience,
      retention,
      infer:
        memoryMode === 'relevant' &&
        !listen &&
        !noInference &&
        !temporary &&
        !other &&
        !fictional &&
        !scenario &&
        !sourceOnly &&
        audience === 'self' &&
        settings.memoryEnabled,
      purposes: [purpose],
      grants,
    });
    const contract: ContextContract = {
      id: randomUUID(),
      revision: 1,
      scope,
      subjectId,
      worldId,
      memoryMode,
      retention,
      audience,
      purpose,
      interactionMode: listen
        ? 'listen'
        : direct
          ? 'direct_answer'
          : hint
            ? 'tutor_hint'
            : clarify
              ? 'clarify'
              : plan
                ? 'suggest_next'
                : 'analyze',
      actionMode:
        temporalAmbiguities.length ||
        (!interpretation.directLocalWrite && listen) ||
        /别改|不执行|先别.*(?:保存|发送)|只.*草稿/.test(authoredText)
          ? 'respond'
          : 'propose',
      exploration,
      privacyEpoch: this.repo.epoch,
      policyRevision: this.repo.policyRevision,
      timeZone,
      now,
      budget: {
        maxTokens: 24000,
        maxRows: 200,
        maxReadBytes: 160000,
        toolCalls: broadCampus ? 20 : 12,
        modelCalls: 20,
        dependencyDepth: 8,
        ...controls.budget,
      },
      excludedReasons: [
        ...(sourceOnly ? ['current_sources_only'] : []),
        ...(other ? ['other_subject'] : []),
        ...(audience !== 'self' ? ['audience_projection'] : []),
        ...(listen ? ['listen_mode'] : []),
        ...(temporary ? ['no_retention'] : []),
      ],
      temporalAmbiguities,
      resolvedDates,
      interpretation,
    };
    return {
      text,
      authoredText,
      attachment,
      contract,
      restriction,
      scenario,
      localOnly,
      speechActs,
      interpretation,
      requestFragments: interpretation.fragments,
      corrections: /说错|记错|更正|不是.*是|今天没|别再按|现在变了/.test(policyText) ? [policyText] : [],
    };
  }
}
export function isEphemeral(text: string) {
  return /(?:只用于|仅用于|只用在|只用|仅限|仅).*本轮.*(?:不保存|不记录)|(?:这段|这句|本轮|此轮|临时).*不保存|不要保存这段|临时模式|session.only|do not (?:save|store)|don't (?:save|store)/i.test(
    authoredControls(text),
  );
}

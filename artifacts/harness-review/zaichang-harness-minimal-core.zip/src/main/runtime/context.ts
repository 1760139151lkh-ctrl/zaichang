import { randomUUID } from 'node:crypto';
import type {
  Assertion,
  ContextContract,
  ContextPack,
  EvidenceBundle,
  EvidenceEvent,
  Need,
  NeedResult,
  TypedValue,
} from '../../shared/harness';
import { always, HarnessError } from '../../shared/harness';
import type { KernelRepository } from '../storage/repository';
import type { PolicyKernel, IngressDecision } from './policy';
import type { CapabilityBroker, CapabilityResult } from '../capabilities/broker';
import type { DomainService } from '../storage/domains';
import type { WorkService } from './work';
import { canonical, dateInZone, dayBounds, evaluateCondition } from './semantics';
import { redactCredentials } from './redaction';
import type { ProviderMetadata } from '../provider';
import type { ProviderReceipt } from '../../shared/harness';

function grams(text: string) {
  const p = Array.from(text.toLowerCase()),
    out = new Set<string>();
  for (let i = 0; i < p.length - 1; i++)
    if (!/[\s，。！？、；：]/.test(p[i] + p[i + 1])) out.add(p[i] + p[i + 1]);
  return out;
}
function lexical(query: string, text: string) {
  const a = grams(query),
    b = grams(text);
  let score = 0;
  for (const g of a) if (b.has(g)) score++;
  return score;
}
const relevantPredicates = (text: string) => {
  const prefixes: string[] = [];
  if (/学习|项目|做题|解释|图书馆|哪里学|专注/.test(text))
    prefixes.push('study.', 'learning.', 'explanation.', 'library.', 'place.', 'transition.', 'resource.');
  if (/跑步|体育|运动|跑的/.test(text)) prefixes.push('running.', 'sports.');
  if (/回家|住处|住哪|路线|怎么走|怎么去|去哪|课程|教室/.test(text))
    prefixes.push('residence.', 'transport.', 'location.', 'deadline.');
  if (/安排|接下来|最后两小时/.test(text))
    prefixes.push('deadline.', 'study.', 'transport.', 'rest.', 'current.', 'interaction.');
  if (/怎样理解|了解我|偏好|喜欢/.test(text)) prefixes.push('preference.', 'place.');
  return prefixes;
};
export class ContextCompiler {
  private providerMetadata?: ProviderMetadata;
  constructor(
    readonly repo: KernelRepository,
    readonly policy: PolicyKernel,
    readonly broker: CapabilityBroker,
    readonly domains: DomainService,
    readonly work: WorkService,
  ) {}
  /** Bind only non-secret protocol facts; payloads and credentials never enter the receipt. */
  setProviderMetadata(metadata?: ProviderMetadata) {
    this.providerMetadata = metadata
  }
  initialNeeds(contract: ContextContract, text: string): Need[] {
    // Listening suppresses unsolicited planning and memory reads, but an
    // explicitly requested read-only sub-request still needs its source.
    if (
      (contract.interactionMode === 'listen' && !contract.interpretation?.hasRetrieval) ||
      contract.memoryMode === 'current_sources_only'
    )
      return [];
    const needs: Need[] = [],
      add = (
        key: string,
        capability: string,
        args: Need['args'] = {},
        importance: Need['importance'] = 'conditional',
      ) =>
        needs.push({
          id: key,
          key,
          importance,
          capability,
          args,
          condition: always,
          mode: 'all',
          childIds: [],
        });
    if (/课程|课表|下一节|教室|有没有时间限制/.test(text))
      add('schedule', 'campus.lookup', { domain: 'schedule' }, /必须|截止|时间限制/.test(text) ? 'must' : 'conditional');
    if (/考试/.test(text)) add('exams', 'campus.lookup', { domain: 'exams' }, /必须|截止|哪天/.test(text) ? 'must' : 'conditional');
    if (/体育|计次|次数|打卡/.test(text)) add('sports', 'campus.lookup', { domain: 'sports' }, 'conditional');
    if (/天气|下雨|能跑|跑步合适/.test(text))
      add(
        'weather',
        'weather.lookup',
        { days: 3 },
        /顺便|有空|如果方便/.test(text)
          ? 'optional'
          : /天气|下雨/.test(text)
            ? 'must'
            : 'conditional',
      );
    if (/路线|导航|怎么走|怎么去|从.*到/.test(text)) {
      add('origin', 'map.location_status', {}, 'must');
      add('precise_origin', 'map.location_status', {}, 'conditional');
      if (/这栋楼|这间|那栋/.test(text)) add('destination.eligibility', 'map.place', {}, 'conditional');
    }
    if (/余额|还能用多少|承诺支出/.test(text)) add('financial_coverage', 'finance.available', {}, 'must');
    if (/能吃饭|供餐/.test(text)) add('food_service_status', 'place.food_service', {}, 'conditional');
    if (/掌握|独立做/.test(text)) add('independent_performance', 'learning.independent_performance', {}, 'must');
    return needs;
  }
  private currentFacts(
    ingress: IngressDecision,
    recentSessionEvents: EvidenceEvent[] = [],
  ): Record<string, TypedValue> {
    // When the turn's focus is another subject, keep an owner's side comment
    // as provenance (the coordinator stores it separately) without letting it
    // alter the facts used for that other-subject task.
    if (
      ingress.interpretation.fragments.some(
        (fragment) =>
          fragment.subjectId !== ingress.contract.subjectId && !fragment.intents.includes('record_local'),
      )
    )
      return {};
    const points = Array.from(ingress.authoredText),
      today = dateInZone(ingress.contract.now, ingress.contract.timeZone),
      priorTexts = recentSessionEvents
        .filter(
          (event) =>
            event.status === 'active' &&
            event.speaker === 'user' &&
            event.authority === 'user_statement' &&
            event.subjectId === ingress.contract.subjectId &&
            event.worldId === ingress.contract.worldId &&
            dateInZone(event.receivedAt, ingress.contract.timeZone) === today,
        )
        .sort((a, b) => a.sequence - b.sequence)
        .map((event) => event.text),
      currentTexts = ingress.speechActs
        .filter(
          (act) =>
            act.subjectId === ingress.contract.subjectId &&
            act.worldId === ingress.contract.worldId &&
            ['assert', 'correct', 'reject'].includes(act.kind),
        )
        .map((act) => points.slice(act.startCodePoint, act.endCodePoint).join('')),
      facts: Record<string, TypedValue> = {};
    // Apply same-day original clauses in sequence. The newest current wording
    // wins, so a correction is available before background extraction/indexing
    // catches up and an older positive cannot erase a tail negation.
    for (const text of [...priorTexts, ...currentTexts]) {
      if (/今天.*(?:没(?:有)?|未)骑车|没(?:有)?骑车来/.test(text))
        facts['transport.current'] = { type: 'text', value: 'walk' };
      else if (/今天.*(?:骑车|带了自行车)/.test(text))
        facts['transport.current'] = { type: 'text', value: 'bike' };
      if (/今天.*(?:不想跑|不跑)|跑步今天不安排/.test(text))
        facts['running.today_allowed'] = { type: 'boolean', value: false };
      else if (/今天.*(?:想跑|要跑|安排跑步)/.test(text))
        facts['running.today_allowed'] = { type: 'boolean', value: true };
      if (/今天.*(?:精神很好|精神不错|有精力)/.test(text))
        facts['current.energy'] = { type: 'text', value: 'good' };
      if (/今天.*(?:身体不舒服|身体不适|疲惫|很累)/.test(text))
        facts['current.accommodation'] = { type: 'text', value: 'reduce_optional_load_today' };
      if (/不需要有产出|不.*优化掉.*休息|休息.*别优化掉/.test(text))
        facts['rest.preserve_unstructured'] = { type: 'boolean', value: true };
    }
    return facts;
  }
  async compile(
    ingress: IngressDecision,
    currentEvents: EvidenceEvent[],
    signal: AbortSignal,
    additionalNeeds: Need[] = [],
    acquire = false,
    sessionId?: string,
  ): Promise<ContextPack> {
    const contract = ingress.contract,
      s = this.policy.validate(contract.scope),
      now = Date.parse(contract.now),
      recentSessionEvents =
        sessionId && contract.memoryMode === 'relevant'
          ? this.repo.sessionEvidence(contract.scope, sessionId, 8)
          : [],
      currentFacts = this.currentFacts(ingress, recentSessionEvents),
      prefixes = relevantPredicates(ingress.authoredText);
    const excluded: Record<string, number> = {};
    for (const reason of contract.excludedReasons) excluded[reason] = 1;
    const referenceEvents =
      sessionId &&
      contract.memoryMode === 'relevant' &&
      /这|那|刚才|之前|继续|上次|两个/.test(ingress.authoredText)
        ? recentSessionEvents.slice(0, 4)
        : [];
    const pendingConstraints =
      sessionId &&
      contract.memoryMode === 'relevant' &&
      /安排|计划|接下来|继续|下一步/.test(ingress.authoredText)
        ? this.repo.pendingConstraints(contract.scope, sessionId)
        : [];
    let assertions: Assertion[] = [],
      raw: EvidenceEvent[] = [],
      workState: unknown[] = [],
      bundles: EvidenceBundle[] = [];
    if (contract.memoryMode === 'relevant' && s.sources.includes('profile:self')) {
      const eligible = [
        ...new Map(
          [
            ...this.repo.assertions(contract.scope, { statuses: ['active'], limit: contract.budget.maxRows }),
            ...this.repo.lexicalAssertions(contract.scope, ingress.authoredText),
          ].map((a) => [a.id, a]),
        ).values(),
      ].filter((a) => {
        if (
          (a.temporal.validFrom && Date.parse(a.temporal.validFrom) > now) ||
          (a.temporal.validTo && Date.parse(a.temporal.validTo) <= now)
        ) {
          excluded.outside_valid_time = (excluded.outside_valid_time || 0) + 1;
          return false;
        }
        if (
          a.verification !== 'verified' ||
          a.kind === 'inferred_hypothesis' ||
          a.temporal.unresolvedExpression
        ) {
          excluded.unverified = (excluded.unverified || 0) + 1;
          return false;
        }
        return true;
      });
      const relevant = eligible
        .filter(
          (a) =>
            a.strength === 'hard' ||
            a.evidenceIds.some((id) => referenceEvents.some((e) => e.id === id)) ||
            prefixes.some((p) => a.predicate.startsWith(p)) ||
            lexical(ingress.authoredText, a.text) >= 2,
        )
        .filter((a) => !contract.exploration || a.strength === 'hard');
      // Current explicit correction suppresses old data for matching predicates before model exposure.
      assertions = relevant
        .filter((a) => !(a.predicate in currentFacts))
        .sort(
          (a, b) =>
            Number(b.strength === 'hard') - Number(a.strength === 'hard') ||
            lexical(ingress.authoredText, b.text) - lexical(ingress.authoredText, a.text),
        );
      const byId = new Map(eligible.map((a) => [a.id, a]));
      for (const assertion of assertions) {
        const related = [
          assertion,
          ...assertion.exceptionIds.map((id) => byId.get(id)).filter((a): a is Assertion => !!a),
        ];
        const sources = [...new Set(related.flatMap((a) => a.evidenceIds))]
          .map((id) => this.repo.evidence(contract.scope, id))
          .filter((e): e is EvidenceEvent => !!e);
        const condition = evaluateCondition(
          assertion.conditions,
          Object.fromEntries([
            ...eligible.map((a) => [a.predicate, a.value]),
            ...Object.entries(currentFacts),
          ]),
        );
        if (condition === 'false') continue;
        const text = canonical({
          understanding: related.map((a) => ({
            id: a.id,
            revision: a.revision,
            predicate: a.predicate,
            value: a.value,
            text: a.text,
            conditions: a.conditions,
            validFrom: a.temporal.validFrom,
            validTo: a.temporal.validTo,
            strength: a.strength,
          })),
          sources: sources.map((e) => ({
            id: e.id,
            version: e.contentVersion,
            sourceId: e.sourceId,
            receivedAt: e.receivedAt,
            authority: e.authority,
            text: e.text,
          })),
        });
        bundles.push({
          id: assertion.id,
          assertionIds: related.map((a) => a.id),
          evidenceIds: sources.map((e) => e.id),
          text,
          estimatedTokens: Math.ceil(Array.from(text).length / 1.4),
          hard: related.some((a) => a.strength === 'hard'),
          coverage: condition === 'unknown' ? 'conditional' : 'complete',
        });
      }
    }
    if (
      contract.memoryMode === 'relevant' &&
      s.sources.includes('history:self') &&
      contract.interactionMode !== 'listen'
    ) {
      // Entity/lexical path and independent original-source path are separately eligible; no need for an extracted assertion.
      const candidates = [
        ...new Map(
          [
            ...this.repo.lexicalEvidence(contract.scope, ingress.authoredText),
            ...this.repo.evidenceList(contract.scope, contract.budget.maxRows),
          ].map((e) => [e.id, e]),
        ).values(),
      ].filter((e) => !s.currentEventIds.includes(e.id) && e.speaker === 'user');
      raw = [
        ...new Map(
          [
            ...pendingConstraints,
            ...referenceEvents,
            ...candidates
              .map((e) => ({ e, score: lexical(ingress.authoredText, e.text) }))
              .filter((r) => r.score >= 3)
              .sort((a, b) => b.score - a.score)
              .slice(0, 8)
              .map((r) => r.e),
          ].map((e) => [e.id, e]),
        ).values(),
      ];
      for (const e of raw) {
        if (bundles.some((b) => b.evidenceIds.includes(e.id))) continue;
        const text = canonical({
          original: {
            id: e.id,
            version: e.contentVersion,
            sourceId: e.sourceId,
            receivedAt: e.receivedAt,
            authority: e.authority,
            text: e.text,
          },
          processing: this.repo
            .spans(contract.scope, e.id)
            .map((s) => ({ start: s.start, end: s.end, status: s.status })),
        });
        bundles.push({
          id: e.id,
          assertionIds: [],
          evidenceIds: [e.id],
          text,
          estimatedTokens: Math.ceil(Array.from(text).length / 1.4),
          hard: pendingConstraints.some((p) => p.id === e.id),
          coverage: 'conditional',
        });
      }
    }
    if (s.sources.includes('work:self') && contract.interactionMode !== 'listen') {
      const records = this.repo.work(contract.scope),
        episode = this.work.resolveEpisode(
          contract.scope,
          sessionId,
          ingress.authoredText,
          currentEvents.map((event) => event.id),
        ).episode,
        reference = /第[一二三四五六七八九十\d]+个|刚才那个|刚刚那个|之前那个|继续|回到|回来/.test(
          ingress.authoredText,
        ),
        referenced = new Set(
          reference
            ? ((episode?.data.lastDisplayedOptionIds || episode?.data.optionIds || []) as string[])
            : [],
        );
      workState = records
        .filter(
          (w) =>
            ['episode', 'goal', 'commitment', 'plan', 'option', 'task', 'window', 'experience'].includes(
              w.kind,
            ) && !['cancelled', 'closed'].includes(w.status),
        )
        .filter(
          (w) =>
            (reference && (w.id === episode?.id || referenced.has(w.id))) ||
            lexical(ingress.authoredText, w.title) >= 2 ||
            /继续|上次|那个|这个目标/.test(ingress.authoredText),
        )
        .slice(0, 12);
    }
    const needs = [...this.initialNeeds(contract, ingress.authoredText), ...additionalNeeds];
    const needResults: NeedResult[] = [];
    for (const need of needs) {
      if (needResults.some((n) => n.key === need.key)) continue;
      let result: CapabilityResult | undefined;
      if (acquire && need.capability)
        result = await this.broker.invoke(contract.scope, need.capability, need.args, signal);
      const location = result?.data as any;
      const status =
        need.key === 'precise_origin' &&
        (!location ||
          Number(location.accuracy_m || location.accuracyMeters || Infinity) > 100 ||
          location.inside_supported_area === false)
          ? 'unknown'
          : result?.status || 'not_queried';
      needResults.push({
        id: need.id,
        key: need.key,
        capability: need.capability,
        status,
        evidenceIds: [],
        reason: result?.reason,
        value: result?.data,
        fetchedAt: result?.fetchedAt,
        coverage: result?.coverage,
      });
      if (need.key === 'weather' && result?.coverage?.until) {
        const deadline = ingress.authoredText.match(/到(\d{1,2})月(\d{1,2})日/);
        const requested = deadline
          ? dateInZone(contract.now, contract.timeZone).slice(0, 4) +
            '-' +
            deadline[1].padStart(2, '0') +
            '-' +
            deadline[2].padStart(2, '0')
          : undefined;
        if (requested && requested > result.coverage.until.slice(0, 10))
          needResults.push({
            id: 'weather.full_deadline_window',
            key: 'weather.full_deadline_window',
            status: 'unknown',
            evidenceIds: [],
            reason: '请求时段超出实际预报窗口',
          });
      }
      if (result?.status === 'conflict')
        for (const conflict of (result.data as any)?.conflicts || [])
          for (const field of conflict.fields || ['room'])
            needResults.push({
              id: conflict.id + '.' + field,
              key: conflict.id + '.' + field,
              status: 'conflict',
              evidenceIds: [],
              reason: '来源之间的字段值不一致',
            });
    }
    let estimatedTokens = Math.ceil(Array.from(ingress.text).length / 1.4),
      readBytes = Buffer.byteLength(ingress.text),
      coverage: ContextPack['receipt']['coverage'] = 'complete_for_candidate';
    const admitted: EvidenceBundle[] = [];
    for (const bundle of bundles) {
      if (
        estimatedTokens + bundle.estimatedTokens > contract.budget.maxTokens ||
        readBytes + Buffer.byteLength(bundle.text) > contract.budget.maxReadBytes
      ) {
        excluded.budget = (excluded.budget || 0) + 1;
        if (bundle.hard) coverage = 'blocked';
        else if (coverage !== 'blocked') coverage = 'conditional';
        continue;
      }
      admitted.push(bundle);
      estimatedTokens += bundle.estimatedTokens;
      readBytes += Buffer.byteLength(bundle.text);
      if (bundle.coverage !== 'complete' && coverage !== 'blocked') coverage = 'conditional';
    }
    if (estimatedTokens > contract.budget.maxTokens || readBytes > contract.budget.maxReadBytes)
      coverage = 'blocked';
    if (needResults.some((n) => !['fresh', 'known_absent'].includes(n.status)) && coverage !== 'blocked')
      coverage = 'conditional';
    const admittedIds = new Set(admitted.flatMap((b) => b.assertionIds));
    assertions = assertions.filter((a) => admittedIds.has(a.id));
    const evidenceIds = [
      ...new Set([...admitted.flatMap((b) => b.evidenceIds), ...currentEvents.map((e) => e.id)]),
    ];
    const priorEvidence = evidenceIds
      .filter((id) => !currentEvents.some((e) => e.id === id))
      .map((id) => this.repo.evidence(contract.scope, id))
      .filter((e): e is EvidenceEvent => !!e);
    const provider = this.providerMetadata
      ? ({
          ...this.providerMetadata,
          capabilities: {
            ...this.providerMetadata.capabilities,
            modalities: [...this.providerMetadata.capabilities.modalities],
          },
          limits: {
            ...this.providerMetadata.limits,
            hostContextTokens: contract.budget.maxTokens,
          },
        } satisfies ProviderReceipt)
      : undefined;
    const receipt = {
      id: randomUUID(),
      runId: contract.id,
      contractRevision: contract.revision,
      policyRevision: contract.policyRevision,
      privacyEpoch: contract.privacyEpoch,
      watermarks: this.repo.watermarks(),
      providedEvidenceIds: evidenceIds,
      providedSourceIds: [
        ...new Set(
          [...priorEvidence, ...currentEvents]
            .map((e) => e.sourceId)
            .concat(
              needResults.flatMap((n) =>
                n.capability ? [this.broker.describe(n.capability)?.sourceId || ''] : [],
              ),
            )
            .filter(Boolean),
        ),
      ],
      providedObjectVersions: [
        ...assertions.map((a) => ({ id: a.id, revision: a.revision })),
        ...currentEvents.map((e) => ({ id: e.id, revision: e.contentVersion })),
      ],
      needResults: needResults.map((n) => ({ key: n.key, status: n.status })),
      excludedReasonCounts: excluded,
      ...(provider ? { provider } : {}),
      providerVersion: provider ? `${provider.protocol}/${provider.protocolVersion}` : 'unknown',
      toolAttempts: [],
      coverage,
      budget: { estimatedTokens, readBytes },
    };
    this.repo.saveReceipt(contract.scope, receipt);
    const data: Record<string, unknown> = {
      scope: {
        subject: contract.subjectId,
        world: contract.worldId,
        purpose: contract.purpose,
        audience: contract.audience,
        memoryMode: contract.memoryMode,
        retention: contract.retention,
      },
      time: {
        now: contract.now,
        timeZone: contract.timeZone,
        resolvedDates: contract.resolvedDates,
        ambiguities: contract.temporalAmbiguities,
      },
      interactionMode: contract.interactionMode,
      exploration: contract.exploration,
      interpretation: ingress.interpretation,
      currentFacts,
      correctionOverlay: ingress.corrections,
      workState,
      speechActs: ingress.speechActs,
      evidenceBundles: admitted.map((b) => JSON.parse(b.text)),
      needs: needResults,
      coverage,
      criteria: [
        'user_autonomy',
        ...(assertions.some((a) => a.predicate.includes('autonomy')) ? ['autonomy'] : []),
        ...(assertions.some((a) => a.predicate.includes('focus')) ? ['focus'] : []),
      ],
      protectedInteractionRules: ['no_shaming', 'user_decides', 'no_preference_as_permission'],
      limitations:
        coverage === 'blocked' ? ['完整条件束超出预算，需要缩小任务或先澄清，不能给保证可执行的安排'] : [],
    };
    return {
      contract,
      bundles: admitted,
      assertions,
      evidence: [...priorEvidence, ...currentEvents],
      needs: needResults,
      receipt,
      data,
      currentText: ingress.authoredText,
    };
  }
  async expand(pack: ContextPack, needs: Need[], signal: AbortSignal) {
    this.policy.validate(pack.contract.scope);
    for (const need of needs) {
      if (pack.needs.some((n) => n.key === need.key)) continue;
      const result = need.capability
        ? await this.broker.invoke(pack.contract.scope, need.capability, need.args, signal)
        : undefined;
      pack.needs.push({
        id: need.id,
        key: need.key,
        capability: need.capability,
        status: result?.status || 'unknown',
        evidenceIds: [],
        value: result?.data,
        reason: result?.reason || '缺少当前事实',
        fetchedAt: result?.fetchedAt,
      });
      if (result?.data)
        pack.receipt.providedSourceIds = [
          ...new Set([...(pack.receipt.providedSourceIds || []), result.sourceId]),
        ];
    }
    if (pack.needs.some((n) => !['fresh', 'known_absent'].includes(n.status)))
      pack.receipt.coverage = 'conditional';
    pack.receipt.needResults = pack.needs.map((n) => ({ key: n.key, status: n.status }));
    pack.data.needs = pack.needs;
    pack.data.coverage = pack.receipt.coverage;
    this.repo.saveReceipt(pack.contract.scope, pack.receipt);
    return pack;
  }
  /** Record the actual endpoint/mode used by a model call without retaining payloads. */
  recordProviderRequest(
    pack: ContextPack | undefined,
    metadata: ProviderMetadata | undefined,
    mode: { thinking: 'enabled' | 'disabled'; strict: boolean; tools: boolean },
  ) {
    if (!pack || !metadata) return;
    const previous = pack.receipt.provider;
    const thinking = previous?.requestModes?.thinking;
    const strict = previous?.requestModes?.strict;
    const provider: ProviderReceipt = {
      ...metadata,
      observedEndpoints: [
        ...new Set([...(previous?.observedEndpoints || []), metadata.endpoint]),
      ],
      capabilities: {
        ...metadata.capabilities,
        modalities: [...metadata.capabilities.modalities],
      },
      limits: {
        ...metadata.limits,
        hostContextTokens: pack.contract.budget.maxTokens,
      },
      requestModes: {
        thinking:
          thinking && thinking !== mode.thinking
            ? 'mixed'
            : (thinking || mode.thinking),
        strict: strict !== undefined && strict !== mode.strict ? 'mixed' : (strict ?? mode.strict),
        tools: Boolean(previous?.requestModes?.tools || mode.tools),
      },
    };
    pack.receipt.provider = provider;
    pack.receipt.providerVersion = `${provider.protocol}/${provider.protocolVersion}`;
    this.repo.saveReceipt(pack.contract.scope, pack.receipt);
  }
  recordTool(pack: ContextPack, result: CapabilityResult, capability: string) {
    this.policy.validate(pack.contract.scope);
    if (result.data) {
      pack.receipt.providedSourceIds = [
        ...new Set([...(pack.receipt.providedSourceIds || []), result.sourceId]),
      ];
      if (capability === 'evidence.search')
        for (const entry of (result.data as any).results || [])
          if (typeof entry.id === 'string' && this.repo.evidence(pack.contract.scope, entry.id))
            pack.receipt.providedEvidenceIds = [...new Set([...pack.receipt.providedEvidenceIds, entry.id])];
    }
    const attempt = this.broker.invocations
      .filter((i) => i.scopeId === pack.contract.scope.id && i.capability === capability)
      .at(-1);
    if (attempt)
      pack.receipt.toolAttempts.push({
        id: attempt.id,
        capability,
        status: result.status,
        version: attempt.version,
      });
    const key =
      capability === 'campus.lookup'
        ? (result.data as any)?.domain || 'campus'
        : capability === 'weather.lookup'
          ? 'weather'
          : capability;
    const existing = pack.needs.find((n) => n.key === key || n.capability === capability);
    if (existing) {
      existing.status = result.status;
      existing.value = result.data;
      existing.reason = result.reason;
      existing.fetchedAt = result.fetchedAt;
      existing.coverage = result.coverage;
    } else
      pack.needs.push({
        id: key,
        key,
        capability,
        status: result.status,
        evidenceIds: [],
        value: result.data,
        reason: result.reason,
        fetchedAt: result.fetchedAt,
        coverage: result.coverage,
      });
    pack.receipt.needResults = pack.needs.map((n) => ({ key: n.key, status: n.status }));
    this.repo.saveReceipt(pack.contract.scope, pack.receipt);
  }
  serialize(pack: ContextPack) {
    this.policy.validate(pack.contract.scope);
    // Public/group drafting receives a release brief and explicitly allowed
    // projection only. Never serialize the authored event, speech acts,
    // history bundles or private work state into this model boundary.
    if (pack.contract.audience !== 'self') {
      return redactCredentials(
        canonical({
          scope: {
            audience: pack.contract.audience,
            purpose: pack.contract.purpose,
            memoryMode: pack.contract.memoryMode,
            retention: pack.contract.retention,
          },
          time: pack.data.time,
          interactionMode: pack.data.interactionMode,
          releaseSpec: pack.data.releaseSpec,
          availabilityProjection: pack.data.availabilityProjection,
          coverage: pack.receipt.coverage,
          limitations: pack.data.limitations,
        }),
      );
    }
    if (pack.receipt.coverage === 'blocked')
      return redactCredentials(
        canonical({
          scope: pack.data.scope,
          time: pack.data.time,
          currentRequest: pack.currentText,
          coverage: 'blocked',
          limitations: pack.data.limitations,
          missing: pack.receipt.needResults,
        }),
      );
    return redactCredentials(canonical(pack.data));
  }
}

import { randomUUID, createHash } from 'node:crypto';
import { z } from 'zod';
import type { Store } from '../store';
import type { Action, Memory, Obligation, Step } from '../../shared/types';
import type { ToolSpec, ProviderMetadata } from '../provider';
import {
  always,
  candidateSchema,
  conditionSchema,
  changeSchema,
  HarnessError,
  needSchema,
  personalLabel,
  type ContextPack,
  type EvidenceEvent,
  type MemoryChange,
  releaseSpecSchema,
  type ReleaseSpec,
  type ScopeHandle,
} from '../../shared/harness';
import { KernelRepository } from '../storage/repository';
import { PolicyKernel, type IngressDecision, type InputControls } from './policy';
import { ContextCompiler } from './context';
import { WorkService } from './work';
import { MemoryService } from '../memory/service';
import { DomainService } from '../storage/domains';
import { CapabilityBroker, type CapabilityResult } from '../capabilities/broker';
import { registerBuiltins, localActionInput, type BuiltinConnections } from '../capabilities/builtin';
import { ActionRuntime } from '../actions/runtime';
import { ReminderRuntime } from '../actions/reminders';
import { canonical, dateInZone, dayBounds } from './semantics';
import {
  ObservationPort,
  SyncPort,
  RulePackPort,
  WatchPort,
  StorageProtectionPort,
  EntityPort,
} from '../capabilities/ports';

export interface RunSession {
  ingress: IngressDecision;
  events: EvidenceEvent[];
  pack?: ContextPack;
  sessionId: string;
  ephemeral: boolean;
  episodeId?: string;
  toolCalls: number;
  modelCalls: number;
  signal: AbortSignal;
}
export interface RuntimeCallbacks {
  step: (step: Step) => void;
  plan: (items: Obligation[]) => void;
  action: (item: Action) => void;
  changed: () => void;
  mapCard?: (card: import('../../shared/map-v2').MapCard) => void;
  delegate: (tasks: { title: string; instruction: string }[]) => Promise<unknown>;
}
const lookUpSchema = z
  .object({
    source: z.enum(['campus', 'history', 'weather', 'map', 'local', 'capability']),
    mode: z.enum(['overview', 'detail', 'refresh']).optional(),
    domain: z.string().max(80).optional(),
    query: z.string().max(100).optional(),
    days: z.number().int().min(1).max(7).optional(),
    from: z.string().datetime({ offset: true }).optional(),
    to: z.string().datetime({ offset: true }).optional(),
    at: z.string().datetime({ offset: true }).optional(),
    window: z.string().max(40).optional(),
    timeMode: z.enum(['overlap', 'starts', 'contained']).optional(),
    fields: z
      .array(z.string().regex(/^[A-Za-z0-9_.-]{1,80}$/))
      .max(24)
      .optional(),
    filters: z.array(z.string().max(160)).max(6).optional(),
    sort: z.string().max(100).optional(),
    offset: z.number().int().min(0).max(10000).optional(),
    academicYear: z
      .string()
      .regex(/^20\d{2}-20\d{2}$/)
      .optional(),
    term: z.enum(['1', '2']).optional(),
    includeSensitiveDomains: z.boolean().optional(),
    limit: z.number().int().min(1).max(50).optional(),
    capability: z.string().max(100).optional(),
    arguments: z.record(z.string(), z.json()).optional(),
    refresh: z.boolean().optional(),
  })
  .strict();
const workChangeSchema = z.discriminatedUnion('operation', [
  z
    .object({
      operation: z.literal('propose_options'),
      options: z
        .array(z.object({ title: z.string().min(1).max(120), rationale: z.string().max(600) }).strict())
        .min(2)
        .max(5),
    })
    .strict(),
  z
    .object({
      operation: z.literal('reject_option'),
      id: z.string().min(1).max(160),
      expectedRevision: z.number().int().positive(),
      sourceQuote: z.string().min(1).max(1000),
      validWhen: conditionSchema,
      permanent: z.boolean().default(false),
    })
    .strict(),
  z.object({ operation: z.literal('propose_plan'), candidate: candidateSchema }).strict(),
  z
    .object({
      operation: z.literal('checkpoint'),
      episodeId: z.string(),
      expectedRevision: z.number().int(),
      nextSmallQuestion: z.string().max(300),
      openQuestions: z.array(z.string().max(300)).max(5),
    })
    .strict(),
  z
    .object({
      operation: z.literal('propose_goal'),
      title: z.string().min(1).max(120),
      reason: z.string().max(600),
    })
    .strict(),
  z
    .object({
      operation: z.literal('propose_task'),
      title: z.string().min(1).max(160),
      kind: z.enum(['prepare_application', 'prepare_portfolio', 'todo']),
      sourceQuote: z.string().min(1).max(1000),
    })
    .strict(),
]);
type SpecDefinition = {
  name: string;
  description: string;
  schema: z.ZodType;
  grant?: string;
  mutates?: boolean;
};
function sanitizeReleaseText(value: string) {
  return value
    .replace(/(?:因为|由于|因|出于|没空的?原因|私人原因|家庭原因|不方便透露)[^\n。！？!?；;]*/g, '')
    .replace(/(?:别|不要|先别|不必|不)\s*(?:解释|提及|提|说)[^\n。！？!?；;]*/g, '')
    .replace(/(?:我有|我现在有|我今天有)\s*[^，。！？!?；;]{0,80}(?=给|发给|写给|回复|回|通知|告知)/g, '')
    .replace(/\s+/g, ' ')
    .replace(/[，,；;:：]\s*$/, '')
    .trim();
}
function splitReleaseFacts(value: string) {
  return value
    .split(/[、,，；;]\s*/)
    .map((part) =>
      part
        .replace(/^(?:只说|就说|可以说)\s*/, '')
        .replace(/\s+/g, ' ')
        .replace(/[，,；;:：]\s*$/, '')
        .trim(),
    )
    .filter((part) => !/^(?:语气|口吻|长度|简短|一段|详细|只草稿|先别发送|直接发送|发出去)/.test(part))
    .filter((part) => part.length > 0)
    .slice(0, 24);
}
function inferredReleaseFacts(value: string) {
  return value
    .split(/[、,，；;]\s*/)
    .map((part) => sanitizeReleaseText(part))
    .filter(
      (part) =>
        part.length > 0 &&
        !/^(?:语气|口吻|长度|简短|一段|详细|只草稿|先别发送|直接发送|发出去|不提|别提|不要提|礼貌|自然|正式|客气)/.test(part),
    )
    .slice(0, 24);
}
const specs: SpecDefinition[] = [
  {
    name: 'look_up',
    description:
      '在本轮已授权的范围按需查资料。campus 指定 domain 查对应领域；overview 合并当前需要的领域。未接入与未授权会明确返回。不能指定文件路径、身份或网址。',
    schema: lookUpSchema,
  },
  {
    name: 'read_evidence',
    description: '按上下文中的来源 ID 打开有权使用的原文。不能通过自行构造身份扩大范围。',
    schema: z.object({ id: z.string().min(1).max(160) }).strict(),
    grant: 'evidence:read',
  },
  {
    name: 'propose_memory_change',
    description:
      '提出有本轮原文定位的条件理解或纠正。只是候选，代码和语义复核决定是否生效。主体/假设/今日例外/未来生效不可混淆；绝不授予动作权限。',
    schema: changeSchema,
    grant: 'memory:write',
    mutates: true,
  },
  {
    name: 'remember_preference',
    description: '兼容入口：只提出用户本轮明确偏好。source_quote 须逐字来自本人原文，条件和期限一起保留。',
    schema: z.object({ text: z.string().min(1).max(140), source_quote: z.string().min(2).max(300) }).strict(),
    grant: 'memory:write',
    mutates: true,
  },
  {
    name: 'prepare_action',
    description: '准备可编辑本地安排，用户查看具体内容后确认才保存。此调用不发送、不预约，也不代表外部成功。',
    schema: localActionInput,
    grant: 'local:write',
    mutates: true,
  },
  {
    name: 'inspect_action',
    description: '读取获批动作的真实回执；结果未知时请求核查，不能重新派发。',
    schema: z.object({ id: z.string(), reconcile: z.boolean().default(false) }).strict(),
  },
  {
    name: 'update_work_state',
    description: '提出方案或目标，或保存事项检查点。方案补齐依赖并验证，不自动变成承诺。',
    schema: workChangeSchema,
    grant: 'work:write',
    mutates: true,
  },
  {
    name: 'set_plan',
    description: '只维护本轮最多五项处理步骤；不把步骤变成用户承诺，没有证据不能称完成。',
    schema: z
      .object({
        items: z
          .array(
            z
              .object({
                id: z.string().max(40),
                title: z.string().max(90),
                status: z.enum(['pending', 'running', 'done', 'blocked']),
              })
              .strict(),
          )
          .min(1)
          .max(5),
      })
      .strict(),
    mutates: true,
  },
  {
    name: 'delegate',
    description:
      '有限的只读调查：每个子任务只获得父任务的范围子集，取消联动，不能继续委派、写记忆或执行动作。',
    schema: z
      .object({
        tasks: z
          .array(z.object({ title: z.string().max(60), instruction: z.string().max(1200) }).strict())
          .min(1)
          .max(3),
      })
      .strict(),
    mutates: true,
  },
];

// DeepSeek's ordinary tool endpoint accepts a bounded object schema but does
// not accept the recursive oneOf/$defs emitted by Zod for work changes. Local
// Zod validation remains authoritative after the call; this model-facing
// dialect only keeps the operation and the bounded fields discoverable.
const modelWorkChangeParameters: Record<string, unknown> = {
  type: 'object',
  properties: {
    operation: { type: 'string', enum: ['propose_options', 'reject_option', 'propose_plan', 'checkpoint', 'propose_goal', 'propose_task'] },
    options: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, rationale: { type: 'string' } }, required: ['title', 'rationale'], additionalProperties: false } },
    id: { type: 'string' },
    expectedRevision: { type: 'integer' },
    sourceQuote: { type: 'string' },
    validWhen: { type: 'object', additionalProperties: true },
    permanent: { type: 'boolean' },
    candidate: { type: 'object', additionalProperties: true },
    episodeId: { type: 'string' },
    nextSmallQuestion: { type: 'string' },
    openQuestions: { type: 'array', items: { type: 'string' } },
    title: { type: 'string' },
    reason: { type: 'string' },
    kind: { type: 'string', enum: ['prepare_application', 'prepare_portfolio', 'todo'] },
  },
  required: ['operation'],
  additionalProperties: false,
};
const modelMemoryChangeParameters: Record<string, unknown> = {
  type: 'object',
  properties: {
    operation: { type: 'string', enum: ['ADD', 'SUPPORT', 'REFINE', 'ADD_EXCEPTION', 'SUPERSEDE', 'CORRECT', 'DISPUTE', 'EXPIRE', 'RETRACT'] },
    targetId: { type: 'string' },
    expectedRevision: { type: 'integer' },
    eventId: { type: 'string' },
    sourceQuote: { type: 'string' },
    predicate: { type: 'string' },
    value: { type: 'object', additionalProperties: true },
    text: { type: 'string' },
    kind: { type: 'string', enum: ['explicit_fact', 'explicit_preference', 'current_state', 'inferred_hypothesis'] },
    strength: { type: 'string', enum: ['hard', 'soft', 'unconfirmed'] },
    conditions: { type: 'object', additionalProperties: true },
    validFrom: { type: 'string' },
    validTo: { type: 'string' },
    unresolvedTime: { type: 'string' },
    subject: { type: 'string', enum: ['self', 'source_subject', 'other', 'fictional'] },
    world: { type: 'string', enum: ['source_world', 'hypothetical'] },
    idempotencyKey: { type: 'string' },
  },
  required: ['operation', 'eventId', 'sourceQuote', 'predicate', 'value', 'text', 'kind', 'strength', 'conditions', 'idempotencyKey'],
  additionalProperties: false,
};
const modelMapRouteParameters: Record<string, unknown> = {
  type: 'object',
  properties: {
    from: { type: 'object', additionalProperties: true },
    to: { type: 'object', additionalProperties: true },
    avoidStairs: { type: 'boolean' },
    version: { type: 'string' },
  },
  required: [],
  additionalProperties: false,
};
const modelParameterOverrides: Record<string, Record<string, unknown>> = {
  update_work_state: modelWorkChangeParameters,
  propose_memory_change: modelMemoryChangeParameters,
  map_route: modelMapRouteParameters,
};
export class RuntimeCoordinator {
  readonly policy: PolicyKernel;
  readonly memory: MemoryService;
  readonly domains: DomainService;
  readonly work: WorkService;
  readonly broker: CapabilityBroker;
  readonly context: ContextCompiler;
  readonly actions: ActionRuntime;
  readonly reminders: ReminderRuntime;
  readonly connections: BuiltinConnections;
  readonly observations: ObservationPort;
  readonly sync: SyncPort;
  readonly rulePacks: RulePackPort;
  readonly watches: WatchPort;
  readonly storageProtection = new StorageProtectionPort();
  readonly entities: EntityPort;
  lastSession?: RunSession;
  private ephemeralEvents = new Map<string, EvidenceEvent>();
  private modelBoundary?: { client: { invalidateBoundary?: () => void }; fingerprint: string };
  constructor(
    readonly store: Store,
    readonly repo: KernelRepository,
  ) {
    this.policy = new PolicyKernel(repo);
    this.memory = new MemoryService(repo, this.policy);
    this.domains = new DomainService(repo, this.policy);
    this.work = new WorkService(repo, this.policy);
    this.broker = new CapabilityBroker(this.policy);
    this.domains.onChanged = () => this.work.staleWorlds();
    this.connections = { weatherEnabled: () => store.settings().weatherEnabled };
    registerBuiltins(this.broker, this.policy, repo, this.domains, this.connections);
    this.context = new ContextCompiler(repo, this.policy, this.broker, this.domains, this.work);
    this.reminders = new ReminderRuntime(repo, this.policy);
    this.actions = new ActionRuntime(repo, this.policy, this.broker, (a) => {
      store.writeAgendaProjection(a);
      this.reminders.schedule(a);
    });
    this.observations = new ObservationPort(repo, this.policy, this.work, this.domains);
    this.sync = new SyncPort(repo, this.policy, this.work);
    this.rulePacks = new RulePackPort(repo, this.policy, this.domains);
    this.watches = new WatchPort(repo, this.policy, this.reminders);
    this.entities = new EntityPort(repo, this.policy);
    this.memory.migrateLegacy();
    const legacyCampus = store.meta<import('../../shared/types').CampusSnapshot | null>('campus', null);
    if (legacyCampus && !repo.getMeta('campus_import_metadata')) this.domains.importSnapshot(legacyCampus);
    this.policy.onBarrier(() => {
      this.ephemeralEvents.clear();
      this.modelBoundary?.client.invalidateBoundary?.();
      this.modelBoundary = undefined;
      if (this.lastSession) {
        this.lastSession.pack = undefined;
        this.lastSession.events = [];
        this.lastSession.ingress = {
          ...this.lastSession.ingress,
          text: '',
          authoredText: '',
          corrections: [],
          attachment: undefined,
        };
      }
    });
    this.resumePendingIndices();
    this.restoreConversationProjection();
  }
  restoreConversationProjection() {
    const rows = this.repo.db
      .prepare(
        `SELECT e.payload FROM h_evidence e WHERE e.owner=? AND e.workspace=? AND e.status!='deleted'
      AND json_extract(e.payload,'$.kind')='user_message' AND json_extract(e.payload,'$.parentEventId') IS NULL AND json_extract(e.payload,'$.sessionId') IS NOT NULL
      AND NOT EXISTS(SELECT 1 FROM messages m WHERE m.id=e.id) ORDER BY e.seq`,
      )
      .all(this.repo.identity.principalId, this.repo.identity.workspaceId);
    this.repo.write(() => {
      for (const row of rows) {
        const event = JSON.parse(String(row.payload)) as EvidenceEvent;
        if (event.label.retention === 'session_only') continue;
        const sessionId = this.store.session(event.sessionId, event.text.split('\n')[0]);
        const attachments = this.repo.db
          .prepare(
            "SELECT payload FROM h_evidence WHERE json_extract(payload,'$.parentEventId')=? AND json_extract(payload,'$.kind')='file_import' AND status!='deleted'",
          )
          .all(event.id)
          .map((row) => JSON.parse(String(row.payload)) as EvidenceEvent);
        const content =
          event.text +
          attachments
            .map((e) => '\n\n[用户附上的文字资料：' + (e.fileName || '已保存附件') + ']\n' + e.text)
            .join('');
        const message = {
          id: event.id,
          sessionId,
          role: 'user' as const,
          content,
          createdAt: event.receivedAt,
          status: 'done' as const,
          steps: [],
          obligations: [],
          actions: [],
          retention: event.label.retention,
        };
        this.store.putMessage(message);
        this.store.putMessage({
          ...message,
          id: event.id + ':interrupted',
          role: 'assistant',
          content: '上次处理在开始时中断，输入已完整保留。可以重新发送。',
          status: 'cancelled',
        });
      }
    });
    this.repo.setMeta('restored_conversation_count', rows.length);
  }
  resumePendingIndices() {
    for (const job of this.repo.pending('index_evidence')) {
      const row = this.repo.db
        .prepare(
          'SELECT subject,world,source,purpose,audience,retain FROM h_evidence WHERE id=? AND owner=? AND workspace=? AND status!=?',
        )
        .get(
          String(job.object_id),
          this.repo.identity.principalId,
          this.repo.identity.workspaceId,
          'deleted',
        );
      if (!row) continue;
      const scope = this.policy.hostScope({
        subjectId: String(row.subject),
        worldId: String(row.world),
        sources: [String(row.source)],
        currentEventIds: [String(job.object_id)],
        purposes: [String(row.purpose)],
        audience: row.audience as any,
        infer: false,
      });
      this.repo.indexEvidence(scope, String(job.object_id));
    }
  }
  bindModel(
    contract: RunSession['ingress']['contract'],
    client: {
      invalidateBoundary?: () => void;
      providerMetadata?: (options?: { strict?: boolean; thinking?: 'enabled' | 'disabled' }) => ProviderMetadata;
    },
  ) {
    const s = this.policy.validate(contract.scope),
      fingerprint = canonical({
        runId: contract.id,
        subject: s.subjectId,
        world: s.worldId,
        sources: s.sources,
        purpose: s.purposes,
        audience: s.audience,
        epoch: s.privacyEpoch,
        revision: s.policyRevision,
      });
    if (this.modelBoundary?.client !== client || this.modelBoundary.fingerprint !== fingerprint) {
      this.modelBoundary?.client.invalidateBoundary?.();
      client.invalidateBoundary?.();
    }
    this.context.setProviderMetadata(client.providerMetadata?.());
    this.modelBoundary = { client, fingerprint };
  }
  connect(value: Partial<BuiltinConnections>) {
    Object.assign(this.connections, value);
  }
  begin(
    content: string,
    eventId: string,
    sessionId: string,
    signal: AbortSignal,
    controls: InputControls = {},
  ): RunSession {
    const ingress = this.policy.ingress(content, eventId, this.store.settings(), controls),
      contract = ingress.contract,
      s = this.policy.validate(contract.scope),
      ephemeral = contract.retention === 'session_only';
    if (ingress.attachment && !ephemeral) this.policy.registerSource('file:' + ingress.attachment.id);
    const makeEvent = (id: string, text: string, file = false): EvidenceEvent => ({
      id,
      ownerId: s.principalId,
      workspaceId: s.workspaceId,
      subjectId: s.subjectId,
      worldId: s.worldId,
      sourceId: file ? 'file:' + id : 'history:self',
      contentVersion: 1,
      sequence: 0,
      text,
      speaker: file ? 'external' : 'user',
      kind: file ? 'file_import' : 'user_message',
      authority: file ? 'quotation' : 'user_statement',
      roots: [id],
      sessionId,
      interpretationTimeZone: contract.timeZone,
      label: {
        ...personalLabel,
        purpose: contract.purpose,
        audience: contract.audience,
        retention: contract.retention,
        infer: !file && s.infer,
      },
      receivedAt: contract.now,
      status: 'active',
      ...(file
        ? {
            fileName: ingress.attachment!.name,
            parentEventId: eventId,
            locator: { kind: 'file' as const, artifactId: id, version: 1 },
          }
        : {}),
    });
    const events = [
      makeEvent(eventId, ingress.authoredText),
      ...(ingress.attachment ? [makeEvent(ingress.attachment.id, ingress.attachment.text, true)] : []),
    ];
    if (ephemeral) {
      for (const event of events) this.ephemeralEvents.set(event.id, event);
    } else
      this.repo.write(() => {
        for (let i = 0; i < events.length; i++) {
          events[i] = this.repo.ingest(contract.scope, events[i]);
          if (!this.memory.paused) this.repo.indexEvidence(contract.scope, events[i].id);
        }
      });
    // Mixed input may contain a separate, explicit statement about the owner. Keep its own subject-bound evidence,
    // sharing the same provenance root, rather than applying it to the person being helped.
    if (!ephemeral && contract.retention === 'purpose_scoped' && this.store.settings().memoryEnabled) {
      const points = Array.from(ingress.authoredText);
      for (const [index, act] of ingress.speechActs.entries())
        if (
          act.subjectId === s.principalId &&
          act.subjectId !== s.subjectId &&
          act.worldId === 'real' &&
          ['assert', 'correct'].includes(act.kind)
        ) {
          const id = eventId + ':owner-' + index,
            text = points.slice(act.startCodePoint, act.endCodePoint).join('');
          const scope = this.policy.hostScope({
            sources: ['history:self', 'profile:self'],
            currentEventIds: [id],
            subjectId: s.principalId,
            worldId: 'real',
            purposes: [contract.purpose],
            retention: contract.retention,
            infer: true,
          });
          this.repo.ingest(scope, {
            id,
            ownerId: s.principalId,
            workspaceId: s.workspaceId,
            subjectId: s.principalId,
            worldId: 'real',
            sourceId: 'history:self',
            contentVersion: 1,
            text,
            speaker: 'user',
            kind: 'user_message',
            authority: 'user_statement',
            roots: [eventId],
            parentEventId: eventId,
            label: { ...personalLabel, purpose: contract.purpose },
            receivedAt: contract.now,
            status: 'active',
            locator: {
              kind: 'text',
              eventId,
              contentVersion: 1,
              startCodePoint: act.startCodePoint,
              endCodePoint: act.endCodePoint,
            },
          });
          this.repo.indexEvidence(scope, id);
        }
    }
    if (ingress.scenario && !ephemeral) {
      const baseline = this.policy.hostScope({
        sources: s.sources,
        purposes: s.purposes,
        subjectId: s.subjectId,
      });
      this.work.createWorld(baseline, contract.worldId, { quotedAssumption: ingress.authoredText }, [
        eventId,
      ]);
    }
    const session: RunSession = {
      ingress,
      events,
      sessionId,
      ephemeral,
      signal,
      toolCalls: 0,
      modelCalls: 0,
    };
    if (!ephemeral && this.policy.can(contract.scope, 'work:write')) {
      const episode = this.work.episode(contract.scope, sessionId, ingress.authoredText, [eventId]);
      session.episodeId = episode?.id;
      if (episode) this.work.resolveReference(contract.scope, episode.id, ingress.authoredText);
      this.work.applyCurrentControls(contract.scope, ingress.authoredText);
    }
    this.lastSession = session;
    return session;
  }
  async compile(session: RunSession, acquire = false) {
    session.pack = await this.context.compile(
      session.ingress,
      session.events,
      session.signal,
      [],
      acquire,
      session.sessionId,
    );
    const contract = session.ingress.contract;
    if (contract.worldId !== 'real')
      session.pack.data.boundWorld = this.work.readWorldBaseline(contract.scope, contract.worldId);
    if (contract.memoryMode === 'relevant') {
      const metadata = this.repo.getMeta<any>('campus_import_metadata', {});
      const media = /刚才|转写|语音|纠正后/.test(session.ingress.authoredText)
        ? this.observations
            .list(contract.scope, 'media')
            .filter((o) => o.data.correctionConfirmedByUser === true)
        : [];
      session.pack.data.resolvedEntities = this.entities.resolve(
        contract.scope,
        session.ingress.authoredText + ' ' + media.map((o) => o.text).join(' '),
        metadata.institutionId || 'local',
      );
      if (media.length) {
        session.pack.data.currentMedia = media.map((o) => ({
          id: o.id,
          version: o.version,
          locator: o.locator,
          text: o.text,
          status: 'user_corrected_transcript',
        }));
        session.pack.receipt.providedEvidenceIds.push(...media.map((o) => o.evidenceId));
      }
      if (/规则|学期|要求/.test(session.ingress.authoredText) && metadata.institutionId && metadata.termId)
        session.pack.data.institutionRules = this.rulePacks.applicable(
          contract.scope,
          metadata.institutionId,
          metadata.termId,
          metadata.cohort,
        );
      if (/技能|掌握|独立.*题/.test(session.ingress.authoredText)) {
        const observations = this.observations.list(contract.scope, 'learning'),
          taskIds = [...new Set(observations.map((o) => o.data.taskRef))];
        if (taskIds.length === 1) {
          const projection = this.observations.learningProjection(contract.scope, taskIds[0]);
          session.pack.data.learning = projection;
          const need = session.pack.needs.find((n) => n.key === 'independent_performance');
          if (need) need.status = projection.independentPerformance === 'unknown' ? 'unknown' : 'fresh';
        }
      }
    }
    if (
      contract.audience !== 'self' &&
      /可约时间|空闲时间|忙闲|可用时间/.test(session.ingress.authoredText) &&
      !contract.excludedReasons.includes('current_sources_only')
    ) {
      // The authored request grants a one-turn busy-only projection. No title/body is selected or sent to the draft model.
      const scope = this.policy.hostScope({
        sources: ['campus:local', 'local-agenda'],
        grants: ['availability:share'],
        purposes: ['personal_assistance'],
        infer: false,
      });
      session.pack.data.availabilityProjection = this.domains.availability(scope);
    }
    if (contract.audience !== 'self') {
      const projection = (session.pack.data.availabilityProjection || {}) as Record<string, unknown>;
      const releaseSpec = this.releaseSpec(session, projection);
      session.pack.data.releaseSpec = releaseSpec;
      session.pack.currentText = this.generationInput(session);
      session.pack.data.currentFacts = {};
      session.pack.data.correctionOverlay = [];
      session.pack.receipt.providedEvidenceIds = [];
      session.pack.receipt.providedObjectVersions = [{ id: releaseSpec.id, revision: 1 }];
      session.pack.data.projectionId = 'projection:' + contract.id;
      this.repo.saveReceipt(contract.scope, session.pack.receipt);
    }
    return session.pack;
  }
  /** Build the minimum audience-specific brief without carrying the authored request. */
  releaseSpec(session: RunSession, projection: Record<string, unknown> = {}): ReleaseSpec {
    const text = session.ingress.authoredText.trim();
    const audience = session.ingress.contract.audience;
    const recipientMatch = text.match(/(?:给|发给|写给|回复|回|通知|告知)\s*([^，。！？!?；;:\n]{1,80}?)(?=写|发|说|说明|告知|通知|：|:|，|。|！|？|$)/);
    const recipient = (recipientMatch?.[1] || (audience === 'group' ? '小组' : audience === 'public' ? '公众' : '指定受众'))
      .trim()
      .replace(/^(?:我|帮我|请)\s*/, '')
      .slice(0, 160);
    const explicitPurpose = text.match(/(?:沟通目的|交流目的|目的|想表达|想说|需要(?:告诉|通知|说明))(?:是|为|：|:)?\s*([^\n。！？!?；;]{1,220})/);
    const purposeFromIntent = text.match(/(?:给|发给|写给|回复|回)\s*[^，。！？!?；;:\n]{1,80}?\s*(?:写|发|说|说明|告知|通知)\s*([^\n。！？!?；;]{1,220})/);
    const availability = /可约时间|空闲时间|忙闲|可用时间/.test(text);
    const purpose = sanitizeReleaseText(
      availability
        ? '协调可约时间'
        : explicitPurpose?.[1] ||
            purposeFromIntent?.[1] ||
            (/拒绝|婉拒/.test(text)
              ? '礼貌婉拒邀请'
              : /课程安排|近况/.test(text)
                ? '说明愿意公开的近况'
                : '完成这次沟通'),
    ).slice(0, 300);
    const explicit = text.match(/(?:公开内容|可以公开|允许公开|明确(?:要|可)说|要表达)\s*[:：]\s*([^\n。！？!?；;]{1,600})/)?.[1];
    const inferred = text.match(/(?:说明|告知|告诉|表达|提到)\s*([^\n。！？!?；;]{1,240})/)?.[1];
    const allowedFacts = [...new Set([
      ...(explicit ? splitReleaseFacts(explicit) : []),
      ...(inferred ? inferredReleaseFacts(inferred) : []),
    ])].filter(Boolean).slice(0, 24);
    // A request may contain a safe outcome next to a private reason (for
    // example, “这次不参加，原因是家里的事”).  Preserve the safe outcome in
    // the audience projection so the model can write a useful neutral draft;
    // never copy the surrounding reason into that projection.
    const safeParticipation = text.match(
      /(?:我)?(?:这次|此次|本次)[^，,。！？!?；;\n]{0,80}(?:不参加|不能参加|无法参加|不去了|不来)[^，,。！？!?；;\n]*/,
    )?.[0];
    if (!allowedFacts.length && safeParticipation)
      allowedFacts.push(sanitizeReleaseText(safeParticipation));
    if (!allowedFacts.length && /(?:不参加|不能参加|无法参加|不去了|不来)/.test(text))
      allowedFacts.push('这次不参加活动');
    const tone = sanitizeReleaseText(
      text.match(/(?:语气|口吻)\s*[:：]\s*([^\n。！？!?；;]{1,120})/)?.[1] ||
        (/(?:礼貌.*自然|自然.*礼貌)/.test(text)
          ? '礼貌、自然'
          : /(?:礼貌|客气)/.test(text)
            ? '礼貌'
            : /正式/.test(text)
              ? '正式'
              : '自然、礼貌'),
    ).slice(0, 120);
    const length: ReleaseSpec['length'] = /详细|展开|长一点|完整/.test(text)
      ? 'long'
      : /一段|适中|正常长度/.test(text)
        ? 'medium'
        : 'short';
    const negativeSend = /(?:别|不要|先别|暂不|不必)\s*(?:发送|发出|发出去|联系)/.test(text);
    const send = !negativeSend && /(?:直接)?发送|发出去|发给对方|帮我发/.test(text);
    const prohibitedCategories = [
      ...(!allowedFacts.some((fact) => /(?:因为|原因|理由)/.test(fact)) ? ['private_reason'] : []),
      'private_original',
    ];
    return releaseSpecSchema.parse({
      id: 'release:' + session.ingress.contract.id,
      recipient,
      purpose,
      allowedFacts,
      allowedProjection: structuredClone(projection),
      tone,
      length,
      prohibitedCategories: [...new Set(prohibitedCategories)],
      mode: send ? 'send' : 'draft',
      materialVersions: projection && Object.keys(projection).length ? [{ id: 'projection:' + session.ingress.contract.id, revision: 1 }] : [],
      authorization: send ? 'explicit_send' : allowedFacts.length ? 'explicit_draft' : 'projection_only',
    });
  }
  generationInput(session: RunSession) {
    if (session.ingress.contract.audience === 'self')
      return (
        session.ingress.authoredText +
        (session.ingress.attachment
          ? '\n\n' + JSON.stringify({ attached_data: session.ingress.attachment })
          : '')
      );
    const spec = (session.pack?.data.releaseSpec as ReleaseSpec | undefined) || this.releaseSpec(session);
    return '只根据以下 ReleaseSpec 起草面向指定受众的内容；不得读取或猜测原始请求，也不得把私人原文带入草稿。\n' + JSON.stringify(spec);
  }
  async processCurrent(session: RunSession) {
    if (session.ephemeral) return;
    for (const event of session.events)
      await this.memory.process(session.ingress.contract.scope, event.id, session.signal);
  }
  toolSpecs(session: RunSession, child = false): ToolSpec[] {
    const contract = session.ingress.contract,
      s = this.policy.validate(contract.scope);
    const interpretation = contract.interpretation,
      simpleConversation =
        /先陪我|先听我|只要一句|一个方向|第一步|简单说|直接说/.test(session.ingress.authoredText) &&
        !/比较|方案|多(?:个|门)|分别|调查|查清|完整计划|几条|几门/.test(session.ingress.authoredText),
      allowListenRead = !!interpretation?.hasRetrieval &&
        interpretation.fragments.some(
          (fragment) =>
            fragment.intents.includes('retrieve') &&
            fragment.subjectId === s.principalId &&
            fragment.worldId === 'real' &&
            fragment.readSources.length > 0,
        ),
      allowListenLocal = !!interpretation?.directLocalWrite &&
        interpretation.fragments.some(
          (fragment) =>
            fragment.intents.includes('record_local') &&
            fragment.subjectId === s.principalId &&
            fragment.worldId === 'real' &&
            fragment.audience === 'self',
        ),
      restrictedSubrequest = s.subjectId !== s.principalId || s.worldId !== 'real';
    const available: SpecDefinition[] = [...specs];
    if (this.connections.map && s.sources.includes('map:local')) {
      const place = z.object({ kind: z.enum(['place', 'node']), id: z.string().min(1).max(100) }).strict();
      available.push(
        {
          name: 'map_overview',
          description: '查看已装配地图的范围与数据说明。',
          schema: z.object({}).strict(),
          grant: 'map:read',
        },
        {
          name: 'map_search',
          description: '在现有地图检索地点，使用返回的稳定地点 ID。',
          schema: z
            .object({ query: z.string().min(1).max(100), limit: z.number().int().min(1).max(10).optional() })
            .strict(),
          grant: 'map:read',
        },
        {
          name: 'map_route',
          description: '计算现有步行网络上的路线并展示地图卡；未知入口、起点和不可达会明确返回。',
          schema: z
            .object({
              from: z.union([place, z.object({ kind: z.literal('current') }).strict()]).optional(),
              to: place.optional(),
              avoidStairs: z.boolean().optional(),
              version: z.string().optional(),
            })
            .strict(),
          grant: 'map:read',
        },
        {
          name: 'map_location_status',
          description: '读取定位能力状态，不启动定位。',
          schema: z.object({}).strict(),
          grant: 'map:read',
        },
      );
    }
    return available
      .filter(
        (d) =>
          (!simpleConversation || !['update_work_state', 'set_plan', 'delegate'].includes(d.name)) &&
          (!child || (!d.mutates && d.name !== 'inspect_action')) &&
          (!d.grant || s.grants.includes(d.grant)) &&
          (d.name !== 'inspect_action' ||
            (s.sources.includes('local-agenda') && contract.audience === 'self')) &&
          (d.name !== 'look_up' || !restrictedSubrequest || allowListenRead) &&
          (contract.interactionMode !== 'listen' ||
            ['read_evidence'].includes(d.name) ||
            (allowListenRead && d.name === 'look_up') ||
            (allowListenLocal && d.name === 'prepare_action')) &&
          (!session.ephemeral || !d.mutates || d.name === 'set_plan') &&
          ((d.name !== 'propose_memory_change' && d.name !== 'remember_preference') || s.infer),
      )
      .map((d) => {
        const { $schema: _, ...parameters } = modelParameterOverrides[d.name] || z.toJSONSchema(d.schema);
        return { type: 'function', function: { name: d.name, description: d.description, parameters } };
      });
  }
  async executeTool(
    session: RunSession,
    name: string,
    raw: unknown,
    callbacks: RuntimeCallbacks,
    child = false,
  ): Promise<unknown> {
    const contract = session.ingress.contract,
      handle = contract.scope;
    session.signal.throwIfAborted();
    this.policy.validate(handle);
    if (++session.toolCalls > contract.budget.toolCalls)
      throw new HarnessError('tool_budget', '本轮工具调用达到上限。');
    const aliases: Record<string, string> = {
      search_history: 'look_up',
      query_campus: 'look_up',
      get_weather: 'look_up',
      propose_action: 'prepare_action',
    };
    if (name in aliases) {
      raw =
        name === 'search_history'
          ? { source: 'history', ...(raw as object) }
          : name === 'query_campus'
            ? {
                source: 'campus',
                domain: (raw as any).kind,
                from: (raw as any).from,
                to: (raw as any).to,
                query: (raw as any).query,
              }
            : name === 'get_weather'
              ? { source: 'weather', ...(raw as object) }
              : raw;
      name = aliases[name];
    }
    if (name.startsWith('map_')) {
      const interpretation = contract.interpretation;
      if (
        contract.interactionMode === 'listen' &&
        !interpretation?.fragments.some(
          (fragment) =>
            fragment.intents.includes('retrieve') &&
            fragment.subjectId === this.policy.validate(handle).principalId &&
            fragment.worldId === 'real' &&
            fragment.readSources.includes('map'),
        )
      )
        throw new HarnessError('tool_forbidden', '倾听本轮没有请求地图查询。');
      const mapping: Record<string, string> = {
          map_overview: 'map.overview',
          map_search: 'map.search',
          map_route: 'map.route',
          map_location_status: 'map.location_status',
        },
        capability = mapping[name];
      if (!capability) throw new HarnessError('tool_unavailable', '地图工具不可用。');
      const result = await this.broker.invoke(handle, capability, raw, session.signal);
      if (session.pack) this.context.recordTool(session.pack, result, capability);
      if (capability === 'map.route' && result.data)
        callbacks.mapCard?.({ kind: 'route', route: result.data as any });
      return result;
    }
    const allowed = this.toolSpecs(session, child).some((s) => s.function.name === name);
    if (!allowed) throw new HarnessError('tool_forbidden', '该工具当前不可用或未授权。');
    const definition = specs.find((d) => d.name === name)!,
      args = definition.schema.parse(raw) as any;
    if (name === 'look_up') return this.lookUp(session, args);
    if (name === 'read_evidence') {
      const event = this.ephemeralEvents.get(args.id) || this.repo.evidence(handle, args.id);
      if (
        !event ||
        (!session.events.some((e) => e.id === event.id) && event.label.audience !== contract.audience)
      )
        throw new HarnessError('evidence_forbidden', '这条原文不在本轮允许范围内。');
      if (session.pack && !session.pack.receipt.providedEvidenceIds.includes(event.id)) {
        session.pack.receipt.providedEvidenceIds.push(event.id);
        this.repo.saveReceipt(handle, session.pack.receipt);
      }
      return {
        id: event.id,
        version: event.contentVersion,
        text: event.text,
        authority: event.authority,
        locator: event.locator,
      };
    }
    if (name === 'remember_preference' || name === 'propose_memory_change') {
      let change: unknown = args;
      if (name === 'remember_preference') {
        const event = session.events[0],
          date = /今天/.test(args.source_quote)
            ? dayBounds(dateInZone(contract.now, contract.timeZone), contract.timeZone)
            : undefined;
        change = {
          operation: 'ADD',
          eventId: event.id,
          sourceQuote: args.source_quote,
          predicate: 'preference.explicit',
          text: args.text,
          value: { type: 'text', value: args.text },
          kind: date ? 'current_state' : 'explicit_preference',
          strength: 'soft',
          conditions: always,
          validFrom: date?.from,
          validTo: date?.to,
          idempotencyKey: createHash('sha256')
            .update(event.id + args.source_quote)
            .digest('hex'),
        };
      }
      const parsed = changeSchema.parse(change);
      if (!session.events.some((e) => e.id === parsed.eventId))
        throw new HarnessError('event_not_current', '记忆提案须指向本轮原文。');
      const value = await this.memory.propose(handle, parsed, session.signal);
      callbacks.changed();
      return {
        status: value.status === 'active' ? 'saved' : 'needs_confirmation',
        id: value.id,
        revision: value.revision,
        verification: value.verification,
      };
    }
    if (name === 'prepare_action') {
      if (session.ephemeral || contract.worldId !== 'real' || contract.actionMode === 'respond') {
        const draft = { ...args, id: randomUUID(), saved: false };
        callbacks.action(draft);
        return {
          prepared: true,
          saved: false,
          status: 'draft_only',
          item: draft,
          note: '仅比较草稿；尚未获得保存或执行授权。',
        };
      }
      const pack = session.pack || (await this.compile(session)),
        taskText = args.title + ' ' + args.detail;
      const activity = /^(?:核对|确认|查询|整理|查看)/.test(args.title)
        ? 'local_note'
        : /跑步|晨跑|夜跑/.test(taskText)
          ? 'outdoor_run'
          : /项目|编程/.test(taskText)
            ? 'project_work'
            : 'local_note';
      const candidate = {
        id: randomUUID(),
        title: args.title,
        activity,
        location: /回家|回宿舍/.test(taskText) ? 'home' : undefined,
        startsAt: args.startsAt,
        endsAt:
          args.startsAt && args.durationMinutes
            ? new Date(Date.parse(args.startsAt) + args.durationMinutes * 60000).toISOString()
            : undefined,
        needs: [],
        dependencies: [],
        resourceCapabilities: [],
        preservesUnstructuredTime: false,
        rationale: args.detail,
      };
      if (activity !== 'local_note' || args.startsAt)
        await this.context.expand(pack, this.work.introducedNeeds(candidate), session.signal);
      const verified = this.work.validatePlan(
        contract,
        candidate,
        pack.needs,
        pack.assertions,
        pack.data.currentFacts as any,
      );
      if (verified.violations.length)
        throw new HarnessError('plan_constraint_violation', '这项建议与当前明确限制冲突，未生成可确认动作。');
      const dependencies = [
        ...[...new Set([...pack.receipt.providedEvidenceIds, ...(pack.receipt.providedSourceIds || [])])].map(
          (id) => ({
            consumerId: 'pending',
            producerId: id,
            producerRevision: 0,
            sensitivity: 'privacy' as const,
            invalidation: 'block' as const,
          }),
        ),
        ...session.events.map((e) => ({
          consumerId: 'pending',
          producerId: e.id,
          producerRevision: e.contentVersion,
          sensitivity: 'hard' as const,
          invalidation: 'block' as const,
        })),
        ...pack.assertions.map((a) => ({
          consumerId: 'pending',
          producerId: a.id,
          producerRevision: a.revision,
          sensitivity: a.strength === 'hard' ? ('hard' as const) : ('soft' as const),
          invalidation: 'revalidate' as const,
        })),
      ];
      const directLocal = !!contract.interpretation?.directLocalWrite;
      const unresolvedForDirect = verified.unresolvedNeeds.filter(
        (need) => {
          if (directLocal && need === 'user_choice') return false;
          const declared = verified.needs.find((candidateNeed) =>
            [candidateNeed.id, candidateNeed.key].includes(need),
          );
          // Conditional evidence improves the registration, but only a
          // missing must-need (or an unclassified hard ambiguity) blocks an
          // explicit, reversible local write.
          return declared ? declared.importance === 'must' : true;
        },
      );
      if (directLocal && !verified.violations.length && !unresolvedForDirect.length) {
        const executed = await this.actions.directLocal(
          handle,
          {
            id:
              'direct:' +
              createHash('sha256')
                .update(
                  canonical({
                    eventId: session.events[0]?.id || contract.id,
                    capability: 'local.agenda.save',
                    arguments: args,
                  }),
                )
                .digest('hex'),
            capability: 'local.agenda.save',
            arguments: args,
            dependencies,
            // This boolean is derived from the host-validated interpretation,
            // never from the model's tool arguments.
            authorized: true,
          },
          session.signal,
        );
        const item = {
          ...args,
          id: executed.action.id,
          saved: true,
          revision: executed.action.revision,
          approvalDigest: executed.action.digest,
          coverage: 'verified' as const,
          missingNeeds: [],
        };
        callbacks.action(item);
        callbacks.changed();
        return {
          prepared: true,
          saved: true,
          executionTier: 'direct_local',
          status: executed.receipt.status,
          item,
          receipt: {
            id: executed.receipt.id,
            status: executed.receipt.status,
            localStatus: executed.receipt.localStatus,
            observedAt: executed.receipt.observedAt,
          },
          undo: { actionId: executed.action.id, operation: 'cancel_local_action' },
        };
      }
      const prepared = this.actions.prepare(handle, {
        capability: 'local.agenda.save',
        arguments: args,
        dependencies,
      });
      const item = {
        ...args,
        id: prepared.id,
        saved: false,
        revision: prepared.revision,
        approvalDigest: prepared.digest,
        coverage: verified.feasibility,
        missingNeeds: verified.unresolvedNeeds,
      };
      callbacks.action(item);
      return { prepared: true, saved: false, status: 'awaiting_approval', item };
    }
    if (name === 'set_plan') {
      const items = (args.items as Obligation[]).map((i) => ({
        ...i,
        status:
          i.status === 'done' &&
          !this.broker.invocations.some((v) => v.scopeId === handle.id && v.status === 'fresh')
            ? ('blocked' as const)
            : i.status,
      }));
      callbacks.plan(items);
      return { ok: true, scope: 'run_steps_only' };
    }
    if (name === 'delegate') return callbacks.delegate(args.tasks);
    if (name === 'inspect_action')
      return args.reconcile
        ? this.actions.reconcile(handle, args.id, session.signal)
        : { action: this.actions.get(handle, args.id), receipts: this.actions.receipts(handle, args.id) };
    if (name === 'update_work_state') {
      const recordDerivation = (id: string) => {
        for (const source of new Set([
          ...(session.pack?.receipt.providedEvidenceIds || session.events.map((e) => e.id)),
          ...(session.pack?.receipt.providedSourceIds || []),
        ]))
          this.repo.addDependency(handle, {
            consumerId: id,
            producerId: source,
            producerRevision: 0,
            sensitivity: 'privacy',
            invalidation: 'revalidate',
          });
      };
      const mutate = <T extends { id: string }>(write: () => T): T =>
        this.repo.write(() => {
          const item = write();
          recordDerivation(item.id);
          return item;
        });
      if (args.operation === 'propose_options') {
        if (!session.episodeId) throw new HarnessError('episode_missing', '先在当前对话确定要比较的事项。');
        const options = args.options.map((option: { title: string; rationale: string }) => ({
          id: randomUUID(),
          title: option.title,
          data: { rationale: option.rationale },
        }));
        this.repo.write(() => {
          this.work.addOptions(
            handle,
            session.episodeId!,
            options,
            options.map((o: { id: string }) => o.id),
          );
          for (const option of options) recordDerivation(option.id);
          recordDerivation(session.episodeId!);
        });
        return {
          options: options.map((o: { id: string; title: string }, index: number) => ({
            id: o.id,
            ordinal: index + 1,
            title: o.title,
          })),
          status: 'proposals_only',
          instruction: '按返回顺序呈现；后续第二个等引用使用稳定选项。',
        };
      }
      if (args.operation === 'reject_option') {
        if (!session.ingress.authoredText.includes(args.sourceQuote))
          throw new HarnessError('unsupported_evidence', '拒绝理由需要本轮原话。');
        const old = this.repo.work(handle, 'option').find((o) => o.id === args.id);
        if (!old) throw new HarnessError('option_missing', '选项不存在。');
        if (args.permanent && !/永远|无论|明确禁止|不要再推荐|不再考虑/.test(args.sourceQuote))
          throw new HarnessError('unsupported_permanent_rejection', '这段话不足以成为永久拒绝条件。');
        return mutate(() =>
          this.work.update(handle, old.id, args.expectedRevision, {
            status: 'rejected',
            data: {
              ...old.data,
              rejection: { reason: args.sourceQuote, validWhen: args.validWhen, permanent: args.permanent },
              rejectionStillApplicable: true,
            },
          }),
        );
      }
      if (args.operation === 'checkpoint') {
        const old = this.repo.work(handle, 'episode').find((e) => e.id === args.episodeId);
        return mutate(() =>
          this.work.update(handle, args.episodeId, args.expectedRevision, {
            data: {
              ...old?.data,
              nextSmallQuestion: args.nextSmallQuestion,
              openQuestions: args.openQuestions,
            },
          }),
        );
      }
      if (args.operation === 'propose_goal')
        return mutate(() =>
          this.work.create(
            handle,
            'goal',
            args.title,
            { reason: args.reason },
            { status: 'proposed', evidenceIds: [session.events[0].id] },
          ),
        );
      if (args.operation === 'propose_task') {
        if (!session.ingress.authoredText.includes(args.sourceQuote))
          throw new HarnessError('unsupported_evidence', '任务提议缺少本轮原话。');
        return mutate(() =>
          this.work.create(
            handle,
            'task',
            args.title,
            { kind: args.kind, proposed: true },
            { status: 'draft', evidenceIds: [session.events[0].id] },
          ),
        );
      }
      const pack = session.pack || (await this.compile(session));
      await this.context.expand(pack, this.work.introducedNeeds(args.candidate), session.signal);
      const plan = this.work.validatePlan(
        contract,
        args.candidate,
        pack.needs,
        pack.assertions,
        pack.data.currentFacts as any,
      );
      mutate(() => this.work.savePlan(contract, plan, [session.events[0].id]));
      return plan;
    }
    throw new HarnessError('tool_unavailable', '工具尚未实现。');
  }
  private async lookUp(session: RunSession, args: z.infer<typeof lookUpSchema>) {
    if (session.ingress.contract.interactionMode === 'listen') {
      const scope = this.policy.validate(session.ingress.contract.scope),
        allowed = new Set(
          session.ingress.contract.interpretation?.fragments
            .filter(
              (fragment) =>
                fragment.intents.includes('retrieve') &&
                fragment.subjectId === scope.principalId &&
                fragment.worldId === 'real',
            )
            .flatMap((fragment) => fragment.readSources) || [],
        );
      if (!allowed.has(args.source))
        throw new HarnessError('tool_forbidden', '这项读取没有对应的明确子请求。');
    }
    if (
      this.policy.validate(session.ingress.contract.scope).child &&
      (args.mode === 'refresh' || args.refresh)
    )
      throw new HarnessError('child_refresh', '只读分身不能刷新外部连接器。');
    if (
      (args.mode === 'refresh' || args.refresh) &&
      !/(最新|刷新|同步|更新|refresh|latest)/i.test(session.ingress.authoredText)
    )
      throw new HarnessError('refresh_not_requested', '刷新来源需要本轮明确请求。');
    const handle = session.ingress.contract.scope,
      call = async (capability: string, input: unknown) => {
        const result = await this.broker.invoke(handle, capability, input, session.signal, {
          refresh: args.mode === 'refresh' || args.refresh,
          maxCalls: session.ingress.contract.budget.toolCalls,
        });
        if (session.pack) this.context.recordTool(session.pack, result, capability);
        return result;
      };
    if (args.source === 'history') return call('evidence.search', { query: args.query || '' });
    if (args.source === 'weather') return call('weather.lookup', { days: args.days || 3 });
    if (args.source === 'map') return call('map.search', { query: args.query || '' });
    if (args.source === 'local') return call('local.agenda.read', { query: args.query });
    if (args.source === 'capability') {
      if (!args.capability) return { capabilities: this.broker.discover(handle) };
      const description = this.broker.describe(args.capability);
      if (description && description.effect !== 'read')
        throw new HarnessError('effect_forbidden', '查找入口只能调用只读能力。');
      return call(args.capability, args.arguments || {});
    }
    const text = session.ingress.authoredText;
    const relevant = new Set<string>();
    if (args.domain) relevant.add(args.domain);
    else {
      if (/全部.*校园资料|所有.*校园资料|完整.*校园资料|校园资料总览/.test(text))
        for (const domain of [
          'schedule',
          'courses',
          'exams',
          'assignments',
          'grades',
          'gpa',
          'practice',
          'reservations',
          'card',
          'transactions',
          'profile',
          'holidays',
          'source_status',
        ])
          relevant.add(domain);
      if (/课表|课程|学业|校园|所有|资料|安排/.test(text)) relevant.add('schedule');
      if (/考试|所有|全部/.test(text)) relevant.add('exams');
      if (/体育|打卡|实践|所有|全部/.test(text)) relevant.add('sports');
      if (/成绩|绩点/.test(text)) relevant.add('grades');
      if (!relevant.size) relevant.add('source_status');
    }
    const input = (domain: string) => ({
      domain,
      query: args.query,
      from: args.from,
      to: args.to,
      at: args.at,
      timeMode: args.timeMode,
      fields: args.fields,
      filters: args.filters,
      sort: args.sort,
      offset: args.offset,
      window: args.window,
      limit: args.limit || 12,
      refresh: args.mode === 'refresh' || !!args.refresh,
    });
    if (relevant.size > 1) {
      const batches = [];
      for (const domain of relevant)
        batches.push({ domain, result: await call('campus.lookup', input(domain)) });
      return { status: batches.every((b) => b.result.status === 'fresh') ? 'fresh' : 'partial', batches };
    }
    return call('campus.lookup', input([...relevant][0]));
  }
  finish(session: RunSession) {
    if (session.ephemeral) {
      for (const e of session.events) this.ephemeralEvents.delete(e.id);
      session.events = [];
      session.ingress = {
        ...session.ingress,
        text: '',
        authoredText: '',
        corrections: [],
        attachment: undefined,
      };
      if (session.pack) {
        session.pack.evidence = [];
        session.pack.currentText = '';
        session.pack.data = {};
      }
    }
    if (session.pack) {
      try {
        this.repo.saveReceipt(session.ingress.contract.scope, session.pack.receipt);
      } catch {}
    }
  }
  saveMemoryControl(text: string, id?: string) {
    return this.memory.saveControl(text, id);
  }
  memories(): Memory[] {
    return this.memory.views();
  }
  async acceptLocal(item: Action) {
    const handle = this.policy.hostScope();
    let action = this.actions.get(handle, item.id);
    if (
      action &&
      ['cancelled', 'cancel_requested', 'cancellation_confirmed', 'cannot_cancel'].includes(action.status)
    )
      throw new HarnessError('stale_action', '这项建议的依据已变化，请重新生成或选择当前方案。');
    if (action && item.revision !== undefined && item.revision !== action.revision)
      throw new HarnessError('revision_conflict', '你看到的动作版本已更新，请重新查看后确认。');
    if (action && item.approvalDigest !== undefined && item.approvalDigest !== action.digest)
      throw new HarnessError('approval_mismatch', '待确认内容已经变化，请重新查看。');
    if (!action) {
      // Only a genuine offered card or an existing local record can enter the legacy compatibility path.
      const offered = this.store.db
        .prepare("SELECT payload FROM messages WHERE role='assistant'")
        .all()
        .some((r) => (JSON.parse(String(r.payload)).actions || []).some((a: Action) => a.id === item.id));
      if (!offered) throw new HarnessError('unknown_action', '请从当前建议卡确认具体安排。');
      action = this.actions.prepare(handle, {
        id: item.id,
        capability: 'local.agenda.save',
        arguments: localArgs(item),
      });
    } else if (canonical(action.arguments) !== canonical(localArgs(item)))
      action = this.actions.revise(handle, action.id, action.revision, localArgs(item));
    const approval = this.actions.approve(handle, action.id, action.digest, action.revision);
    const receipt = await this.actions.execute(handle, action.id, approval.id);
    if (item.done) {
      this.store.writeAgendaProjection({ ...item, saved: true, done: true });
      this.reminders.cancel(item.id);
    }
    return receipt;
  }
}
function localArgs(item: Action) {
  return {
    title: item.title,
    detail: item.detail,
    ...(item.startsAt ? { startsAt: item.startsAt } : {}),
    ...(item.durationMinutes ? { durationMinutes: item.durationMinutes } : {}),
    ...(item.demo ? { demo: true } : {}),
  };
}

import { spawn, spawnSync, type ChildProcess } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import type { Store } from './store';

export type CampusDomain =
  | 'schedule'
  | 'courses'
  | 'exams'
  | 'assignments'
  | 'grades'
  | 'gpa'
  | 'practice'
  | 'reservations'
  | 'card'
  | 'transactions'
  | 'profile'
  | 'holidays'
  | 'source_status';
export type CampusRefreshScope = 'academic' | 'domain';

export interface CampusReadArgs {
  domain: CampusDomain;
  window?: string;
  from?: string;
  to?: string;
  at?: string;
  timeMode?: 'overlap' | 'starts' | 'contained';
  fields?: string[];
  filters?: string[];
  sort?: string;
  limit?: number;
  offset?: number;
  refresh?: boolean;
}
export interface CampusRefreshArgs {
  scope: CampusRefreshScope;
  domain?: CampusDomain;
  academicYear?: string;
  term?: '1' | '2';
}
export interface CampusConnectorState {
  configured: boolean;
  available: boolean;
  label: string;
  catalogued?: number;
  verified?: number;
  blocked?: number;
  credentialsConfigured?: boolean;
  reason?: string;
}

export interface CampusFullContextArgs {
  refresh?: boolean;
  includeSensitiveDomains?: boolean;
  academicYear?: string;
  term?: '1' | '2';
}

const DOMAIN_RESOURCE: Record<CampusDomain, string> = {
  schedule: 'classes',
  courses: 'courses',
  exams: 'exams',
  assignments: 'todos',
  grades: 'grades',
  gpa: 'gpa_overall',
  practice: 'practice_summary',
  reservations: 'reservations',
  card: 'card_accounts',
  transactions: 'transactions',
  profile: 'student_profile',
  holidays: 'holidays',
  source_status: 'source_status',
};

const DOMAIN_ENDPOINT: Partial<Record<CampusDomain, string>> = {
  reservations: 'booking.seats',
  card: 'ecard.cards',
  transactions: 'ecard.transactions',
  profile: 'eta.profile',
};

const SUMMARY_FIELDS: Partial<Record<CampusDomain, string[]>> = {
  schedule: ['uid', 'summary', 'startTime', 'endTime', 'location', 'teacher', 'rescheduled', 'time_precision'],
  courses: ['key', 'name', 'semester_id', 'credit', 'teachers', 'confirmed', 'online'],
  exams: ['id', 'name', 'type', 'startTime', 'endTime', 'dateLabel', 'location', 'seat', 'time_precision'],
  assignments: ['id', 'name', 'course', 'deadline', 'status'],
  grades: ['id', 'name', 'semester_id', 'credit', 'original', 'fivePoint', 'gpaIncluded', 'gpa_exclusion_reason'],
  practice: ['items', 'calculated_approved_points', 'official_summary'],
  reservations: ['id', 'nameMerge', 'no', 'startTime', 'endTime', 'statusName', 'signInTime'],
  transactions: ['occurred_at', 'resume', 'tranamt', 'cardBalance', 'amount_unit'],
  card: ['status', 'state', 'db_balance', 'balance', 'amount_unit'],
  profile: ['departmentName', 'professionName', 'className'],
};
const SAFE_MODEL_FIELDS = new Set([
  ...Object.values(SUMMARY_FIELDS).flat(),
  'date', 'dateLabel', 'title', 'name', 'status', 'source', 'updatedAt', 'fetched_at',
  'startTime', 'endTime', 'location', 'teacher', 'summary', 'deadline', 'credit', 'amount_unit',
]);

const DOMAIN_LABEL: Record<CampusDomain, string> = {
  schedule: '逐次课程',
  courses: '课程与教学班',
  exams: '考试安排',
  assignments: '作业与待办',
  grades: '成绩记录',
  gpa: '绩点汇总',
  practice: '实践与体育相关记录',
  reservations: '图书馆预约',
  card: '校园卡账户',
  transactions: '校园卡流水',
  profile: '学生资料',
  holidays: '校历与假期',
  source_status: '数据连接状态',
};

// High-level resources are backed by complete encrypted datasets in the external
// connector. Reading them gives the model a bounded index without mistaking the
// connector's diagnostic endpoint samples for complete personal data.
const FULL_CONTEXT_DOMAINS: CampusDomain[] = [
  'schedule',
  'courses',
  'exams',
  'assignments',
  'grades',
  'gpa',
  'practice',
  'reservations',
  'card',
  'transactions',
  'profile',
  'holidays',
  'source_status',
];
const SENSITIVE_DOMAINS = new Set<CampusDomain>(['reservations', 'card', 'transactions', 'profile']);
const DIRECT_REFRESH_DOMAINS = new Set<CampusDomain>(['reservations', 'card', 'transactions', 'profile']);

function safeRoot(candidate: string | null | undefined): string | null {
  if (!candidate?.trim()) return null;
  const root = path.resolve(candidate.trim());
  if (!existsSync(path.join(root, 'scripts', 'zju.py')) || !existsSync(path.join(root, 'references', 'endpoints.json')) || !existsSync(path.join(root, 'SKILL.md')) || !existsSync(path.join(root, 'LICENSE'))) return null;
  return root;
}

function parseJson(output: string): any {
  const trimmed = output.trim();
  if (!trimmed) throw new Error('连接器没有返回结果。');
  try {
    return JSON.parse(trimmed);
  } catch {
    throw new Error('连接器返回的不是有效 JSON。');
  }
}

function stopProcess(child: ChildProcess) {
  if (!child.pid) return;
  if (process.platform === 'win32') {
    spawnSync('taskkill', ['/pid', String(child.pid), '/t', '/f'], { windowsHide: true, stdio: 'ignore' });
  } else {
    child.kill('SIGTERM');
  }
}

function compactResult(result: any, domain?: CampusDomain): any {
  if (!result || typeof result !== 'object') return result;
  const output: any = {
    status: result.status,
    fetched_at: result.fetched_at,
    endpoint: result.endpoint,
    source: result.source,
    validation: result.validation,
    query: result.query,
    returned: result.returned,
    server_returned_count: result.server_returned_count,
    pagination: result.pagination,
    data_path: result.data_path,
    changes: result.changes,
    completeness: result.completeness,
    issues: result.issues,
    empty_result: result.empty_result,
    note: result.note,
    error: result.error,
    retrieved_at: result.retrieved_at,
    stale: result.stale,
    freshness: result.freshness,
    resource: result.resource,
    operation: result.operation,
    evaluated_at: result.evaluated_at,
    time_interval: result.time_interval,
    total_matches: result.total_matches,
    offset: result.offset,
    next_offset: result.next_offset,
    unknown_time_records: result.unknown_time_records,
    coverage: result.coverage,
    metric_quality: result.metric_quality,
    measurement_notes: result.measurement_notes,
    credential_redactions: result.credential_redactions,
    nested_values_truncated: result.nested_values_truncated,
    schema_version: result.schema_version,
    semester_id: result.semester_id,
    counts: result.counts,
    grade_attempts: result.grade_attempts,
    practice_projects: result.practice_projects,
    data_quality: result.data_quality,
    schedule_coverage: result.schedule_coverage,
    sections: result.sections,
    raw_data_preserved: result.raw_data_preserved,
    normalization_error_type: result.normalization_error_type,
    message: result.message,
    requested: result.requested,
    executed: result.executed,
  };
  if ('records' in result) output.records = sanitize(result.records);
  if ('results' in result) output.results = sanitize(result.results);
  if ('result' in result) output.result = sanitize(result.result);
  if (domain === 'source_status' && result.resources) output.resources = result.resources;
  if ('normalized' in result) output.normalized = sanitize(result.normalized);
  if ('bundle_id' in result) output.bundle_id = result.bundle_id;
  const safeOutput = sanitize(output);
  let serialized = JSON.stringify(safeOutput);
  if (serialized.length <= 56000) return safeOutput;
  if (safeOutput.normalized) delete safeOutput.normalized;
  if (Array.isArray(safeOutput.results)) safeOutput.results = safeOutput.results.slice(0, 8);
  if (Array.isArray(safeOutput.records)) {
    safeOutput.records = safeOutput.records.slice(0, 12);
  }
  safeOutput.truncated_for_model = true;
  safeOutput.note = '连接器保留完整加密数据；本次只返回有界摘要。请缩小时间范围或字段后继续。';
  serialized = JSON.stringify(safeOutput);
  if (serialized.length > 56000 && Array.isArray(safeOutput.results)) safeOutput.results = safeOutput.results.slice(0, 3);
  return safeOutput;
}

function sanitize(value: any, key = '', depth = 0): any {
  if (depth > 12) return '[depth limit]';
  if (/(password|passwd|token|ticket|cookie|authorization|synjones|secret|openid|unionid|accesskey|qrcode|qr_code|barcode|voucher|body_b64|student.?no|student.?id|card.?no|card_number|identity.?no|identity.?id|id.?card|phone|mobile|email|身份证|学号|手机号|邮箱|account)/i.test(key)) return '[redacted]';
  if (typeof value === 'string') {
    return value
      .replace(/(token|ticket|code|synjones-auth|password)=[^&\s"<>]+/gi, '$1=[redacted]')
      .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[redacted]');
  }
  if (Array.isArray(value)) return value.map(item => sanitize(item, key, depth + 1));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, sanitize(v, k, depth + 1)]));
  return value;
}

export class ZjuAdapter {
  constructor(private store: Store) {}

  private root(): string | null {
    if (this.store.meta<boolean>('zju_source_disabled', false)) return null;
    return safeRoot(this.store.meta<string | null>('zju_source_root', null))
      || safeRoot(process.env.ZAICHANG_ZJU_SOURCE)
      || safeRoot(path.resolve(process.cwd(), 'integrations', 'zju-student-info'));
  }

  describe(): CampusConnectorState {
    const root = this.root();
    if (!root) return { configured: false, available: false, label: '浙大个人信息连接器', credentialsConfigured: false, reason: '尚未选择连接器目录。' };
    try {
      const verificationPath = path.join(root, 'references', 'verification-latest.json');
      const verification = existsSync(verificationPath) ? JSON.parse(readFileSync(verificationPath, 'utf8')) : null;
      return {
        configured: true,
        available: true,
        label: '浙大个人信息连接器',
        catalogued: Number(verification?.total_catalogued || 0) || undefined,
        verified: Number(verification?.passed || 0) || undefined,
        blocked: Number(verification?.blocked || 0) || undefined,
        credentialsConfigured: this.credentialsConfigured(),
        reason: this.credentialsConfigured() ? undefined : '尚未在本机凭据窗口保存校园账号。',
      };
    } catch {
      return { configured: true, available: true, label: '浙大个人信息连接器', credentialsConfigured: this.credentialsConfigured(), reason: '目录可用，验证摘要暂不可读。' };
    }
  }

  private credentialsConfigured(): boolean {
    const base = process.env.LOCALAPPDATA;
    return !!base && existsSync(path.join(base, 'CodexZjuStudentInfo', 'credentials.dpapi'));
  }

  configure(root: string): CampusConnectorState {
    const safe = safeRoot(root);
    if (!safe) throw new Error('所选目录不是可识别的浙大个人信息连接器。');
    this.store.putMeta('zju_source_root', safe);
    this.store.putMeta('zju_source_disabled', false);
    return this.describe();
  }

  disconnect() {
    this.store.putMeta('zju_source_root', null);
    this.store.putMeta('zju_source_disabled', true);
  }

  async configureCredentials(): Promise<void> {
    const root = this.root();
    if (!root) throw new Error('请先选择浙大个人信息连接器目录。');
    const python = process.env.ZAICHANG_PYTHON || 'python';
    const child = spawn(python, [path.join(root, 'scripts', 'zju.py'), 'credentials', 'set'], {
      cwd: root,
      env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
      windowsHide: false,
      shell: false,
      stdio: ['ignore', 'ignore', 'ignore'],
    });
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => { stopProcess(child); reject(new Error('凭据窗口等待超时。')); }, 180_000);
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error('凭据未保存。')); });
    });
  }

  async run(args: string[], signal: AbortSignal, timeoutMs = 45_000): Promise<any> {
    const root = this.root();
    if (!root) return { status: 'unavailable', reason: '浙大个人信息连接器尚未配置。', connector: this.describe() };
    const python = process.env.ZAICHANG_PYTHON || 'python';
    const script = path.join(root, 'scripts', 'zju.py');
    const child = spawn(python, [script, ...args], {
      cwd: root,
      env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
      windowsHide: true,
      shell: false,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '', stderr = '', settled = false;
    const finish = (fn: () => void) => { if (!settled) { settled = true; fn(); } };
    const output = await new Promise<{ code: number | null; stdout: string; stderr: string }>((resolve, reject) => {
      const timer = setTimeout(() => { stopProcess(child); finish(() => reject(new Error('校园连接器超过本轮时间上限，已停止。'))); }, timeoutMs);
      const abort = () => { clearTimeout(timer); stopProcess(child); finish(() => reject(signal.reason || new DOMException('已停止', 'AbortError'))); };
      signal.addEventListener('abort', abort, { once: true });
      child.stdout.on('data', chunk => { stdout += String(chunk); if (stdout.length > 1_200_000) abort(); });
      child.stderr.on('data', chunk => { stderr = (stderr + String(chunk)).slice(0, 4000); });
      child.on('error', error => { clearTimeout(timer); signal.removeEventListener('abort', abort); finish(() => reject(error)); });
      child.on('close', code => { clearTimeout(timer); signal.removeEventListener('abort', abort); finish(() => resolve({ code, stdout, stderr })); });
    });
    let parsed: any;
    try { parsed = parseJson(output.stdout); } catch { throw new Error('校园连接器输出异常，请检查其本地 Python 环境。'); }
    if (output.code !== 0 && parsed.status !== 'partial') {
      const error = parsed.error || { code: 'CONNECTOR_ERROR', message: '校园连接器没有完成请求。' };
      return { status: 'error', error, stderr: output.stderr.slice(0, 500), connector: this.describe() };
    }
    return parsed;
  }

  async capabilities(signal: AbortSignal) {
    const root = this.root();
    if (!root) return { status: 'unavailable', reason: '浙大个人信息连接器尚未配置。', connector: this.describe() };
    try {
      const registry = JSON.parse(readFileSync(path.join(root, 'references', 'endpoints.json'), 'utf8'));
      const endpoints = Array.isArray(registry.endpoints) ? registry.endpoints : [];
      const counts = endpoints.reduce((acc: Record<string, number>, item: any) => { const key = String(item.status || 'unknown'); acc[key] = (acc[key] || 0) + 1; return acc; }, {});
      return { status: this.credentialsConfigured() ? 'ok' : 'auth_required', connector: this.describe(), resources: counts, catalogued: endpoints.length, note: '只读本地连接器目录，没有读取个人记录。' };
    } catch {
      return { status: 'error', connector: this.describe(), reason: '无法读取连接器目录。' };
    }
  }

  async fullContext(args: CampusFullContextArgs, signal: AbortSignal) {
    const connector = this.describe();
    if (!connector.available) return { status: 'unavailable', connector, reason: connector.reason };
    if (!connector.credentialsConfigured) return { status: 'auth_required', connector, reason: '请在资料面板设置本机校园账号后再读取。' };
    const started = Date.now();
    const batches: any[] = [];
    const budgetMs = args.refresh ? 150_000 : 90_000;
    const deadline = Date.now() + budgetMs;
    const fullSignal = AbortSignal.any([signal, AbortSignal.timeout(budgetMs)]);
    const domains = args.includeSensitiveDomains === false
      ? FULL_CONTEXT_DOMAINS.filter(domain => !SENSITIVE_DOMAINS.has(domain))
      : FULL_CONTEXT_DOMAINS;
    const expectedScopes: string[] = [...(args.refresh ? ['academic'] : []), ...domains];
    let budgetExhausted = false;
    // Academic sync is a single normalized operation. It is only refreshed when the model
    // has an explicit freshness reason; the default path reads the existing encrypted bundle.
    if (args.refresh) {
      try {
        const academic = await this.run(['academic', '--year', args.academicYear || this.defaultAcademicYear(), '--term', args.term || '1'], fullSignal, Math.max(1_000, deadline - Date.now()));
        batches.push({ scope: 'academic', data: compactResult(academic) });
      } catch (error) {
        if (signal.aborted) throw error;
        batches.push({ scope: 'academic', data: { status: 'partial', error: error instanceof Error ? error.message : '学业资料读取未完成' } });
      }
    }
    // A small bounded fan-out keeps the overview responsive without opening a
    // request storm against the school systems. Results are reassembled in the
    // stable domain order so the model sees one predictable index.
    for (let offset = 0; offset < domains.length; offset += 3) {
      if (signal.aborted) throw signal.reason;
      if (fullSignal.aborted || Date.now() >= deadline) { budgetExhausted = true; break; }
      const chunk = domains.slice(offset, offset + 3);
      const results = await Promise.all(chunk.map(async (domain) => {
        try {
          const shouldRefresh = !!args.refresh && DIRECT_REFRESH_DOMAINS.has(domain);
          const readResult = await this.read({ domain, refresh: shouldRefresh }, fullSignal);
          return { scope: domain, data: compactResult(readResult.data, domain) };
        } catch (error) {
          if (signal.aborted) throw error;
          return { scope: domain, data: { status: 'error', error: error instanceof Error ? error.message : '领域读取失败' } };
        }
      }));
      batches.push(...results);
      if (fullSignal.aborted || Date.now() >= deadline) { budgetExhausted = true; break; }
    }
    const completedScopes = batches.flatMap(batch => {
      const status = String(batch.data?.status || 'ok');
      return ['ok', 'partial'].includes(status)
        ? (Array.isArray(batch.scope) ? batch.scope : [batch.scope])
        : [];
    });
    const missingScopes = expectedScopes.filter(scope => !completedScopes.includes(scope));
    const incompleteScopes = batches.flatMap(batch => {
      const status = String(batch.data?.status || 'ok');
      return status === 'partial' || batch.data?.stale === true || batch.data?.coverage?.complete === false
        ? (Array.isArray(batch.scope) ? batch.scope : [batch.scope])
        : [];
    });
    const batchStatuses = batches.map(batch => String(batch.data?.status || batch.data?.data?.status || 'ok'));
    const hasIncomplete = batches.some(batch => batch.data?.stale === true || batch.data?.freshness?.stale === true || batch.data?.completeness?.complete === false || batch.data?.coverage?.complete === false || batch.data?.data_quality?.all_requested_sources_complete === false);
    const status = budgetExhausted || missingScopes.length || hasIncomplete || batchStatuses.some(s => ['error', 'auth_required', 'unavailable'].includes(s))
      ? 'partial'
      : batchStatuses.includes('partial') ? 'partial' : 'ok';
    return {
      status,
      connector,
      refreshed: !!args.refresh,
      elapsedMs: Date.now() - started,
      missingScopes,
      incompleteScopes,
      budgetExhausted,
      expectedScopes,
      source: 'zju-student-info complete encrypted datasets via quick/academic',
      batches,
      note: '这是本人完整加密数据集的分域读取索引；每个分域只给模型少量必要字段，原始字段与完整分页仍在连接器中。预约/签到/支付/修改资料未执行。',
    };
  }

  private defaultAcademicYear(): string {
    const now = new Date();
    const start = now.getMonth() >= 7 ? now.getFullYear() : now.getFullYear() - 1;
    return `${start}-${start + 1}`;
  }

  async read(args: CampusReadArgs, signal: AbortSignal) {
    const connector = this.describe();
    if (!connector.available) return { domain: args.domain, label: DOMAIN_LABEL[args.domain], cached: !args.refresh, connector, data: { status: 'unavailable', reason: connector.reason } };
    if (!connector.credentialsConfigured) return { domain: args.domain, label: DOMAIN_LABEL[args.domain], cached: !args.refresh, connector, data: { status: 'auth_required', reason: '请先在资料面板设置本机校园账号。' } };
    const resource = DOMAIN_RESOURCE[args.domain];
    const cli = ['quick', resource];
    if (args.window) cli.push('--window', args.window);
    if (args.from) cli.push('--from', args.from);
    if (args.to) cli.push('--to', args.to);
    if (args.at) cli.push('--at', args.at);
    if (args.timeMode) cli.push('--time-mode', args.timeMode);
    const blockedFields = (args.fields || []).filter(field => /(password|token|student.?no|student.?id|card.?no|card_number|identity.?no|identity.?id|id.?card|phone|mobile|email|身份证|学号|手机号|邮箱|account)/i.test(field));
    if (blockedFields.length) throw new Error('为保护本人身份信息，该字段不能作为模型读取字段。');
    const unsupportedFields = (args.fields || []).filter(field => !SAFE_MODEL_FIELDS.has(field));
    if (unsupportedFields.length) throw new Error('该字段不在安全摘要范围内，请缩小到工具提供的可读字段。');
    const fields = args.fields?.length ? args.fields : SUMMARY_FIELDS[args.domain];
    if (fields?.length) cli.push('--fields', fields.join(','));
    for (const filter of args.filters || []) cli.push('--filter', filter);
    if (args.sort) cli.push('--sort', args.sort);
    cli.push('--limit', String(Math.min(50, Math.max(1, args.limit || 8))));
    cli.push('--offset', String(Math.max(0, args.offset || 0)));
    if (args.refresh) cli.push('--refresh');
    const result = await this.run(cli, signal, args.refresh ? 120_000 : 35_000);
    return { domain: args.domain, label: DOMAIN_LABEL[args.domain], cached: !args.refresh, connector: this.describe(), data: compactResult(result, args.domain) };
  }

  async refresh(args: CampusRefreshArgs, signal: AbortSignal) {
    const connector = this.describe();
    if (!connector.available) return { scope: args.scope, label: '校园资料同步', connector, data: { status: 'unavailable', reason: connector.reason } };
    if (!connector.credentialsConfigured) return { scope: args.scope, label: '校园资料同步', connector, data: { status: 'auth_required', reason: '请先在资料面板设置本机校园账号。' } };
    if (args.scope === 'academic') {
      const academicYear = args.academicYear || this.defaultAcademicYear();
      if (!/^20\d{2}-20\d{2}$/.test(academicYear)) throw new Error('同步学业资料需要形如 2026-2027 的学年。');
      const term = args.term || '1';
      const result = await this.run(['academic', '--year', academicYear, '--term', term], signal, 150_000);
      return { scope: args.scope, label: '学业资料同步', connector: this.describe(), data: compactResult(result) };
    }
    if (!args.domain || args.domain === 'source_status') throw new Error('按领域同步时需要指定具体领域。');
    const result = await this.read({ domain: args.domain, refresh: true, limit: 20 }, signal);
    return { ...result, scope: args.scope, label: `${DOMAIN_LABEL[args.domain]}同步` };
  }
}

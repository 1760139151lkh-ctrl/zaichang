import { z } from 'zod';
import type { CampusMapAdapter } from '../mapService';
import type { ZjuAdapter, CampusDomain } from '../zjuAdapter';
import type { DomainService } from '../storage/domains';
import type { KernelRepository } from '../storage/repository';
import type { PolicyKernel } from '../runtime/policy';
import type { CapabilityBroker, CapabilityDefinition, CapabilityProvider, CapabilityResult } from './broker';
import { HarnessError, type KnowledgeStatus } from '../../shared/harness';

export interface BuiltinConnections {
  map?: CampusMapAdapter;
  campus?: ZjuAdapter;
  weatherEnabled: () => boolean;
}
const jsonObject = z.record(z.string(), z.json());
const campusDomains = [
  'schedule',
  'courses',
  'exams',
  'assignments',
  'grades',
  'gpa',
  'practice',
  'sports',
  'reservations',
  'card',
  'transactions',
  'profile',
  'holidays',
  'source_status',
  'places',
  'rules',
] as const;
export const campusInput = z
  .object({
    domain: z.enum(campusDomains),
    query: z.string().max(100).optional(),
    from: z.string().datetime({ offset: true }).optional(),
    to: z.string().datetime({ offset: true }).optional(),
    at: z.string().datetime({ offset: true }).optional(),
    timeMode: z.enum(['overlap', 'starts', 'contained']).optional(),
    fields: z
      .array(z.string().regex(/^[A-Za-z0-9_.-]{1,80}$/))
      .max(24)
      .optional(),
    filters: z.array(z.string().max(160)).max(6).optional(),
    sort: z.string().max(100).optional(),
    offset: z.number().int().min(0).max(10000).optional(),
    window: z.string().max(40).optional(),
    limit: z.number().int().min(1).max(50).default(12),
    refresh: z.boolean().default(false),
  })
  .strict();
export const localActionInput = z
  .object({
    title: z.string().min(1).max(160),
    detail: z.string().max(1500),
    startsAt: z.string().datetime({ offset: true }).optional(),
    durationMinutes: z.number().int().min(1).max(1440).optional(),
    demo: z.boolean().optional(),
  })
  .strict();
const base = (
  name: string,
  input: z.ZodType,
  output: z.ZodType,
  requiredScopes: string[],
  extra: Partial<CapabilityDefinition> = {},
): CapabilityDefinition => ({
  name,
  version: '1',
  input,
  output,
  effect: 'read',
  requiredScopes,
  subjects: ['self'],
  worlds: ['real', 'scenario'],
  timeoutMs: 15000,
  maxBytes: 80000,
  supportsIdempotency: false,
  supportsInspect: false,
  supportsCancel: false,
  ...extra,
});
const manifest = (
  id: string,
  sourceId: string,
  capabilities: CapabilityDefinition[],
  egressHosts: string[] = [],
): CapabilityProvider['manifest'] => ({
  id,
  sourceId,
  version: '1',
  capabilities,
  egressHosts,
  platforms: ['*'],
  simulated: false,
  trust: 'bundled_reviewed',
  offline: 'read_cache',
  license: 'project-owned adapter; underlying sources retain original licenses',
});
function statusOf(value: any): KnowledgeStatus {
  if (value?.stale || value?.freshness?.stale) return 'stale';
  if (value?.status === 'forbidden' || value?.status === 'auth_required') return 'forbidden';
  if (value?.status === 'unavailable' || value?.status === 'unsupported') return 'unsupported';
  if (value?.status === 'error' || value?.status === 'failed') return 'failed';
  if (value?.status === 'conflict') return 'conflict';
  if (
    value?.status === 'partial' ||
    value?.coverage?.complete === false ||
    value?.completeness?.complete === false
  )
    return 'unknown';
  return ['ok', 'fresh'].includes(String(value?.status))
    ? 'fresh'
    : value?.status === 'not_found'
      ? 'not_found'
      : 'unknown';
}
function safeRecord(value: unknown, depth = 0): any {
  if (depth > 12) return null;
  if (Array.isArray(value)) return value.slice(0, 100).map((v) => safeRecord(v, depth + 1));
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.entries(value)
        .filter(
          ([key]) =>
            !/(password|secret|token|cookie|authorization|credential|raw_response|data_path|body_b64|身份证|学号|手机号|email|phone|account)/i.test(
              key,
            ),
        )
        .map(([k, v]) => [k, safeRecord(v, depth + 1)]),
    );
  return typeof value === 'string' ? value.slice(0, 4000) : value;
}
export function registerBuiltins(
  broker: CapabilityBroker,
  policy: PolicyKernel,
  repo: KernelRepository,
  domains: DomainService,
  connections: BuiltinConnections,
) {
  const register = (provider: CapabilityProvider) =>
    broker.register(provider, { reviewed: true, source: 'bundled source review' });
  register({
    manifest: manifest('local-agenda', 'local-agenda', [
      base('local.agenda.save', localActionInput, z.object({}).strict(), ['local:write'], {
        effect: 'local_write',
        worlds: ['real'],
        supportsIdempotency: true,
        supportsInspect: true,
        supportsCancel: true,
      }),
      base(
        'local.agenda.read',
        z.object({ query: z.string().max(100).optional() }).strict(),
        z.object({ items: z.array(jsonObject) }).strict(),
        ['evidence:read'],
      ),
    ]),
    invoke: (name, args, ctx) => {
      if (name === 'local.agenda.save')
        throw new HarnessError('transaction_required', '本地安排必须由受控事务提交。');
      policy.validate(ctx.scope);
      const items = repo.db
        .prepare('SELECT payload FROM agenda')
        .all()
        .map((r) => JSON.parse(String(r.payload)))
        .filter((a) => !a.done && (!args.query || a.title.includes(args.query)));
      return {
        status: items.length ? 'fresh' : 'known_absent',
        sourceId: 'local-agenda',
        data: { items },
        coverage: { complete: true, scope: 'unfinished local agenda' },
        fetchedAt: repo.clock.now(),
        simulated: false,
      };
    },
  });
  register({
    manifest: manifest('campus-read', 'campus:local', [
      base(
        'campus.lookup',
        campusInput,
        z
          .object({
            domain: z.string(),
            records: z.array(jsonObject),
            conflicts: z.array(jsonObject).optional(),
            source: z.string(),
            institutionId: z.string(),
            termId: z.string(),
            live: z.boolean(),
          })
          .strict(),
        ['campus:read'],
        { timeoutMs: 90000 },
      ),
    ]),
    invoke: async (_name, args, ctx) => {
      const sourceId = 'campus:local';
      if (['card', 'transactions', 'profile', 'grades', 'gpa'].includes(args.domain))
        policy.require(ctx.scope, 'campus:' + args.domain + ':read');
      const connector =
        connections.campus && typeof connections.campus.describe === 'function'
          ? connections.campus.describe()
          : { available: !!connections.campus, credentialsConfigured: true };
      if (
        connector?.available &&
        connector.credentialsConfigured !== false &&
        !['sports', 'places', 'rules'].includes(args.domain)
      ) {
        const wrapped = (await connections.campus!.read(
          {
            domain: args.domain as CampusDomain,
            from: args.from,
            to: args.to,
            at: args.at,
            timeMode: args.timeMode,
            fields: args.fields,
            filters: args.filters,
            sort: args.sort,
            offset: args.offset,
            window: args.window,
            limit: args.limit,
            refresh: args.refresh,
          },
          ctx.signal,
        )) as any;
        const result = wrapped?.data && typeof wrapped.data === 'object' ? wrapped.data : wrapped;
        policy.validate(ctx.scope);
        const records = result.records || result.result || [];
        return {
          status: statusOf(result),
          sourceId,
          data: {
            domain: args.domain,
            records: (Array.isArray(records) ? records : [records])
              .map((r: any) => safeRecord(r))
              .filter((r: any) => r && typeof r === 'object' && !Array.isArray(r)),
            source: String(result.source || '浙大个人信息读取器'),
            institutionId: 'zju',
            termId: String(result.semester_id || 'unspecified'),
            live: args.refresh,
          },
          fetchedAt: result.fetched_at || result.evaluated_at,
          expiresAt:
            result.fetched_at && Number.isFinite(Date.parse(result.fetched_at))
              ? new Date(Date.parse(result.fetched_at) + 300000).toISOString()
              : undefined,
          coverage: {
            complete: result.coverage?.complete === true || result.completeness?.complete === true,
            scope: args.domain,
          },
          reason: result.reason,
          simulated: false,
        };
      }
      const metadata = repo.getMeta<{ institutionId: string; termId: string; source: string }>(
        'campus_import_metadata',
      );
      if (!metadata)
        return {
          status: 'unsupported',
          sourceId,
          reason: '校园资料尚未导入，外部连接器未连接。',
          simulated: false,
        };
      const result = domains.resolve(ctx.scope, args.domain === 'practice' ? 'sports' : args.domain, {
        institutionId: metadata.institutionId,
        termId: metadata.termId,
        from: args.from,
        to: args.to,
        query: args.query,
        limit: 6000,
      });
      let records = result.records;
      if (args.from)
        records = records.filter(
          (r) => !r.value.endsAt || Date.parse(String(r.value.endsAt)) > Date.parse(args.from),
        );
      if (args.to)
        records = records.filter(
          (r) => !r.value.startsAt || Date.parse(String(r.value.startsAt)) < Date.parse(args.to),
        );
      if (args.query) records = records.filter((r) => canonicalRecord(r.value).includes(args.query));
      const statuses = result.status === 'conflict' ? 'conflict' : records.length ? 'stale' : 'not_found';
      return {
        status: statuses,
        sourceId,
        data: {
          domain: args.domain,
          records: records.slice(0, args.limit).map((r) => safeRecord(r.value)),
          conflicts: result.conflicts.map((g) => ({ id: g[0].id, sources: g.map((r) => r.sourceId) })),
          source: metadata.source,
          institutionId: metadata.institutionId,
          termId: metadata.termId,
          live: false,
        },
        fetchedAt: records[0]?.fetchedAt,
        coverage: { complete: result.records.length <= args.limit, scope: args.domain },
        reason: '本地导入快照，尚未核实当前学校状态。',
        simulated: false,
      };
    },
  });
  const place = z.object({ kind: z.enum(['place', 'node']), id: z.string().min(1).max(100) }).strict();
  const routeInput = z
    .object({
      from: z.union([place, z.object({ kind: z.literal('current') }).strict()]).optional(),
      to: place.optional(),
      avoidStairs: z.boolean().optional(),
      version: z.string().optional(),
    })
    .strict();
  register({
    manifest: manifest('spatial', 'map:local', [
      base('map.overview', z.object({}).strict(), jsonObject, ['map:read'], {
        subjects: ['self', 'other', 'fictional'],
      }),
      base(
        'map.search',
        z
          .object({ query: z.string().min(1).max(100), limit: z.number().int().min(1).max(10).default(5) })
          .strict(),
        z.object({ matches: z.array(jsonObject) }).strict(),
        ['map:read'],
        { subjects: ['self', 'other', 'fictional'] },
      ),
      base('map.route', routeInput, jsonObject, ['map:read'], { subjects: ['self', 'other', 'fictional'] }),
      base('map.location_status', z.object({}).strict(), jsonObject, ['map:read']),
    ]),
    invoke: (name, args) => {
      if (!connections.map)
        return {
          status: 'unsupported',
          sourceId: 'map:local',
          reason: '地图数据尚未装配。',
          simulated: false,
        };
      const value =
        name === 'map.overview'
          ? connections.map.overview()
          : name === 'map.search'
            ? { matches: connections.map.search(args.query, args.limit) }
            : name === 'map.route'
              ? connections.map.route(args)
              : connections.map.locationStatus();
      const v = value as any,
        status: KnowledgeStatus =
          name === 'map.route' && v.status !== 'ready' && v.status !== 'ok' && v.status !== 'success'
            ? 'unknown'
            : name === 'map.location_status'
              ? 'unknown'
              : 'fresh';
      return {
        status,
        sourceId: 'map:local',
        data: JSON.parse(JSON.stringify(value)),
        fetchedAt: repo.clock.now(),
        coverage: {
          complete: name !== 'map.route' || status === 'fresh',
          scope: 'OSM building entrances and walking graph',
        },
        reason: v.reason,
        simulated: false,
      };
    },
  });
  register({
    manifest: manifest(
      'weather',
      'weather:open-meteo',
      [
        base(
          'weather.lookup',
          z
            .object({
              days: z.number().int().min(1).max(7).default(3),
              location: z.literal('Hangzhou').default('Hangzhou'),
            })
            .strict(),
          z
            .object({
              location: z.string(),
              timeZone: z.string(),
              forecast: z
                .object({
                  time: z.array(z.string()),
                  weather_code: z.array(z.number()),
                  temperature_2m_max: z.array(z.number()),
                  temperature_2m_min: z.array(z.number()),
                  precipitation_probability_max: z.array(z.number()),
                })
                .strict(),
            })
            .strict(),
          ['weather:read'],
        ),
      ],
      ['api.open-meteo.com'],
    ),
    invoke: async (_name, args, ctx) => {
      if (!connections.weatherEnabled())
        return {
          status: 'forbidden',
          sourceId: 'weather:open-meteo',
          reason: '天气查询未开启。',
          simulated: false,
        };
      const url = new URL('https://api.open-meteo.com/v1/forecast');
      url.search = new URLSearchParams({
        latitude: '30.2741',
        longitude: '120.1551',
        daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
        timezone: 'Asia/Shanghai',
        forecast_days: String(args.days),
      }).toString();
      const response = await ctx.request(url.toString());
      if (!response.ok) throw new HarnessError('weather_failed', '天气服务未完成查询。');
      const data = (await response.json()) as any;
      return {
        status: 'fresh',
        sourceId: 'weather:open-meteo',
        data: { location: '杭州城市参考坐标（非用户定位）', timeZone: 'Asia/Shanghai', forecast: data.daily },
        fetchedAt: repo.clock.now(),
        expiresAt: new Date(Date.parse(repo.clock.now()) + 1800000).toISOString(),
        coverage: {
          complete: true,
          scope: 'Hangzhou forecast for ' + args.days + ' days',
          until: data.daily?.time?.at(-1),
        },
        simulated: false,
      };
    },
  });
  register({
    manifest: manifest('evidence', 'history:self', [
      base(
        'evidence.search',
        z.object({ query: z.string().min(1).max(100) }).strict(),
        z.object({ results: z.array(jsonObject) }).strict(),
        ['evidence:read'],
      ),
    ]),
    invoke: (_name, args, ctx) => ({
      status: 'fresh',
      sourceId: 'history:self',
      data: {
        results: repo.searchEvidence(ctx.scope, args.query).map((e) => ({
          id: e.id,
          text: e.text,
          sourceId: e.sourceId,
          contentVersion: e.contentVersion,
          receivedAt: e.receivedAt,
          authority: e.authority,
        })),
      },
      fetchedAt: repo.clock.now(),
      simulated: false,
    }),
  });
}
function canonicalRecord(value: unknown) {
  return JSON.stringify(value);
}

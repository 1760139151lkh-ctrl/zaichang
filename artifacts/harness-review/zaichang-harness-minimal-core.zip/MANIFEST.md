# Minimal executable architecture slice

## Package purpose

This directory is a source-faithful, minimal review slice of the current “在场” Harness. It is not a release, a repository backup, or a rewritten architecture description. Every indexed source, test and fixture is copied byte-for-byte from the working tree at generation time. The ZIP keeps the same repository-relative paths.

## Actual runtime path

The production path is:

`src/renderer/App.tsx:send` → `window.zaichang.send` (`src/shared/types.ts:Bridge`) → `src/main/preload.ts:Bridge.send` → Electron IPC `send` → `src/main/main.ts:handle('send')` (trusted frame/source check and Zod input parse) → `src/main/harness.ts:Harness.start` → `src/main/runtime/coordinator.ts:RuntimeCoordinator.begin` → `PolicyKernel.ingress/hostScope` builds `ContextContract`/`ScopeHandle` and the privacy epoch → `KernelRepository.ingest` writes source events/spans/outbox → `RuntimeCoordinator.compile` → `ContextCompiler.compile` resolves needs, scoped retrieval, current-turn overlay, dependency expansion and receipt → `Harness.run` builds system/campus/map prompts plus serialized `ContextPack` and `generationInput` → `RuntimeCoordinator.toolSpecs/executeTool` and `ToolRegistry` expose only validated capabilities → `DeepSeekClient.complete` serializes the final HTTP body, handles retry/cancellation/SSE/tool calls/reasoning state → the continuation returns to `Harness` and persists message, receipt, memory/work/action projections.`

The final provider request is an actual payload: `src/main/harness.ts` constructs `WireMessage[]`, and `src/main/provider.ts` calls `fetch` with `model`, `messages`, optional tool schemas, `stream: true`, bounded `max_tokens` and thinking state. The Authorization value is supplied at runtime and is not in this package.

The evidence chain is inspectable as `RuntimeCoordinator.begin → KernelRepository.ingest → MemoryService.process/propose → bindModelSemantics extractor/reviewer → MemoryService.commitVerified → ContextCompiler.compile → ContextReceipt → harness payload`. Correction/delete follows `MemoryService.saveControl/forget → PolicyKernel.signalBarrier/privacy epoch → KernelRepository.invalidate/cleanupFence → derived work/actions/messages/receipts/indexes invalidated → next scope rejects the old revision`. Action state follows `prepare_action → ActionRuntime.prepare → approve → execute/Attempt → Receipt`; a lost response becomes `outcome_unknown`, and only `reconcile` can inspect it before a retry.

The repository has one production Harness façade: `src/main/main.ts` imports `src/main/harness.ts`, and `Store` owns one `RuntimeCoordinator`. No separate test-only coordinator substitutes for the Electron path. The package includes real-entry tests and selected synthetic fixtures so this can be checked directly.

## Included files

The machine-readable index is authoritative for the exact file list, SHA-256, category, runtime connection flag, reason, responsibility and symbols. The following is the same index in audit-friendly text:

- `examples/campus.example.json` — Synthetic template loaded by a real IPC handler. Responsibility: Campus import/template contract. Symbols: `campus example JSON`. [contract; runtime_connected=true]
- `index.html` — Minimal build/runtime metadata needed to identify the actual entry and dependency versions. Responsibility: Build and dependency boundary. Symbols: `package/build configuration`. [runtime; runtime_connected=false]
- `package-lock.json` — Minimal build/runtime metadata needed to identify the actual entry and dependency versions. Responsibility: Build and dependency boundary. Symbols: `package/build configuration`. [contract; runtime_connected=false]
- `package.json` — Minimal build/runtime metadata needed to identify the actual entry and dependency versions. Responsibility: Build and dependency boundary. Symbols: `package/build configuration`. [runtime; runtime_connected=false]
- `prompts/campus-tools.md` — Prompt text loaded by the production Harness before the provider request. Responsibility: System, campus and map instruction boundaries. Symbols: `default text module`. [contract; runtime_connected=true]
- `prompts/map-tools.md` — Prompt text loaded by the production Harness before the provider request. Responsibility: System, campus and map instruction boundaries. Symbols: `default text module`. [contract; runtime_connected=true]
- `prompts/system.md` — Prompt text loaded by the production Harness before the provider request. Responsibility: System, campus and map instruction boundaries. Symbols: `default text module`. [contract; runtime_connected=true]
- `scripts/build-electron.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/evaluate-harness.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/harness-evidence.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/harness-recover.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/harness-recover.ts` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/score-conversation-quality.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/score-harness-evaluation.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/test-environment.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/test-harness.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/test.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/validate-trajectories.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `scripts/verify-harness.mjs` — Selected runner/scorer/recovery script used by the listed verification command. Responsibility: Verification orchestration; not a production runtime module. Symbols: `script entry / exported validator where present`. [test; runtime_connected=false]
- `src/main/actions/reminders.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: ReminderRuntime schedule/lease/runDue/recover and delivery state Symbols: `ReminderRuntime schedule/lease/runDue/recover and delivery state`. [action; runtime_connected=true]
- `src/main/actions/runtime.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: ActionRuntime prepare/approve/execute/reconcile/cancel; attempts/receipts/idempotency Symbols: `ActionRuntime prepare/approve/execute/reconcile/cancel; attempts/receipts/idempotency`. [action; runtime_connected=true]
- `src/main/capabilities/broker.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: CapabilityBroker register/invoke/runRecipes and effect/scope gates Symbols: `CapabilityBroker register/invoke/runRecipes and effect/scope gates`. [runtime; runtime_connected=true]
- `src/main/capabilities/builtin.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: public capability manifests and provider adapters Symbols: `public capability manifests and provider adapters`. [runtime; runtime_connected=true]
- `src/main/capabilities/ports.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Observation/Sync/RulePack/Watch/Entity public extension ports Symbols: `Observation/Sync/RulePack/Watch/Entity public extension ports`. [runtime; runtime_connected=true]
- `src/main/demo.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: controlled local demo provider path Symbols: `controlled local demo provider path`. [runtime; runtime_connected=true]
- `src/main/harness.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Harness.start/run/stop/recoverPending; final prompt assembly; tool loop Symbols: `Harness.start/run/stop/recoverPending; final prompt assembly; tool loop`. [runtime; runtime_connected=true]
- `src/main/main.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: app.whenReady; handle("send"); trusted IPC gate; recovery/reminder timers Symbols: `app.whenReady; handle("send"); trusted IPC gate; recovery/reminder timers`. [runtime; runtime_connected=true]
- `src/main/mapLocation.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: location capability adapter and cancellation Symbols: `location capability adapter and cancellation`. [runtime; runtime_connected=true]
- `src/main/mapService.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Map capability adapter and optional large-data boundary Symbols: `Map capability adapter and optional large-data boundary`. [runtime; runtime_connected=true]
- `src/main/md.d.ts` — Transitive local dependency required to inspect the selected implementation path. Responsibility: Local runtime dependency. Symbols: `module exports`. [runtime; runtime_connected=true]
- `src/main/memory/model.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: bindModelSemantics extractor/reviewer and bounded structured repair Symbols: `bindModelSemantics extractor/reviewer and bounded structured repair`. [memory; runtime_connected=true]
- `src/main/memory/service.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: MemoryService process/propose/verify/commitVerified/saveControl/forget/migrateLegacy Symbols: `MemoryService process/propose/verify/commitVerified/saveControl/forget/migrateLegacy`. [memory; runtime_connected=true]
- `src/main/preload.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Bridge.send; Bridge.onEvent; contextBridge.exposeInMainWorld Symbols: `Bridge.send; Bridge.onEvent; contextBridge.exposeInMainWorld`. [runtime; runtime_connected=true]
- `src/main/provider.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: DeepSeekClient.complete/readSSE/assistantMessage/invalidateBoundary; request serialization/retry/cancel Symbols: `DeepSeekClient.complete/readSSE/assistantMessage/invalidateBoundary; request serialization/retry/cancel`. [provider; runtime_connected=true]
- `src/main/runtime/context.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: ContextCompiler.compile/expand/recordTool/recordProviderRequest/serialize Symbols: `ContextCompiler.compile/expand/recordTool/recordProviderRequest/serialize`. [context; runtime_connected=true]
- `src/main/runtime/controls.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: NativeControls overview/evidence/goal/feedback/retry/reconcile/permission Symbols: `NativeControls overview/evidence/goal/feedback/retry/reconcile/permission`. [runtime; runtime_connected=true]
- `src/main/runtime/coordinator.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: RuntimeCoordinator.begin/compile/generationInput/toolSpecs/executeTool; RunSession Symbols: `RuntimeCoordinator.begin/compile/generationInput/toolSpecs/executeTool; RunSession`. [runtime; runtime_connected=true]
- `src/main/runtime/discourse.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: speech-act and interpretation routing Symbols: `speech-act and interpretation routing`. [runtime; runtime_connected=true]
- `src/main/runtime/policy.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: PolicyKernel.ingress/hostScope/validate/grant/revoke/narrow/signalBarrier Symbols: `PolicyKernel.ingress/hostScope/validate/grant/revoke/narrow/signalBarrier`. [runtime; runtime_connected=true]
- `src/main/runtime/redaction.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: credential/ephemeral redaction and public projection guards Symbols: `credential/ephemeral redaction and public projection guards`. [runtime; runtime_connected=true]
- `src/main/runtime/semantics.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: typed values, condition and temporal semantics Symbols: `typed values, condition and temporal semantics`. [runtime; runtime_connected=true]
- `src/main/runtime/work.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: episode/world/goal/plan/commitment resolution; dependency adoption/invalidation Symbols: `episode/world/goal/plan/commitment resolution; dependency adoption/invalidation`. [runtime; runtime_connected=true]
- `src/main/storage/domains.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: domain snapshots, observations, rule packs and scoped projections Symbols: `domain snapshots, observations, rule packs and scoped projections`. [storage; runtime_connected=true]
- `src/main/storage/repository.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: KernelRepository schema migrations; evidence/assertion/dependency/action/job/outbox persistence; fences Symbols: `KernelRepository schema migrations; evidence/assertion/dependency/action/job/outbox persistence; fences`. [storage; runtime_connected=true]
- `src/main/store.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Store SQLite envelope, message/session projections, RuntimeCoordinator ownership Symbols: `Store SQLite envelope, message/session projections, RuntimeCoordinator ownership`. [runtime; runtime_connected=true]
- `src/main/testBoundary.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: isolated synthetic test-data boundary Symbols: `isolated synthetic test-data boundary`. [runtime; runtime_connected=true]
- `src/main/tools.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: ToolRegistry schemas, bounded child context, result/error normalization Symbols: `ToolRegistry schemas, bounded child context, result/error normalization`. [runtime; runtime_connected=true]
- `src/main/zjuAdapter.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: external campus connector boundary and explicit unavailable state Symbols: `external campus connector boundary and explicit unavailable state`. [runtime; runtime_connected=true]
- `src/renderer/App.tsx` — Direct production entry or transitive implementation of the Harness path. Responsibility: send() and user-facing conversation entry; window.zaichang.send Symbols: `send() and user-facing conversation entry; window.zaichang.send`. [runtime; runtime_connected=true]
- `src/renderer/HarnessViews.tsx` — Direct production entry or transitive implementation of the Harness path. Responsibility: scope/evidence/understanding/work/action review surfaces Symbols: `scope/evidence/understanding/work/action review surfaces`. [runtime; runtime_connected=true]
- `src/renderer/SettingsPanel.tsx` — Direct production entry or transitive implementation of the Harness path. Responsibility: memory, scope and connection controls using the Bridge Symbols: `memory, scope and connection controls using the Bridge`. [runtime; runtime_connected=true]
- `src/renderer/global.d.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/harness.css` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/main.tsx` — Direct production entry or transitive implementation of the Harness path. Responsibility: React root and renderer surface bootstrap Symbols: `React root and renderer surface bootstrap`. [runtime; runtime_connected=true]
- `src/renderer/map/CampusMap.tsx` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/geometry-layer.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/gpu-style.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/map-engine.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/map-state.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/map-theme.ts` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/map/map.css` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/refinements.css` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/style.css` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/tokens.css` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/renderer/ui.tsx` — Renderer import closure needed to follow the real send path; non-core visual details are marked disconnected. Responsibility: UI/import closure only. Symbols: `React component/style/import closure`. [runtime; runtime_connected=false]
- `src/shared/harness.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: ContextContract/ScopeHandle/Evidence/Assertion/Work/Action/Receipt schemas and statuses Symbols: `ContextContract/ScopeHandle/Evidence/Assertion/Work/Action/Receipt schemas and statuses`. [contract; runtime_connected=true]
- `src/shared/limits.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: message/attachment/budget limits Symbols: `message/attachment/budget limits`. [contract; runtime_connected=true]
- `src/shared/map-routing.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: map routing/fix classification contracts Symbols: `map routing/fix classification contracts`. [contract; runtime_connected=true]
- `src/shared/map-v2.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: map capability contracts and cards Symbols: `map capability contracts and cards`. [contract; runtime_connected=true]
- `src/shared/schemas.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: Zod input/output validators and campus/action schemas Symbols: `Zod input/output validators and campus/action schemas`. [contract; runtime_connected=true]
- `src/shared/types.ts` — Direct production entry or transitive implementation of the Harness path. Responsibility: IPC Bridge, Message, State and UI/runtime DTOs Symbols: `IPC Bridge, Message, State and UI/runtime DTOs`. [contract; runtime_connected=true]
- `tests/connection.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for connection. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/core.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for core.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/desktop.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for desktop. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness-ui.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for harness-ui. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/controls.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for controls.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/conversation-quality-corpus.json` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for conversation-quality-corpus. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/crash-process.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for crash-process. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/desktop-entry.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for desktop-entry. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/evaluation.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for evaluation.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/extensions.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for extensions.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/faults.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for faults.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/live-eval.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for live-eval. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/migration.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for migration.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/performance.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for performance.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/ports.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for ports.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/privacy.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for privacy.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/protocol.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for protocol.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/release.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for release.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/scenario-fixture.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for scenario-fixture. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/scenarios.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for scenarios.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/scripted.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for scripted. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/seed-ui.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for seed-ui. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/semantic-corpus.json` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for semantic-corpus. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/sink.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for sink. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/state.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for state.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/support.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for support. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/harness/unit.test.ts` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for unit.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/package.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for package. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tests/trajectory-validation.test.mjs` — Selected synthetic conformance, real-entry, protocol, privacy, extension or quality test; the whole file is retained. Responsibility: Test evidence for trajectory-validation.test. Symbols: `node:test cases or Electron/fixture runner entry`. [test; runtime_connected=false]
- `tsconfig.json` — Minimal build/runtime metadata needed to identify the actual entry and dependency versions. Responsibility: Build and dependency boundary. Symbols: `package/build configuration`. [runtime; runtime_connected=false]
- `vite.config.ts` — Minimal build/runtime metadata needed to identify the actual entry and dependency versions. Responsibility: Build and dependency boundary. Symbols: `package/build configuration`. [runtime; runtime_connected=false]
- `在场-Harness-人本协作设计与Codex实施包/在场-Harness-人本协作重构/02-人本协作架构.md` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [runtime; runtime_connected=false]
- `在场-Harness-人本协作设计与Codex实施包/在场-Harness-人本协作重构/04-行为验收规范.md` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [runtime; runtime_connected=false]
- `在场-Harness-人本协作设计与Codex实施包/在场-Harness-人本协作重构/acceptance/trajectories.json` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]
- `在场-Harness-人本协作设计与Codex实施包/在场-Harness-人本协作重构/交付一致性说明.json` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]
- `在场-Harness-设计与Codex实施包/zaichang-harness-design/acceptance/README.md` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]
- `在场-Harness-设计与Codex实施包/zaichang-harness-design/acceptance/scenarios.json` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]
- `在场-Harness-设计与Codex实施包/zaichang-harness-design/acceptance/traceability.json` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]
- `在场-Harness-设计与Codex实施包/zaichang-harness-design/contracts/core-contracts.ts` — Synthetic acceptance or trajectory fixture read by the selected validator. Responsibility: Declared behavior/traceability input; not a production implementation. Symbols: `JSON/Markdown fixture`. [contract; runtime_connected=false]

## Intentionally excluded

- `node_modules/`: Installed dependency tree is external; package.json is retained for dependency identity.
- `dist/, dist-electron/, release/`: Generated bundles and portable binaries are not source and can embed dependencies.
- `assets/map-v2/, public/map-v2/`: Large OSM/GeoJSON/network data is not needed to inspect the adapter/state machine; adapter and contracts remain.
- `.git/, .test-data/`: No repository metadata, SQLite profiles, test databases, cookies, logs or user history.
- `artifacts/harness/**, artifacts/review/**`: Evaluation outputs, screenshots, videos and logs are evidence artifacts, not core source.
- `deepseek-key.bin, *.dpapi, secrets/, credentials/`: No API key, token, cookie, DPAPI file, account or private configuration is copied.
- `external zju-student-info connector source`: The product boundary invokes a user-selected connector; source and credentials are external.
- `renderer map assets and icon/font binaries`: Large data and binary presentation assets are non-core to the message-to-Harness audit.

The excluded map directory is a data payload, not a missing Harness state transition: `src/main/mapService.ts`, `src/shared/map-v2.ts`, `src/shared/map-routing.ts` and the map UI import closure remain. CSS/icon/font files that are not needed to follow the message-to-Harness path are marked as non-connected closure files rather than silently presented as core.

## Implementation status matrix

| Responsibility | Status | Evidence/qualification |
| --- | --- | --- |
| ContextContract | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| PolicyKernel | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Evidence | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Assertion | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| MemoryExtraction | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Verification | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ControlledCommit | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Correction | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Forget | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ContextNeeds | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Retrieval | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| OriginalEvidenceFallback | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Episode | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| World | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Goal | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Commitment | IMPLEMENTED_BUT_NOT_RUNTIME_CONNECTED | Schema, repository and confirmation path exist in WorkService; no ordinary production model tool exposes commitment confirmation. |
| Plan | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| DependencyInvalidation | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| PlanningValidation | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ActionApproval | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ActionExecution | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| OutcomeUnknown | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| Reconciliation | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| WatchReminder | IMPLEMENTED_BUT_NOT_RUNTIME_CONNECTED | Persistent ReminderRuntime and native notification port exist; watch creation is exercised by controls/fixtures rather than general model exposure. |
| CapabilityBroker | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| TaskRecipe | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| SubAgent | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ReadonlyDelegation | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| CampusAdapter | EXTERNAL_DEPENDENCY_BLOCKED | ZjuAdapter is connected behind a user-selected external connector path; no connector source/account is bundled. |
| MapAdapter | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| WeatherAdapter | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| ExternalWrite | SIMULATED_ONLY | Only controlled local registration and synthetic/HTTP sink fixtures are present; no real external write service is connected. |
| Multimodal | INTERFACE_ONLY | Observation/media ports retain anchors and corrected transcripts; no image/audio provider is connected in this product build. |
| CrossDeviceSync | INTERFACE_ONLY | SyncPort and versioned operation tables are implemented and tested as an extension contract, not connected to a transport. |
| AudienceProjection | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| DeepSeekProtocolState | IMPLEMENTED_AND_RUNTIME_CONNECTED | See the copied source and selected tests in the file index. |
| BorrowedDeviceProvider | SIMULATED_ONLY | Extension fixture is registered through the public broker and tested for malicious/overbroad effects; it is not a live service. |

These labels describe the code and actual production exposure at package time; they are not design aspirations. A schema or conformance fixture does not turn an interface into a live provider, and a synthetic sink does not turn an external write into a real integration.

## Known architectural compromises

- The host remains a single local identity/workspace. `ScopeHandle` is enforced in the runtime, but this is not a multi-account OS sandbox.
- SQLite bodies are not encrypted at rest; API keys are protected with Electron `safeStorage` outside this package.
- Retrieval is scoped SQL/FTS/Chinese short-token/original-evidence fallback; no embedding provider is installed.
- Commitment confirmation and watch creation have durable services and tests, but are not ordinary model tools in the main production tool list.
- Campus access depends on a user-selected external connector. Weather/map capability boundaries exist; live external data is not bundled.
- External sends/writes, multimodal providers and cross-device transport remain simulated or interface-only as shown in the matrix.
- Deletion cannot retract a payload already sent to an external provider; local fences prevent re-entry by local worker/index/context paths.
- Renderer map code is retained only where needed for import closure; large map data and binary presentation assets are excluded.

## Verification commands and recorded evidence

- `npm test` — package or original repository; recorded result: passed (21/21).
- `node scripts/test-harness.mjs --suite unit` — package or original repository; recorded result: passed (20/20 in full run).
- `node scripts/test-harness.mjs --suite privacy` — package or original repository; recorded result: passed (10/10 in full run).
- `node scripts/test-harness.mjs --suite faults` — package or original repository; recorded result: passed (7/7 in full run).
- `node scripts/test-harness.mjs --suite extensions` — package or original repository; recorded result: passed (2/2 in full run).
- `node tests/trajectory-validation.test.mjs` — package or original repository; recorded result: passed (32/32 mechanism cases).
- `npm run verify:harness` — original repository; recorded result: passed; 175 mechanism tests, 94/94 scenarios and docs gate.
- `npm run test:connection` — original repository; recorded result: passed; real Electron/IPC with synthetic DeepSeek transport.
- `npm run test:desktop` — original repository; recorded result: passed with synthetic data.
- `npm run test:harness:desktop` — original repository; recorded result: passed with synthetic data.
- `npm run test:map:core` — original repository; recorded result: passed (22/22).
- `node tests/package.mjs` — original repository after npm run package; recorded result: direct EXE launch blocked by Windows application-control policy; limited fallback recorded.

The package deliberately does not claim that the following checks ran:

- **independent blind DeepSeek semantic adjudication** — No separate adjudicator, reproducible seed or semantic scoring protocol was authorized; live samples remain exploratory.
- **human/student usability study** — No participant study was run; primary-agent reading is not independent human evidence.
- **live campus connector** — No explicit connector directory/account or test account was provided.
- **live weather/position permissions** — No live smoke or OS location permission was authorized.
- **real external delivery/write** — Only local reversible actions and controlled HTTP/synthetic sinks are available.
- **embedding/vector retrieval** — No embedding provider is installed; retrieval uses scoped lexical/FTS/original-evidence paths.
- **direct portable EXE launch** — The current Windows application-control policy blocked the unsigned executable; limited ASAR/security fallback passed.
- **trajectory L/U semantic and experience layers** — The 32 trajectories were validated as mechanism specifications; L and U are deliberately not_run.

Recorded real-model runs used synthetic corpus inputs and a runtime-loaded key that is not copied here; they are exploratory and have no independent semantic adjudication.

## Dependency-closure check

The generator walked static relative imports from production, test and fixture roots, added declared fs/child-process dependencies, then re-scanned every copied file. Closure status is **PASSED**: 110 indexed files, 257 static local edges, 7 declared dynamic edges, 0 hard unresolved local imports. Any allowed unresolved edge is explicitly a non-core map/data/UI path in `PACKAGE-MANIFEST.json`; no core state-transition import is silently omitted.

## Package boundary

No `node_modules`, generated bundle/release, large map data, screenshot/video, `.git`, `.test-data`, SQLite user database, chat history, grades/health/location records, API key, password, token, cookie or DPAPI credential is included. Synthetic fixtures are retained only where a selected test reads them.


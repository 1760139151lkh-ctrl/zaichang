import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { Store } from '../src/main/store';
import { DeepSeekClient, ProviderError, type Completion, type WireMessage } from '../src/main/provider';
import { Harness } from '../src/main/harness';
import { ZjuAdapter } from '../src/main/zjuAdapter';
import { ToolRegistry, type ToolContext } from '../src/main/tools';
import { campusSchema } from '../src/shared/schemas';
import type { Message, RunEvent } from '../src/shared/types';

const complete = (content: string): Completion => ({ content, tool_calls: [] });
const tool = (name: string, args: unknown): Completion => ({
  content: '',
  tool_calls: [{ id: randomUUID(), type: 'function', function: { name, arguments: JSON.stringify(args) } }],
});
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));
function tmpdir(){if(process.env.ZAICHANG_TEST!=='1'||!process.env.ZAICHANG_DATA_DIR)throw new Error('Run through scripts/test.mjs with an isolated test directory.');return process.env.ZAICHANG_DATA_DIR;}
function message(sessionId: string, content: string, role: 'user' | 'assistant' = 'user'): Message {
  return {
    id: randomUUID(),
    sessionId,
    content,
    role,
    createdAt: new Date().toISOString(),
    status: 'done',
    steps: [],
    obligations: [],
    actions: [],
  };
}
function ctx(store: Store, extra: Partial<ToolContext> = {}): ToolContext {
  return {
    store,
    signal: new AbortController().signal,
    userText: '我喜欢整段思考，不喜欢来回跑。',
    currentUserId: '',
    child: false,
    step: () => {},
    plan: () => {},
    action: () => {},
    changed: () => {},
    delegate: async () => [],
    ...extra,
  };
}
function stream(parts: unknown[], split = 7, done = true): Response {
  const bytes = new TextEncoder().encode(
    parts.map((p) => `data: ${JSON.stringify(p)}\r\n\r\n`).join('') + (done ? 'data: [DONE]\n\n' : ''),
  );
  return new Response(
    new ReadableStream({
      start(controller) {
        for (let i = 0; i < bytes.length; i += split) controller.enqueue(bytes.slice(i, i + split));
        controller.close();
      },
    }),
    { status: 200 },
  );
}

test('本地重启可恢复记录，中文短词与全文索引均能检索，删除无残留', () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'zaichang-test-'));
  const file = path.join(dir, 'store.sqlite');
  let store = new Store(file);
  const id = store.session(undefined, '物理与羽毛球');
  store.putMessage(message(id, '我喜欢整段思考，周三打羽毛球，物理考试在周五。'));
  store.close();
  store = new Store(file);
  assert.equal(store.search('物理').length, 1);
  assert.equal(store.search('羽毛球').length, 1);
  assert.equal(store.search('物理 周五').length, 1);
  assert.equal(store.search('%').length, 0);
  store.deleteSession(id);
  assert.equal(store.search('羽毛球').length, 0);
  assert.equal(store.messages(id).length, 0);
  store.close();
});
test('崩溃恢复把未完成步骤标成中断', () => {
  const file = path.join(mkdtempSync(path.join(tmpdir(), 'zaichang-crash-')), 'db');
  let store = new Store(file);
  const id = store.session();
  store.putMessage({
    ...message(id, '', 'assistant'),
    status: 'running',
    steps: [{ id: 's', title: '正在查询', status: 'running' }],
    obligations: [
      { id: 'o', title: '核对课表', status: 'running' },
      { id: 'o2', title: '选择时间', status: 'pending' },
    ],
  });
  store.close();
  store = new Store(file);
  assert.equal(store.messages(id)[0].status, 'cancelled');
  assert.equal(store.messages(id)[0].steps[0].status, 'cancelled');
  assert.ok(store.messages(id)[0].obligations.every((o) => o.status === 'blocked'));
  store.close();
});
test('SSE 可处理跨字节中文与工具参数碎片，内部推理不外泄', async () => {
  let body: any;
  const output: string[] = [];
  const client = new DeepSeekClient('test-key', 'deepseek-v4-flash', (async (_url, init) => {
    body = JSON.parse(String(init?.body));
    return stream(
      [
        { choices: [{ delta: { reasoning_content: '不要展示的内部内容' } }] },
        {
          choices: [
            {
              delta: {
                content: '先看看你的课表。',
                tool_calls: [
                  { index: 0, id: 'call-1', function: { name: 'query_campus', arguments: '{"kind":' } },
                ],
              },
            },
          ],
        },
        {
          choices: [
            {
              delta: { tool_calls: [{ index: 0, function: { arguments: '"schedule"}' } }] },
              finish_reason: 'tool_calls',
            },
          ],
        },
      ],
      5,
    );
  }) as typeof fetch);
  const result = await client.complete(
    [{ role: 'user', content: '安排今天' }],
    [],
    new AbortController().signal,
    (t) => output.push(t),
    { toolChoice: { type: 'function', function: { name: 'campus_full_context' } } },
  );
  assert.equal(result.content, '先看看你的课表。');
  assert.equal(result.tool_calls[0].function.arguments, '{"kind":"schedule"}');
  assert.equal(output.join(''), result.content);
  assert.ok(!JSON.stringify(result).includes('内部'));
  assert.equal(body.thinking.type, 'disabled');
  assert.equal(body.tool_choice.function.name, 'campus_full_context');
});
test('401 错误不回显响应体里的秘密', async () => {
  const client = new DeepSeekClient(
    'secret-test',
    'deepseek-v4-flash',
    (async () => new Response('secret-test', { status: 401 })) as typeof fetch,
  );
  await assert.rejects(
    () => client.complete([], [], new AbortController().signal),
    (e) => e instanceof ProviderError && !e.message.includes('secret-test') && e.message.includes('无效'),
  );
});
test('半截响应不会被伪装成成功，也不重复请求已流出的内容', async () => {
  let calls = 0;
  const client = new DeepSeekClient('test-key', 'deepseek-v4-flash', (async () => {
    calls++;
    return stream([{ choices: [{ delta: { content: '半截' } }] }], 7, false);
  }) as typeof fetch);
  await assert.rejects(() => client.complete([], [], new AbortController().signal), /断开/);
  assert.equal(calls, 1);
});
test('取消请求会传递到 provider 网络请求', async () => {
  const c = new AbortController();
  let linked = false;
  const client = new DeepSeekClient(
    'test-key',
    'deepseek-v4-flash',
    ((_url, init) =>
      new Promise((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () => {
          linked = true;
          reject(init.signal?.reason);
        });
      })) as typeof fetch,
  );
  const request = client.complete([], [], c.signal);
  c.abort();
  await assert.rejects(request);
  assert.equal(linked, true);
});
test('分身权限是主代理的只读子集，关闭的天气和记忆不能调用', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ weatherEnabled: false, memoryEnabled: false });
  const registry = new ToolRegistry(ctx(store, { child: true }));
  const names = registry.specs().map((s) => s.function.name);
  assert.deepEqual(names.sort(), ['look_up', 'read_evidence']);
  assert.match(await registry.execute('look_up', '{"source":"campus","mode":"refresh","domain":"schedule"}'), /不可用|分身/);
  assert.match(await registry.execute('delegate', '{"tasks":[]}'), /不可用/);
  assert.match(await registry.execute('remember_preference', '{}'), /不可用/);
  store.close();
});
test('校园个人工具按意图收敛，兼容别名不进入模型 schema', async () => {
  const store = new Store(':memory:');
  const calls: string[] = [];
  const campus = {
    capabilities: async () => ({ status: 'ok', catalogued: 40 }),
    fullContext: async (args: any) => { calls.push('full:' + Boolean(args.refresh)); return { status: 'ok', batches: [] }; },
    read: async (args: any) => { calls.push('read:' + args.domain + ':' + Boolean(args.refresh)); return { status: 'ok', domain: args.domain, records: [], fetched_at: new Date().toISOString(), coverage: { complete: true } }; },
    refresh: async (args: any) => { calls.push('refresh:' + args.scope); return { status: 'ok', scope: args.scope, domain: args.domain }; },
  };
  const registry = new ToolRegistry(ctx(store, { campus: campus as any, userText: '查课程和考试，需要时更新最新资料。' }));
  const names = registry.specs().map(s => s.function.name);
  assert.deepEqual(names.sort(), ['delegate', 'inspect_action', 'look_up', 'prepare_action', 'propose_memory_change', 'read_evidence', 'remember_preference', 'set_plan', 'update_work_state']);
  assert.ok(names.includes('look_up')); assert.ok(names.includes('prepare_action')); assert.ok(!names.includes('campus_full_context')); assert.ok(!names.includes('campus_read')); assert.ok(!names.includes('campus_refresh')); assert.ok(!names.includes('query_campus'));
  assert.match(await registry.execute('look_up', '{"source":"campus","mode":"detail","domain":"schedule","window":"next:7d"}'), /schedule/);
  assert.match(await registry.execute('look_up', '{"source":"campus","mode":"overview"}'), /batches/);
  assert.match(await registry.execute('look_up', '{"source":"campus","mode":"refresh","domain":"schedule"}'), /schedule/);
  assert.deepEqual(calls, ['read:schedule:false', 'read:schedule:false', 'read:exams:false', 'read:schedule:true']); store.close();
});
test('校园读取的 partial/auth 状态进入 blocked 步骤，不伪装成完成', async () => {
  const store = new Store(':memory:'); const statuses: string[] = [];
  const campus = { read: async () => ({ status: 'partial', records: [], coverage: { complete: false } }) };
  const registry = new ToolRegistry(ctx(store, { campus: campus as any, step: s => statuses.push(s.status), campusMemo: { fullContextUsed: false, domains: new Set(), results: new Map() } }));
  const output = JSON.parse(await registry.execute('look_up', '{"source":"campus","domain":"schedule"}'));
  assert.equal(output.status, 'unknown'); assert.equal(statuses.at(-1), 'blocked'); store.close();
});
test('校园读取按任务取单域，合格缓存不重复扫描，也不主动读取成绩', async () => {
  const store = new Store(':memory:'); store.saveSettings({ mode: 'deepseek' });
  const reads: string[] = []; const fakeCampus = { describe: () => ({ configured: true, available: true, label: 'test' }), read: async (args: any) => { reads.push(args.domain); return { status: 'ok', records: [], fetched_at: new Date().toISOString(), coverage: { complete: true } }; } };
  let calls = 0;
  const fake = { complete: async (messages: WireMessage[]) => { if(messages[0].content?.includes('[harness:extract')) return complete(JSON.stringify({status:'no_personal_fact',changes:[]})); calls++; return calls <= 2 ? tool('look_up', { source: 'campus', domain: 'schedule' }) : complete('已读取允许的课程范围，其他领域没有查询。'); } } as unknown as DeepSeekClient;
  const harness = new Harness(store, () => 'test-key', () => {}, () => fake, fakeCampus as any);
  const first = harness.start(undefined, '帮我看看我明天的课程'); await harness.idle();
  assert.deepEqual(reads, ['schedule']); assert.equal(store.messages(first.sessionId).at(-1)?.status, 'done'); store.close();
});
test('ZJU adapter 只通过受限子进程传参，不依赖应用内 Python import', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'zaichang-zju-')); fs.mkdirSync(path.join(root, 'scripts')); fs.mkdirSync(path.join(root, 'references'));
  fs.writeFileSync(path.join(root, 'references', 'endpoints.json'), '{"endpoints":[]}');
  fs.writeFileSync(path.join(root, 'SKILL.md'), '# test connector');
  fs.writeFileSync(path.join(root, 'LICENSE'), 'GPL-3.0 test fixture');
  fs.writeFileSync(path.join(root, 'scripts', 'zju.py'), "import json,sys; print(json.dumps({'status':'ok','argv':sys.argv[1:],'records':[{'summary':'合成课程'}]}))");
  const store = new Store(':memory:'); const adapter = new ZjuAdapter(store); adapter.configure(root);
  const result = await adapter.read({ domain: 'schedule', window: 'next:7d', limit: 1 }, new AbortController().signal);
  assert.equal(result.data.status, 'ok'); assert.deepEqual(result.data.records, [{ summary: '合成课程' }]);
  store.close();
});
test('记忆需本轮原话，有长度预算，拒绝凭空引用与敏感信息', async () => {
  const store = new Store(':memory:');
  const registry = new ToolRegistry(ctx(store));
  assert.match(
    await registry.execute(
      'remember_preference',
      JSON.stringify({ text: '喜欢整段思考', source_quote: '我喜欢整段思考' }),
    ),
    /saved/,
  );
  assert.match(
    await new ToolRegistry(ctx(store)).execute(
      'remember_preference',
      JSON.stringify({ text: '喜欢晨跑', source_quote: '我喜欢晨跑' }),
    ),
    /原文不支持/,
  );
  assert.equal(store.memories().length, 1);
  assert.match(
    await registry.execute(
      'remember_preference',
      JSON.stringify({ text: '喜欢整段思考', source_quote: '我喜欢整段思考' }),
    ),
    /saved/,
  );
  const sensitive = new ToolRegistry(ctx(store, { userText: '密码是 test-only' }));
  assert.match(
    await sensitive.execute(
      'remember_preference',
      JSON.stringify({ text: '密码是 test-only', source_quote: '密码是 test-only' }),
    ),
    /不可用/,
  );
  for (let i = 0; i < 20; i++) store.saveMemory(`${i}${'长'.repeat(130)}`);
  assert.equal(store.memories().length, 21);
  assert.throws(() => store.saveMemory('余'.repeat(4001)));
  store.close();
});
test('校园日期必须含时区且有效，跨午夜查询保留停课状态与来源', async () => {
  const store = new Store(':memory:');
  assert.equal(campusSchema.safeParse({ source: 'test', updatedAt: '2026-09-09' }).success, false);
  const data = campusSchema.parse({
    source: '测试导出',
    updatedAt: '2026-09-09T10:00:00+08:00',
    schedule: [
      {
        id: '1',
        title: '跨日事件',
        startsAt: '2026-09-09T23:30:00+08:00',
        endsAt: '2026-09-10T00:30:00+08:00',
        location: '示例',
        status: 'cancelled',
        source: '停课通知',
      },
    ],
  });
  store.putMeta('campus', data);
  const result = JSON.parse(
    await new ToolRegistry(ctx(store)).execute(
      'query_campus',
      JSON.stringify({
        kind: 'schedule',
        from: '2026-09-10T00:00:00+08:00',
        to: '2026-09-11T00:00:00+08:00',
      }),
    ),
  );
  assert.equal(result.data.records.length, 1);
  assert.equal(result.data.records[0].status, 'cancelled');
  assert.equal(result.data.live, false);
  assert.equal(result.data.source, '测试导出');
  store.close();
});
test('未连接校园查询准确返回 unavailable，不能伪装成已查到', async () => {
  const store = new Store(':memory:');
  const states: string[] = [];
  const registry = new ToolRegistry(ctx(store, { step: (s) => states.push(s.status) }));
  assert.equal(JSON.parse(await registry.execute('query_campus', '{"kind":"exams"}')).status, 'unsupported');
  assert.equal(states.at(-1), 'blocked');
  store.close();
});

test('首答不等待长期记忆后台提取，显式 idle 仍可等待队列排空', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  let releaseExtraction!: () => void,
    resolveReply!: () => void,
    extractionSettled = false;
  const extractionGate = new Promise<void>((resolve) => {
      releaseExtraction = resolve;
    }),
    replyDone = new Promise<void>((resolve) => {
      resolveReply = resolve;
    }),
    order: string[] = [];
  const fake = {
    complete: async (messages: WireMessage[]) => {
      if (messages[0].content?.includes('[harness:extract')) {
        order.push('extract');
        await extractionGate;
        extractionSettled = true;
        return complete(JSON.stringify({ status: 'no_personal_fact', changes: [] }));
      }
      order.push('foreground');
      return complete('前台回复已完成。');
    },
  } as unknown as DeepSeekClient;
  const harness = new Harness(
    store,
    () => 'test-key',
    (event) => {
      if (event.type === 'message' && event.message.role === 'assistant' && event.message.status === 'done')
        resolveReply();
    },
    () => fake,
  );
  harness.start(undefined, '请先回答，后台再整理这句话。');
  assert.equal(
    await Promise.race([replyDone.then(() => 'reply'), delay(1000).then(() => 'timeout')]),
    'reply',
  );
  assert.equal(order[0], 'foreground');
  assert.equal(extractionSettled, false);
  releaseExtraction();
  await harness.idle();
  assert.equal(extractionSettled, true);
  store.close();
});

test('隐私 epoch 变化会取消后台提取并保留 pending 供重启恢复', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  let resolveReply!: () => void,
    resolveStarted!: () => void;
  const replyDone = new Promise<void>((resolve) => {
      resolveReply = resolve;
    }),
    extractionStarted = new Promise<void>((resolve) => {
      resolveStarted = resolve;
    });
  const fake = {
    complete: async (messages: WireMessage[], _tools: unknown, signal: AbortSignal) => {
      if (messages[0].content?.includes('[harness:extract')) {
        resolveStarted();
        signal.throwIfAborted();
        await new Promise<void>((_resolve, reject) =>
          signal.addEventListener('abort', () => reject(signal.reason), { once: true }),
        );
      }
      return complete('前台回复已完成。');
    },
  } as unknown as DeepSeekClient;
  const harness = new Harness(
    store,
    () => 'test-key',
    (event) => {
      if (event.type === 'message' && event.message.role === 'assistant' && event.message.status === 'done')
        resolveReply();
    },
    () => fake,
  );
  const { sessionId } = harness.start(undefined, '我喜欢安静地读书。');
  await replyDone;
  assert.equal(
    await Promise.race([extractionStarted.then(() => 'started'), delay(1000).then(() => 'timeout')]),
    'started',
  );
  store.runtime.policy.revoke('memory:write');
  await harness.backgroundIdle();
  const userId = store.messages(sessionId).find((message) => message.role === 'user')!.id,
    statuses = store.db
      .prepare('SELECT status FROM h_spans WHERE event_id=? ORDER BY start_cp')
      .all(userId)
      .map((row) => String(row.status));
  assert.deepEqual(statuses, ['pending']);
  assert.equal(store.runtime.memory.views().length, 0);
  await harness.stop();
  store.close();
});

test('只读分身按 child scope 重编 ContextPack，不继承父 pack 正文', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  const parentCanary = 'PARENT_PACK_CANARY_619',
    childPayloads: string[] = [],
    originalCompile = store.runtime.compile.bind(store.runtime);
  (store.runtime as any).compile = async (...args: Parameters<typeof originalCompile>) => {
    const pack = await originalCompile(...args);
    pack.data.parentOnly = { secret: parentCanary };
    return pack;
  };
  let foregroundCalls = 0;
  const fake = {
    complete: async (messages: WireMessage[]) => {
      if (messages[0].content?.includes('[harness:extract'))
        return complete(JSON.stringify({ status: 'no_personal_fact', changes: [] }));
      if (messages[0].content?.includes('你是一个只读分身')) {
        childPayloads.push(messages.at(-1)?.content || '');
        return complete('子任务只使用自己的范围。');
      }
      foregroundCalls++;
      return foregroundCalls === 1
        ? tool('delegate', { tasks: [{ title: '范围核对', instruction: '只核对当前请求。' }] })
        : complete('已完成范围核对。');
    },
  } as unknown as DeepSeekClient;
  const harness = new Harness(store, () => 'test-key', () => {}, () => fake);
  harness.start(undefined, '请分头核对当前请求。');
  await harness.idle();
  assert.equal(childPayloads.length, 1);
  assert.equal(childPayloads[0].includes(parentCanary), false);
  assert.match(childPayloads[0], /分配方向：只核对当前请求/);
  store.close();
});

test('前台范围摘要只显示可纠正的参与方式与公开草稿边界，不暴露内部推理', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  const fake = {
    complete: async () => complete('已按本轮边界处理。'),
  } as unknown as DeepSeekClient;
  const harness = new Harness(store, () => 'test-key', () => {}, () => fake);
  const mixed = harness.start(undefined, '我只是想吐槽，顺手把明天九点小组会记一下。');
  await harness.idle();
  const mixedReply = store.messages(mixed.sessionId).at(-1)!;
  assert.equal(mixedReply.scopeSummary?.interpretation?.posture, 'listen_and_local');
  assert.equal(mixedReply.scopeSummary?.interpretation?.explicitLocalWrite, true);
  const draft = harness.start(
    undefined,
    '给老师写一段，沟通目的：确认时间；公开内容：周三下午可以；语气：礼貌自然；先别发送。',
  );
  await harness.idle();
  const draftReply = store.messages(draft.sessionId).at(-1)!;
  assert.equal(draftReply.scopeSummary?.release?.recipient, '老师');
  assert.equal(draftReply.scopeSummary?.release?.mode, 'draft');
  assert.deepEqual(draftReply.scopeSummary?.release?.allowedFacts, ['周三下午可以']);
  assert.equal(JSON.stringify(draftReply.scopeSummary).includes('内部推理'), false);
  store.close();
});


test('完整 harness：拆解、并行分身、汇总、只准备行动、不擅自保存', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  let mainCalls = 0,
    active = 0,
    maxActive = 0;
  const events: RunEvent[] = [];
  const fake = {
    complete: async (messages: WireMessage[]) => {
      if (messages[0].content?.includes('[harness:extract'))
        return complete(JSON.stringify({ status: 'no_personal_fact', changes: [] }));
      if (messages[0].content?.includes('[harness:verify'))
        return complete(
          JSON.stringify({
            supported: true,
            preservesSubject: true,
            preservesWorld: true,
            preservesTime: true,
            preservesConditions: true,
            reason: 'test',
          }),
        );
      if (messages[0].content?.includes('你是一个只读分身')) {
        active++;
        maxActive = Math.max(maxActive, active);
        await delay(25);
        active--;
        return complete('缺少实时资料，不能断言安排可行。');
      }
      mainCalls++;
      if (mainCalls === 1)
        return tool('set_plan', { items: [{ id: '1', title: '核对课程与体育', status: 'running' }] });
      if (mainCalls === 2)
        return tool('delegate', {
          tasks: [
            { title: '课程方向', instruction: '查询下周课程' },
            { title: '体育方向', instruction: '查询体育要求' },
          ],
        });
      if (mainCalls === 3) return tool('prepare_action', { title: '核对运动时间', detail: '等待真实数据。' });
      if (mainCalls === 4)
        return tool('set_plan', { items: [{ id: '1', title: '核对课程与体育', status: 'blocked' }] });
      return complete('还缺少校园资料。建议先导入。');
    },
  } as unknown as DeepSeekClient;
  const harness = new Harness(
    store,
    () => 'test-key',
    (e) => events.push(e),
    () => fake,
  );
  const result = harness.start(undefined, '帮我综合下周课程和体育打卡');
  await harness.idle();
  const m = store.messages(result.sessionId).at(-1)!;
  assert.equal(m.status, 'done');
  assert.equal(maxActive, 2);
  assert.equal(m.actions.length, 1);
  assert.equal(store.agenda().length, 0);
  assert.equal(m.obligations[0].status, 'blocked');
  assert.ok(events.some((e) => e.type === 'message' && e.message.steps.some((s) => s.scope === '分头了解')));
  store.close();
});
test('停止后的会话可继续，旧的运行状态不会污染新回复', async () => {
  const store = new Store(':memory:');
  const harness = new Harness(
    store,
    () => '',
    () => {},
  );
  const { sessionId } = harness.start(undefined, '安排今天');
  await delay(20);
  await harness.stop();
  assert.equal(harness.running, false);
  const stopped = store.messages(sessionId).at(-1)!;
  assert.equal(stopped.status, 'cancelled');
  assert.ok(stopped.steps.every((s) => s.status !== 'running'));
  harness.start(sessionId, '最近有点累');
  await harness.idle();
  assert.equal(store.messages(sessionId).at(-1)!.status, 'done');
  store.close();
});
test('长对话不依赖递归摘要，未提取的原文限制仍进入当前上下文', async () => {
  const store = new Store(':memory:');
  store.saveSettings({ mode: 'deepseek' });
  const id = store.session();
  for (let i = 0; i < 26; i++)
    store.putMessage(message(id, i === 0 ? '未完成要求：保留晚间休息。' : `测试消息 ${i}`));
  let main: WireMessage[] = [];
  const fake = {
    complete: async (messages: WireMessage[]) => {
      if (messages[0].content?.includes('[harness:extract'))
        return complete(JSON.stringify({ status: 'no_personal_fact', changes: [] }));
      if (messages[0].content?.includes('[harness:verify'))
        return complete(
          JSON.stringify({
            supported: true,
            preservesSubject: true,
            preservesWorld: true,
            preservesTime: true,
            preservesConditions: true,
            reason: 'test',
          }),
        );
      if (messages[0].content?.includes('压缩对话')) return complete('未完成要求：保留晚间休息。');
      main = structuredClone(messages);
      return complete('会保留晚间休息。');
    },
  } as unknown as DeepSeekClient;
  const harness = new Harness(
    store,
    () => 'test-key',
    () => {},
    () => fake,
  );
  harness.start(id, '继续安排');
  await harness.idle();
  assert.equal(store.summary(id).count, 0);
  assert.ok(main[1].content?.includes('保留晚间休息'));
  assert.equal(store.search('未完成要求').length, 1);
  assert.equal(main.length, 3);
  store.close();
});

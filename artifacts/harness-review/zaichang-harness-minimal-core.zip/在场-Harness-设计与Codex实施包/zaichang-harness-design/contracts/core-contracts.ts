/**
 * 在场 Harness：类型设计样本。
 * 本文件不实现 Policy、数据库或真实插件；类型检查通过不证明授权安全。
 * 生产实现须用运行时 schema、可信宿主认证、ScopeHandle 注册/验证与执行点复核。
 * 规范语义以 02-HARNESS-ARCHITECTURE.md 为准。
 */
export type Id = string;
export type ISOInstant = string; // 运行时校验 RFC3339；保存时区解释上下文，不能裸比较任意字符串。
export type Revision = number;
export type PrivacyEpoch = number;
export type JSONValue = null | boolean | number | string | JSONValue[] | { [key: string]: JSONValue };
export type Result<T> =
  | { ok: true; value: T }
  | { ok: false; code: string; retry: 'safe_read_only' | 'after_reconcile' | 'never'; message: string };

export interface AuthContext {
  readonly principalId: Id;
  readonly workspaceId: Id;
  readonly deviceId: Id;
  readonly policyRevision: Revision;
  readonly privacyEpoch: PrivacyEpoch;
}
// 品牌仅防普通TS误用；真正防伪由main进程的运行时工厂和验证器负责。
declare const scopeBrand: unique symbol;
export interface ScopeHandle { readonly id: Id; readonly [scopeBrand]: true; }
export type SubjectRef =
  | { kind: 'self'; entityId: Id }
  | { kind: 'other'; entityId: Id; sharingEvidence?: Id }
  | { kind: 'group'; entityId: Id }
  | { kind: 'fictional'; entityId: Id };
export type WorldRef = { kind: 'real'; id: Id } | { kind: 'scenario'; id: Id; baseRevision: Revision };
export interface ClockContext {
  now: ISOInstant;
  interpretationTimeZone: string; // IANA，例如Asia/Shanghai；由本轮上下文解析，不固定宿主时区。
  sourceTimeZone?: string;
  dateAmbiguity: 'resolved' | 'needs_confirmation';
}
export interface ResourceBudget {
  modelCalls: number; toolCalls: number; maxInputTokens: number; maxOutputTokens: number;
  maxReadBytes: number; maxRows: number; maxDependencyDepth: number;
  parallelReads: number; subAgents: number; deadline: ISOInstant;
}
export interface ContextContract {
  id: Id; revision: Revision; scope: ScopeHandle; subject: SubjectRef; world: WorldRef;
  episodeId?: Id; allowedSourceHandles: readonly Id[]; excludedSourceHandles: readonly Id[];
  purpose: string; audience: 'self' | 'named_recipient' | 'group' | 'public';
  processingDestination: Id;
  memoryMode: 'relevant' | 'current_sources_only' | 'session_only' | 'none';
  retention: 'session_only' | 'history_no_inference' | 'purpose_scoped';
  actionMode: 'respond' | 'read' | 'propose' | 'execute_approved';
  interactionMode: 'listen' | 'clarify' | 'analyze' | 'suggest_next' | 'tutor_hint' | 'direct_answer';
  disclosureProjectionId?: Id;
  policyRevision: Revision; privacyEpoch: PrivacyEpoch; clock: ClockContext;
  budget: ResourceBudget;
}
export type EvidenceLocator =
  | { kind: 'text'; eventId: Id; contentVersion: Revision; startCodePoint: number; endCodePoint: number }
  | { kind: 'file'; artifactId: Id; version: Revision; page?: number; paragraphId?: Id }
  | { kind: 'image'; artifactId: Id; version: Revision; region: readonly [number, number, number, number]; objectId?: Id }
  | { kind: 'audio'; artifactId: Id; version: Revision; startMs: number; endMs: number; transcriptVersion?: Revision }
  | { kind: 'structured'; snapshotId: Id; jsonPointer: string; sourceRecordId: Id };
export interface PolicyLabel {
  id: Id; allowedPurposeIds: readonly Id[]; allowedAudienceIds: readonly Id[];
  retention: 'session_only' | 'history_no_inference' | 'purpose_scoped';
  sensitivity: 'public' | 'personal' | 'restricted';
  validUntil?: ISOInstant;
}
export interface EvidenceRef {
  id: Id; locator: EvidenceLocator; rootSourceIds: readonly Id[];
  subject: SubjectRef; world: WorldRef; policyLabelId: Id;
  authority: 'user_statement' | 'source_record' | 'quotation' | 'model_derivative' | 'legacy_unverified';
}
export interface SourceEvent {
  id: Id; ownerId: Id; workspaceId: Id; sequence: number; contentVersion: Revision;
  kind: 'user_message' | 'tool_result' | 'file_import' | 'user_control' | 'external_observation';
  speaker: 'user' | 'assistant' | 'external'; receivedAt: ISOInstant;
  sourceId: Id; parentEventId?: Id; blobRef?: Id; policyLabelId: Id;
  provenanceRoots: readonly Id[];
}
export type TypedValue =
  | { type: 'boolean'; value: boolean }
  | { type: 'text'; value: string }
  | { type: 'entity'; value: Id }
  | { type: 'quantity'; value: number; unit: string; dimension: string }
  | { type: 'instant'; value: ISOInstant }
  | { type: 'unknown'; reason: string };
export type Condition =
  | { op: 'all' | 'any'; terms: readonly Condition[] }
  | { op: 'not'; term: Condition }
  | { op: 'compare'; predicate: string; comparator: 'eq' | 'ne' | 'lt' | 'lte' | 'gt' | 'gte'; value: TypedValue }
  | { op: 'known'; predicate: string }
  | { op: 'unknown'; reason: string };
export type TruthValue = 'true' | 'false' | 'unknown';
export interface Bitemporal {
  validFrom?: ISOInstant; validTo?: ISOInstant;
  precision: 'instant' | 'day' | 'interval' | 'unresolved';
  recordedFrom: ISOInstant; recordedTo?: ISOInstant;
  unresolvedExpression?: string;
}
export interface Assertion {
  id: Id; ownerId: Id; workspaceId: Id; subject: SubjectRef; world: WorldRef;
  revision: Revision; predicate: string; value: TypedValue;
  kind: 'explicit_fact' | 'explicit_preference' | 'current_state' | 'inferred_hypothesis' | 'legacy_unverified';
  strength: 'hard' | 'soft' | 'unconfirmed'; conditions: Condition; exceptionIds: readonly Id[];
  temporal: Bitemporal; status: 'candidate' | 'active' | 'disputed' | 'superseded' | 'expired' | 'retracted';
  evidence: readonly EvidenceRef[]; policyLabelId: Id;
}
export interface SpeechAct {
  id: Id; kind: 'assert' | 'correct' | 'hypothesize' | 'ask' | 'propose' | 'accept' | 'reject' | 'revoke' | 'quote';
  evidence: readonly EvidenceRef[]; subject: SubjectRef; world: WorldRef;
  referentIds: readonly Id[]; scope: 'turn' | 'episode' | 'domain' | 'long_term';
  route: 'policy_restriction' | 'scenario' | 'memory_candidate' | 'work_state' | 'no_change';
  ambiguity: readonly string[];
}
export interface MemoryChangeProposal {
  id: Id; operation: 'ADD' | 'SUPPORT' | 'REFINE' | 'ADD_EXCEPTION' | 'SUPERSEDE' | 'CORRECT' | 'DISPUTE' | 'EXPIRE' | 'RETRACT';
  targetId?: Id; expectedRevision?: Revision; candidate: Partial<Assertion>;
  evidence: readonly EvidenceRef[]; extractorVersion: string; scope: ScopeHandle;
  privacyEpoch: PrivacyEpoch; idempotencyKey: string;
}
export interface DecisionExperience {
  id: Id; episodeId: Id; contextRevision: Revision; availableOptionIds: readonly Id[];
  suggestedOptionIds: readonly Id[]; selectedOptionIds: readonly Id[];
  rejected: readonly { optionId: Id; explicitReason?: EvidenceRef; validWhen: Condition }[];
  observedOutcomeIds: readonly Id[]; outcomeMissingness: 'known' | 'not_observed' | 'unavailable';
  hypotheses: readonly { id: Id; description: string; supportedBy: readonly Id[]; challengedBy: readonly Id[] }[];
}
export interface ProcessingWatermarks {
  receivedSequence: number; extractedContiguousSequence: number; indexedContiguousSequence: number;
  extractionGaps: readonly number[]; indexingGaps: readonly number[];
}
export type KnowledgeStatus = 'fresh' | 'stale' | 'conflict' | 'not_queried' | 'not_found' | 'failed' | 'forbidden' | 'unsupported' | 'known_absent' | 'unknown';
export interface Need {
  id: Id; typedKey: string; importance: 'must' | 'conditional' | 'optional'; applicableWhen: Condition;
  satisfaction: { mode: 'all' | 'any'; childNeedIds: readonly Id[] };
  acceptedSourceKinds: readonly string[]; freshnessPolicyId: Id;
  acquisitionCapabilityNames: readonly string[];
}
export interface NeedResult {
  needId: Id; status: KnowledgeStatus; evidence: readonly EvidenceRef[];
  scopeDescription: string; observedAt?: ISOInstant; fetchedAt?: ISOInstant; expiresAt?: ISOInstant;
  missingReason?: string;
}
export interface EvidenceBundle {
  id: Id; primary: readonly EvidenceRef[]; conditions: readonly EvidenceRef[];
  exceptions: readonly EvidenceRef[]; conflicts: readonly EvidenceRef[];
  estimatedTokens: number; coverage: 'complete_for_need' | 'conditional' | 'blocked';
}
export interface ContextPack {
  id: Id; contract: ContextContract; watermarks: ProcessingWatermarks;
  currentEventIds: readonly Id[]; overlayIds: readonly Id[]; checkpointId?: Id;
  bundles: readonly EvidenceBundle[]; needs: readonly NeedResult[];
  coverage: 'complete_for_candidate' | 'conditional' | 'blocked';
  // 实际文本由受控serializer按受众投影生成；不能通用JSON.stringify全对象。
}
export interface Dependency {
  consumerId: Id; producerId: Id; producerRevision: Revision;
  sensitivity: 'hard' | 'soft' | 'privacy';
  invalidation: 'block' | 'revalidate' | 'recompute' | 'expire';
  policyLineageIds: readonly Id[];
}
export interface Episode {
  id: Id; subject: SubjectRef; world: WorldRef; revision: Revision; goalIds: readonly Id[];
  acceptedConstraintRefs: readonly Id[]; optionIds: readonly Id[]; selectedOptionIds: readonly Id[];
  rejectedOptionReasons: readonly { optionId: Id; reasonId: Id; validWhen: Condition }[];
  attemptedOutcomeRefs: readonly Id[]; openQuestions: readonly string[];
  nextSmallQuestion?: string; artifactRefs: readonly { id: Id; version: Revision }[];
  coveredEventRanges: readonly { from: number; to: number }[];
}
export interface DomainDelta {
  sourceId: Id; domain: string; institutionId?: Id; termId?: Id;
  scopeKeys: readonly string[]; completeness: 'complete' | 'partial' | 'failed';
  sourceRevision?: string; fromCursor?: string; toCursor?: string;
  upserts: readonly { recordId: Id; value: JSONValue; evidence: EvidenceRef }[];
  explicitTombstones: readonly Id[];
  fetchedAt: ISOInstant; observedAt?: ISOInstant; errors: readonly string[];
}
export interface PlanCandidate {
  id: Id; revision: Revision; world: WorldRef; activityRefs: readonly Id[];
  introducedNeedIds: readonly Id[]; dependencies: readonly Dependency[];
  feasible: 'verified' | 'conditional' | 'not_feasible';
  violatedConstraints: readonly Id[]; unresolvedNeedIds: readonly Id[];
  tradeoffEvidenceIds: readonly Id[]; changeCostDescription?: string;
}
export type ActionStatus = 'proposed' | 'awaiting_approval' | 'approved' | 'dispatching' |
  'succeeded' | 'failed_confirmed' | 'outcome_unknown' | 'reconciling' | 'unresolved' |
  'cancelled' | 'cancel_requested' | 'cancellation_confirmed' | 'cancellation_unknown' | 'cannot_cancel';
export interface Action {
  id: Id; revision: Revision; capabilityName: string; arguments: JSONValue;
  audienceRef: Id; status: ActionStatus; digest: string; idempotencyKey: string;
  dependencyRefs: readonly Dependency[]; validUntil?: ISOInstant;
}
export interface Approval {
  id: Id; actionId: Id; actionDigest: string; actionRevision: Revision;
  principalId: Id; policyRevision: Revision; privacyEpoch: PrivacyEpoch;
  approvedAt: ISOInstant; expiresAt: ISOInstant; oneUse: true;
}
export interface ActionReceipt {
  id: Id; actionId: Id; attemptId: Id; sourceId: Id;
  status: 'confirmed_success' | 'confirmed_failure' | 'accepted_not_confirmed' | 'unknown';
  externalRecordId?: Id; observedAt: ISOInstant; evidence: readonly EvidenceRef[];
}
export interface CapabilityManifest {
  id: Id; version: string; trustTier: 'bundled_reviewed' | 'external_reviewed' | 'untrusted_disabled';
  capabilities: readonly {
    name: string; inputSchemaId: Id; outputSchemaId: Id;
    effect: 'read' | 'local_write' | 'external_write';
    requiredScopes: readonly string[]; supportedWorldKinds: readonly ('real' | 'scenario')[];
    freshnessPolicyId?: Id; supportsIdempotency: boolean; supportsInspect: boolean;
    supportsCancel: boolean; timeoutMs: number;
  }[];
  platforms: readonly string[]; allowedEgressHosts: readonly string[]; licenseEvidenceRef?: Id;
}
export interface InvocationLease {
  id: Id; scope: ScopeHandle; policyRevision: Revision; privacyEpoch: PrivacyEpoch;
  capabilityName: string; deadline: ISOInstant; actionAttemptId?: Id;
}
export interface CapabilityProvider {
  readonly manifest: CapabilityManifest;
  invoke(name: string, validatedArguments: JSONValue, lease: InvocationLease, signal: AbortSignal): Promise<Result<JSONValue>>;
}
export interface RunCapsule {
  id: Id; parentRunId: Id; contract: ContextContract;
  needIds: readonly Id[]; evidenceIds: readonly Id[]; readOnly: true; mayDelegate: false;
  expectedParentRevision: Revision;
}
export interface ContextReceipt {
  id: Id; runId: Id; contractRevision: Revision; policyRevision: Revision; privacyEpoch: PrivacyEpoch;
  watermarks: ProcessingWatermarks; providedEvidenceIds: readonly Id[];
  providedObjectVersions: readonly { id: Id; revision: Revision }[];
  needResults: readonly { needId: Id; status: KnowledgeStatus }[];
  excludedReasonCounts: Readonly<Record<string, number>>;
  providerVersion: string; toolAttemptIds: readonly Id[]; actionReceiptIds: readonly Id[];
  decisionChecks: readonly { checkId: Id; outcome: 'pass' | 'fail' | 'unknown' }[];
}
export interface SyncOperation {
  deviceId: Id; operationId: Id; objectId: Id; baseRevision: Revision;
  delta: JSONValue; causalReferences: readonly Id[]; policyEpoch: PrivacyEpoch; createdAt: ISOInstant;
}
export interface ModelCapabilities {
  providerId: Id; revision: string; toolDialect: string; structuredOutputDialect?: string;
  modalities: readonly ('text' | 'image' | 'audio')[]; maxContextTokens: number;
  opaqueStateRules: 'none' | 'provider_required_bounded_chain';
}
export interface ModelProvider {
  readonly capabilities: ModelCapabilities;
  generate(pack: ContextPack, toolNames: readonly string[], opaqueStateRef: Id | undefined, signal: AbortSignal):
    Promise<Result<{ message: JSONValue; opaqueStateRef?: Id }>>;
  invalidateBoundary(previousBoundaryId: Id, privacyEpoch: PrivacyEpoch): Promise<void>;
}
export interface ClockPort { now(): ISOInstant; monotonicMs(): number; }
export interface CoreServices {
  ingest(event: SourceEvent, scope: ScopeHandle): Promise<Result<{ sequence: number }>>;
  buildContext(contract: ContextContract): Promise<Result<ContextPack>>;
  proposeMemoryChange(change: MemoryChangeProposal): Promise<Result<{ proposalId: Id }>>;
  readEvidence(ref: EvidenceRef, scope: ScopeHandle): Promise<Result<JSONValue>>;
  applyUserCorrection(targetId: Id, evidence: EvidenceRef, scope: ScopeHandle): Promise<Result<{ revision: Revision }>>;
  forget(targetIds: readonly Id[], scope: ScopeHandle): Promise<Result<{ privacyEpoch: PrivacyEpoch; cleanupId: Id }>>;
  prepareAction(action: Action, scope: ScopeHandle): Promise<Result<Action>>;
  executeApproved(actionId: Id, approvalId: Id, scope: ScopeHandle): Promise<Result<ActionReceipt>>;
}

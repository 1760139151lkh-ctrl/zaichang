import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { build } from 'esbuild';
import { isolatedEnvironment } from './test-environment.mjs';
const live = process.argv.includes('--live'),
  out = path.resolve(
    process.env.ZAICHANG_EVAL_REPORT ||
      'artifacts/harness/' + (live ? 'live-evaluation' : 'offline-evaluation'),
  );
fs.mkdirSync(out, { recursive: true });
if (live) {
  if (process.env.ZAICHANG_ALLOW_LIVE_EVAL !== '1' || !process.env.ZAICHANG_TEST_DEEPSEEK_KEY) {
    fs.writeFileSync(
      path.join(out, 'live.json'),
      JSON.stringify(
        {
          status: 'not_run',
          kind: 'real_model',
          reason:
            'Requires ZAICHANG_ALLOW_LIVE_EVAL=1 and separately supplied ZAICHANG_TEST_DEEPSEEK_KEY. Production credentials are never read.',
          model: 'deepseek-v4-flash',
          runs: 0,
          semanticMetrics: { precision: null, conditionRetention: null, bundleRecall: null, denominator: 0 },
          goldStatus: 'provisional engineering slots; independent review required',
          vectorBaseline: 'not_run_no_embedding_provider',
        },
        null,
        2,
      ),
    );
    console.log('Real model evaluation: not_run (explicit authorization/test key absent).');
  } else {
    const env = isolatedEnvironment('live-evaluation');
    env.ZAICHANG_EVAL_REPORT = out;
    const compiled = path.join(env.ZAICHANG_DATA_DIR, 'live-eval.cjs');
    await build({
      entryPoints: ['tests/harness/live-eval.ts'],
      bundle: true,
      platform: 'node',
      format: 'cjs',
      target: 'node24',
      outfile: compiled,
      loader: { '.md': 'text' },
    });
    const result = spawnSync(process.execPath, [compiled], { env, stdio: 'inherit', windowsHide: true });
    process.exitCode = result.status ?? 1;
  }
} else {
  const result = spawnSync(
    process.execPath,
    ['scripts/test-harness.mjs', '--suite', 'all', '--report-dir', out],
    { stdio: 'inherit', windowsHide: true },
  );
  process.exitCode = result.status ?? 1;
}


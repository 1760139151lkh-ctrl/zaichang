import { build } from 'esbuild';
import { spawn } from 'node:child_process';
import { isolatedEnvironment } from './test-environment.mjs';
const env = isolatedEnvironment('core');
await build({
  entryPoints: ['tests/core.test.ts'],
  bundle: true,
  outfile: '.test-data/core.test.cjs',
  platform: 'node',
  format: 'cjs',
  target: 'node24',
  loader: { '.md': 'text' },
});
const child = spawn(process.execPath, ['--test', '.test-data/core.test.cjs'], { stdio: 'inherit', env });
child.on('exit', (code) => process.exit(code ?? 1));

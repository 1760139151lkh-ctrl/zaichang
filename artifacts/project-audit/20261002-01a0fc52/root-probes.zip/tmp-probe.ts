import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
const root=fs.mkdtempSync(path.join(os.tmpdir(),'probe-')); process.env.ZAICHANG_TEST='1'; process.env.ZAICHANG_TEST_ROOT=root; process.env.ZAICHANG_DATA_DIR=path.join(root,'root'); fs.mkdirSync(process.env.ZAICHANG_DATA_DIR);
import { ScenarioFixture } from './tests/harness/scenario-fixture';
const s:any=new ScenarioFixture({},{}); console.log(Object.keys(s),!!s.f,s.f && Object.keys(s.f));

console.log(JSON.stringify({ argv: process.argv, execPath: process.execPath, cwd: process.cwd() }));

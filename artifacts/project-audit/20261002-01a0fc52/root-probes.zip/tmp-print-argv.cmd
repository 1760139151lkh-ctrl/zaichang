@echo off
node "%~dp0tmp-print-argv.mjs"

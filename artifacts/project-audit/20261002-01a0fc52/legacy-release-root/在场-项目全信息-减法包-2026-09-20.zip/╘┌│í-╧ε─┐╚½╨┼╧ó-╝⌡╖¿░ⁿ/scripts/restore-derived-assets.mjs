import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const files = ['manifest.json', 'places.json', 'source.osm.json.gz'];
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
for (const name of files) {
  const source = path.resolve('assets/map-v2', name);
  const destination = path.resolve('public/map-v2', name);
  if (!source.startsWith(path.resolve('assets/map-v2') + path.sep) || !destination.startsWith(path.resolve('public/map-v2') + path.sep)) throw new Error('Derived map path escaped its boundary.');
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  if (!fs.existsSync(destination) || hash(source) !== hash(destination)) fs.copyFileSync(source, destination);
  if (hash(source) !== hash(destination)) throw new Error('Derived map asset verification failed: ' + name);
}
console.log('Restored three byte-identical public map inputs from their canonical asset copies.');

import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { auditRun } from './audit-understanding-run.mjs';

const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const casePattern = /^[SN]\d+-r\d+\.json$/;

export function applyReassessments(stories, rows, replayReports) {
  const byKey = new Map(rows.map(row => [`${row.id}:${row.repeat}`, row]));
  const replacements = [], errors = [];
  for (const replay of replayReports) {
    const key = `${replay.id}:${replay.repeat}`, original = byKey.get(key);
    const semantic = replay.semantic;
    if (!original) { errors.push(`${key}: original record missing`); continue; }
    if (replay.status !== 'passed_reassessment' || !semantic || !['passed','needsMet','truthful','correctionRespected','autonomyRespected'].every(field => semantic[field] === true)) {
      errors.push(`${key}: reassessment is not a complete pass`); continue;
    }
    const failures = (original.calls || []).filter(call => call.error);
    if (original.status !== 'failed' || (original.mechanismErrors || []).length || !(original.turns || []).every(turn => turn.status === 'done') || !failures.length || failures.some(call => call.phase !== 'evaluation_judge')) {
      errors.push(`${key}: original product trajectory had a non-judge failure`); continue;
    }
    replacements.push({ key, replay, original });
  }
  if (errors.length) throw new Error(errors.join('; '));
  const replacementMap = new Map(replacements.map(item => [item.key, item]));
  const adjusted = rows.map(row => {
    const replacement = replacementMap.get(`${row.id}:${row.repeat}`);
    return replacement ? { ...row, status: 'passed', error: undefined, semantic: replacement.replay.semantic,
      reassessment: { status: replacement.replay.status, originalStatus: row.status, originalError: row.error } } : row;
  });
  return { adjusted, replacements, audit: auditRun(stories, adjusted, 3) };
}

if (path.basename(process.argv[1] || '') === 'audit-understanding-reassessments.mjs') {
  const artifactRoot = path.resolve('artifacts/understanding-action');
  const directory = path.resolve(process.argv[2] || path.join(artifactRoot, 'luna-sixty-definitive-final'));
  const replayFiles = process.argv.slice(3).map(value => path.resolve(value));
  if (!directory.startsWith(artifactRoot + path.sep) || !replayFiles.length) throw new Error('Use one artifact batch and at least one explicit replay report.');
  const stories = JSON.parse(fs.readFileSync(path.join(directory, 'frozen-stories.json'), 'utf8'));
  const rows = fs.readdirSync(directory).filter(file => casePattern.test(file)).map(file => JSON.parse(fs.readFileSync(path.join(directory, file), 'utf8')));
  const replayReports = replayFiles.map(file => {
    if (!file.startsWith(artifactRoot + path.sep)) throw new Error('Replay report must remain under the understanding artifact root.');
    const replay = JSON.parse(fs.readFileSync(file, 'utf8'));
    const original = path.resolve(artifactRoot, replay.originalFile || '');
    if (!original.startsWith(directory + path.sep) || !fs.existsSync(original)) throw new Error('Replay original does not belong to this batch.');
    const digest = sha256(fs.readFileSync(original));
    if (digest !== replay.originalSha256) throw new Error('Replay original hash changed: ' + path.basename(original));
    return { ...replay, replayFile: path.relative(artifactRoot, file).replaceAll('\\', '/'), verifiedOriginal: path.relative(artifactRoot, original).replaceAll('\\', '/'), verifiedSha256: digest };
  });
  const { replacements, audit } = applyReassessments(stories, rows, replayReports);
  const report = { checkedAt: new Date().toISOString(), kind: 'immutable_original_reassessment_audit', batch: path.relative(artifactRoot, directory).replaceAll('\\', '/'),
    originalRecords: rows.length, originalAudit: auditRun(stories, rows, 3), reassessments: replacements.map(({ key, replay }) => ({ key, replayFile: replay.replayFile, originalFile: replay.verifiedOriginal, originalSha256: replay.verifiedSha256, originalStatus: replay.originalStatus, status: replay.status, calls: replay.calls?.length || 0 })),
    adjustedAudit: audit,
    originalsModified: false,
    limitations: ['Only failures caused exclusively by evaluation_judge errors after every product turn reached done can be reassessed.', 'Original case files and their failure status remain unchanged.', 'A model reassessment is not independent human review or a hidden holdout.'],
  };
  fs.writeFileSync(path.join(directory, 'audit-with-reassessments.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ originalPassed: report.originalAudit.passedRuns, reassessedPassed: audit.passedRuns, expected: audit.expectedRuns, complete: audit.complete, backendModelThresholdsMet: audit.backendModelThresholdsMet, reassessments: report.reassessments.length }));
}

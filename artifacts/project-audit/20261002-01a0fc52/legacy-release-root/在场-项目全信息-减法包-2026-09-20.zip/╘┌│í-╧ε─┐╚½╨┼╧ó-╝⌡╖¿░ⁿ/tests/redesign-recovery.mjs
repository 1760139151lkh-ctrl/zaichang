import { _electron as electron } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { isolatedEnvironment } from '../scripts/test-environment.mjs';

const env = isolatedEnvironment('astra-recovery');
delete env.ZAICHANG_MODEL_TRANSPORT;
env.ZAICHANG_PROJECT_DEEPSEEK_KEY = 'synthetic-ui-contract-key';
const out = path.resolve(
  process.env.ZAICHANG_RECOVERY_REPORT || 'artifacts/understanding-action/astra-redesign-recovery',
);
await mkdir(out, { recursive: true });
const app = await electron.launch({ args: [process.cwd()], env, timeout: 30000 });
const page = await app.firstWindow();
page.setDefaultTimeout(18000);
const report = {
  kind: 'real_electron_synthetic_transport_recovery',
  modelEvidence: false,
  checks: [],
  screenshots: [],
  errors: [],
  status: 'running',
};
page.on('pageerror', (error) => report.errors.push(String(error)));
const input = page.getByRole('textbox', { name: '和在场说说' });
const shot = async (name) => {
  await page.screenshot({ path: path.join(out, name + '.png'), animations: 'disabled', scale: 'css' });
  report.screenshots.push(name + '.png');
};
const mode = (value) =>
  app.evaluate((_electron, value) => {
    globalThis.__uiMode = value;
  }, value);
const settle = () =>
  page.getByRole('button', { name: '停止回复', exact: true }).waitFor({ state: 'detached', timeout: 90000 });
try {
  await input.waitFor();
  await page.emulateMedia({ colorScheme: 'light' });
  await app.evaluate(() => {
    globalThis.__uiMode = '401';
    globalThis.__uiRequests = [];
    globalThis.__uiAborted = 0;
    globalThis.fetch = async (url, init) => {
      if (String(url) !== 'https://api.deepseek.com/chat/completions')
        throw new Error('Network blocked by synthetic UI fixture');
      const body = JSON.parse(init.body);
      globalThis.__uiRequests.push(body);
      const mode = globalThis.__uiMode;
      const control = body.tools?.some((t) => t.function?.name === 'propose_turn_controls');
      if (!control && mode === '401') return new Response('SYNTHETIC_PRIVATE_ERROR_BODY', { status: 401 });
      if (!control && mode === '429') return new Response('', { status: 429 });
      if (!control && mode === 'offline') throw new TypeError('Synthetic network disconnected');
      if (!control && mode === 'stall')
        return new Promise((_resolve, reject) => {
          const abort = () => {
            globalThis.__uiAborted++;
            reject(init.signal.reason);
          };
          if (init.signal.aborted) abort();
          else init.signal.addEventListener('abort', abort, { once: true });
        });
      const proposal = {
        retention: 'unchanged',
        sourceAllowlist: null,
        sourceExclusions: [],
        sourceBasis: null,
        subject: 'none',
        world: 'real',
        audience: 'self',
        actions: 'unchanged',
        actionsApplyToWholeTurn: false,
        specificActionLimits: [],
        release: null,
        basis: [],
        uncertain: false,
        uncertainControls: [],
      };
      const long =
        '# 先为今天留一点余地\n\n这是一份合成长内容，只用于检查排版。\n\n' +
        Array.from(
          { length: 14 },
          (_, i) =>
            `## ${i + 1}. 一段可以读完的内容\n\n事情多的时候，不必立刻把每一分钟排满。先看清已经确定的部分，再给还没决定的事情留出空间。你可以停下来，也可以回到刚才的位置接着读。\n\n- 已经决定的事保留\n- 还没确定的地方，继续核对\n\n`,
        ).join('') +
        '| 时间 | 事项 | 提醒 | 资料来源 | 需要核对的内容 | 备注 |\n|---|---|---|---|---|---|\n| 14:00 | 讨论课 | 未开启 | 合成资料 | 时间未最终确认 | 只用于排版检查 |\n\n```text\n' +
        'long-unbroken-content-'.repeat(30) +
        '\n```';
      const payload = {
        choices: [
          {
            delta: control
              ? {
                  tool_calls: [
                    {
                      index: 0,
                      id: 'ui-control',
                      type: 'function',
                      function: { name: 'propose_turn_controls', arguments: JSON.stringify(proposal) },
                    },
                  ],
                }
              : { content: mode === 'long' ? long : '已收到这张合成图片，只参考本条与附件。' },
            finish_reason: control ? 'tool_calls' : 'stop',
          },
        ],
      };
      const encoded = new TextEncoder().encode('data: ' + JSON.stringify(payload) + '\n\ndata: [DONE]\n\n');
      return new Response(
        new ReadableStream({
          start(c) {
            c.enqueue(encoded);
            c.close();
          },
        }),
        { headers: { 'Content-Type': 'text/event-stream' } },
      );
    };
  });
  await page.evaluate(() => window.zaichang.saveSettings({ memoryEnabled: false }));
  await app.evaluate(({ dialog }, file) => {
    dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [file] });
  }, path.resolve('build/icon.png'));
  await page.getByRole('button', { name: '添加资料' }).click();
  await page.getByRole('menuitem', { name: /添加图片/ }).click();
  await page.locator('.attachment-preview').waitFor();
  await page.getByRole('button', { name: '设置本轮资料范围' }).click();
  await page.getByRole('combobox', { name: '本轮参考范围' }).selectOption('current_sources_only');
  await page.getByRole('combobox', { name: '本轮保留方式' }).selectOption('history_no_inference');
  await page.getByRole('button', { name: '用于下一条消息' }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  await input.fill('请看这张合成图片，只参考本条与附件。');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await settle();
  await page.getByRole('button', { name: '重新试试', exact: true }).waitFor();
  await shot('01-failed-image');
  assert.equal((await page.textContent('body')).includes('SYNTHETIC_PRIVATE_ERROR_BODY'), false);
  const originalState = await page.evaluate(() => window.zaichang.state());
  const sessionId = originalState.conversations[0].id;
  const original = (await page.evaluate((id) => window.zaichang.messages(id), sessionId)).find(
    (m) => m.role === 'user',
  );
  await input.fill('新的草稿与新附件，都不能被重试清空。');
  const textFile = path.join(env.ZAICHANG_DATA_DIR, 'next-message-only.txt');
  await writeFile(textFile, 'ONLY_IN_NEW_DRAFT_9841');
  await app.evaluate(({ dialog }, file) => {
    dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [file] });
  }, textFile);
  await page.getByRole('button', { name: '添加资料' }).click();
  await page.getByRole('menuitem', { name: /添加文件/ }).click();
  await page.getByRole('button', { name: '设置本轮资料范围' }).click();
  await page.getByRole('combobox', { name: '本轮参考范围' }).selectOption('none');
  await page.getByRole('button', { name: '用于下一条消息' }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  await mode('ok');
  await page.getByRole('button', { name: '重新试试', exact: true }).last().click();
  await settle();
  const messages = await page.evaluate((id) => window.zaichang.messages(id), sessionId);
  const retry = messages.filter((m) => m.role === 'user').at(-1);
  assert.equal(retry.image.dataUrl, original.image.dataUrl);
  assert.deepEqual(retry.requestControls, original.requestControls);
  assert.equal(retry.content, original.content);
  assert.equal(await input.inputValue(), '新的草稿与新附件，都不能被重试清空。');
  await page.locator('.attachment').getByText('next-message-only.txt').waitFor();
  assert.equal(messages.at(-1).status, 'done');
  await shot('02-retry-preserves-new-draft');
  report.checks.push(
    '401 is recoverable and hides private error body; retry uses original image/text/scope while preserving new text and attachment',
  );
  await page.getByRole('button', { name: '连接与偏好', exact: true }).click();
  await page.locator('.connection-advanced summary').click();
  for (const value of ['401', '429', 'offline']) {
    await mode(value);
    await page.getByRole('button', { name: '测试连接', exact: true }).click();
    await page.getByRole('alert').waitFor();
    await shot('03-connection-' + value);
  }
  await mode('stall');
  await page.getByRole('button', { name: '测试连接', exact: true }).click();
  await page.getByRole('button', { name: '取消测试', exact: true }).click();
  await page.getByText('已取消测试', { exact: true }).waitFor();
  assert.ok(await app.evaluate(() => globalThis.__uiAborted > 0));
  await page.getByRole('button', { name: '测试连接', exact: true }).click();
  await page.getByRole('button', { name: '取消测试', exact: true }).waitFor();
  await page.getByRole('button', { name: '关于你', exact: true }).click();
  assert.ok(await app.evaluate(() => globalThis.__uiAborted >= 2));
  report.checks.push(
    '401/429/offline errors stay beside connection control; cancel and leaving connection page abort transport',
  );
  await page.getByRole('button', { name: '新的对话', exact: true }).click();
  await mode('long');
  await input.fill('显示合成长内容，供排版检查。');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await settle();
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1720, 1040));
  await page.waitForTimeout(250);
  await page.locator('.message-scroll').evaluate((el) => el.scrollTo(0, 0));
  await shot('04-long-fullscreen');
  report.reading = await page.evaluate(() => ({
    width: document.querySelector('.messages').getBoundingClientRect().width,
    fontSize: parseFloat(getComputedStyle(document.querySelector('.markdown')).fontSize),
    composer: document.querySelector('.composer').getBoundingClientRect().width,
  }));
  const inputGeometry = await input.evaluate(el => ({ scroll: el.scrollHeight, client: el.clientHeight }));
  assert.ok(inputGeometry.scroll <= inputGeometry.client + 1, 'Empty composer must resize with responsive font metrics');
  assert.ok(report.reading.width <= 860 && report.reading.fontSize >= 16);
  assert.ok(report.reading.composer >= report.reading.width + 100);
  await page.emulateMedia({ reducedMotion: 'reduce', colorScheme: 'dark' });
  await page.getByRole('button', { name: '回到最新消息' }).click();
  await shot('05-long-table-dark');
  await app.evaluate(({ BrowserWindow }) => {
    const w = BrowserWindow.getAllWindows()[0];
    w.unmaximize();
    w.setSize(680, 570);
  });
  await shot('06-long-narrow');
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await input.fill('STOP_CANARY_58');
  await mode('stall');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await page.getByRole('button', { name: '停止回复', exact: true }).waitFor();
  await page.getByRole('button', { name: '停止回复', exact: true }).click();
  await settle();
  await page.getByRole('button', { name: '重新试试', exact: true }).last().waitFor();
  await shot('07-stopped');
  await page.getByRole('button', { name: '新的对话', exact: true }).click();
  await page.getByRole('button', { name: '设置本轮资料范围' }).click();
  await page.getByRole('combobox', { name: '本轮处理方式' }).selectOption('local_only');
  await page.getByRole('button', { name: '用于下一条消息' }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  const beforeLocal = await app.evaluate(() => globalThis.__uiRequests.length);
  await input.fill('LOCAL_ONLY_UI_CANARY_589：这一条不要离开本机。');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await settle();
  assert.equal(await app.evaluate(() => globalThis.__uiRequests.length), beforeLocal);
  await shot('08-local-only');
  report.checks.push('Native pre-send local-only control makes zero model requests');
  report.checks.push(
    'Long markdown/table/code stay in reading width, full-screen input is wider, narrow window has no horizontal page overflow, stop exposes retry',
  );
  assert.deepEqual(report.errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.failure = String(error);
  await shot('failure').catch(() => {});
  throw error;
} finally {
  await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
  await app.evaluate(({ app }) => app.exit(0)).catch(() => {});
}

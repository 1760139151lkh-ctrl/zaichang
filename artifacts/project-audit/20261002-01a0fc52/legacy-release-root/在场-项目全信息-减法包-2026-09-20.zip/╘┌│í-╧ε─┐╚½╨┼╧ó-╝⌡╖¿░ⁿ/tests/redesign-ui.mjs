import { _electron as electron } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { isolatedEnvironment } from '../scripts/test-environment.mjs';

const env = isolatedEnvironment('astra-redesign');
delete env.ZAICHANG_MODEL_TRANSPORT;
delete env.ZAICHANG_PROJECT_DEEPSEEK_KEY;
const out = path.resolve('artifacts/understanding-action/astra-redesign');
await mkdir(out, { recursive: true });
const app = await electron.launch({ args: [process.cwd()], env, timeout: 30000 });
const page = await app.firstWindow();
page.setDefaultTimeout(12000);
const report = {
  kind: 'synthetic_real_electron_ux',
  developer: 'Astra',
  model: 'local_demo',
  checks: [],
  errors: [],
  screenshots: [],
  limits: ['No human research; synthetic tasks do not prove model quality.'],
};
page.on('pageerror', (e) => report.errors.push(String(e)));
async function shot(name) {
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: path.join(out, name + '.png'), animations: 'disabled', scale: 'css' });
  report.screenshots.push(name + '.png');
}
try {
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1220, 850));
  await page.getByRole('textbox', { name: '和在场说说' }).waitFor();
  await page.emulateMedia({ colorScheme: 'light' });
  await shot('01-home-light');
  await page.emulateMedia({ colorScheme: 'dark' });
  await shot('02-home-dark');
  await page.emulateMedia({ colorScheme: 'light' });
  await page.getByRole('button', { name: '安排一下今天', exact: true }).click();
  const input = page.getByRole('textbox', { name: '和在场说说' });
  assert.equal(await input.inputValue(), '帮我安排一下今天');
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await page.getByRole('button', { name: '加入我的安排', exact: true }).waitFor();
  await shot('03-action-ready');
  await page.getByRole('button', { name: '加入我的安排', exact: true }).click();
  await page.locator('.saved-action-receipt').waitFor();
  await shot('04-action-saved');
  report.checks.push('Original chat → native local action → receipt-backed saved object');
  await page.getByRole('button', { name: /^我的安排/ }).click();
  await page.locator('.agenda-item').waitFor();
  await shot('05-agenda');
  await page.getByRole('button', { name: '回到对话', exact: true }).click();
  await page.getByRole('button', { name: '补充或纠正', exact: true }).click();
  assert.match(await input.inputValue(), /需要改正/);
  await page.getByRole('button', { name: '关于你', exact: true }).click();
  await page.getByText('告诉在场一件事', { exact: true }).click();
  await page.getByRole('textbox', { name: '偏好内容' }).fill('我喜欢安静地读书，但讨论时也喜欢有人一起。');
  await page.getByRole('button', { name: '记住这件事', exact: true }).click();
  await page.locator('.memory-row-current').waitFor();
  await shot('06-about-you');
  await page.locator('.memory-row-summary').first().click();
  await page.getByRole('button', { name: '改正这条内容', exact: true }).click();
  await page.getByRole('textbox', { name: '偏好内容' }).fill('我现在更喜欢一点背景声，深夜仍想安静。');
  await page.getByRole('button', { name: '保存修改', exact: true }).click();
  await page.locator('.memory-row-current').filter({ hasText: '背景声' }).waitFor();
  await page.locator('.memory-row-current .memory-row-summary').first().click();
  await shot('07-memory-correction');
  await page.getByRole('button', { name: '连接与偏好', exact: true }).click();
  await shot('08-connections');
  await page.getByRole('tab', { name: '偏好', exact: true }).click();
  await shot('09-preferences');
  await page.getByRole('tab', { name: '连接', exact: true }).click();
  await page.getByRole('button', { name: /校园资料与天气/ }).click();
  await shot('10-sources');
  await page.getByRole('button', { name: '回到对话', exact: true }).click();
  assert.match(await input.inputValue(), /需要改正/);
  report.checks.push(
    'Navigation preserves draft; memory create/correction reaches native storage; settings/source paths reachable',
  );
  await page.getByRole('button', { name: '设置本轮资料范围' }).click();
  await page.getByRole('combobox', { name: '本轮处理方式' }).selectOption('local_only');
  await shot('11-scope');
  await page.getByRole('button', { name: '用于下一条消息' }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  await page.getByRole('button', { name: '新的对话', exact: true }).click();
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(680, 570));
  await shot('12-home-narrow');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  await page.getByRole('button', { name: '关于你', exact: true }).click();
  await shot('13-memory-narrow');
  await page.emulateMedia({ colorScheme: 'dark', reducedMotion: 'reduce' });
  await shot('14-memory-dark-narrow');
  const animations = await page.locator('.page-panel').evaluate((el) => getComputedStyle(el).animationName);
  assert.equal(animations, 'none');
  report.checks.push('680×570 navigation, reading and controls; reduced motion has no page animation');
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].setSize(1220, 850));
  await page.emulateMedia({ colorScheme: 'light', reducedMotion: 'no-preference' });
  await page.getByRole('button', { name: '打开校园地图', exact: true }).click();
  await page.locator('.campus-v2-stage canvas').first().waitFor();
  await page.waitForTimeout(900);
  await shot('15-campus');
  await page.getByRole('button', { name: '返回关于你', exact: true }).click();
  await page.getByRole('button', { name: '新的对话', exact: true }).click();
  await input.fill('草稿保留检查：读完这一段之后，再决定下一步。');
  await page.keyboard.press('Control+k');
  await page.getByRole('textbox', { name: '搜索对话标题' }).fill('没有这段合成对话');
  await shot('16-history-empty');
  await page.keyboard.press('Escape');
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  assert.equal(await input.evaluate((el) => el === document.activeElement), true);
  await page.getByRole('button', { name: '添加资料' }).click();
  await page.keyboard.press('ArrowDown');
  assert.match(await page.evaluate(() => document.activeElement.textContent), /添加文件/);
  await page.keyboard.press('Escape');
  assert.equal(
    await page.getByRole('button', { name: '添加资料' }).evaluate((el) => el === document.activeElement),
    true,
  );
  report.checks.push(
    'Keyboard history search/empty/Escape restores input; upload menu arrow keys/Escape restore trigger',
  );
  await page.getByRole('button', { name: '设置本轮资料范围' }).click();
  await page.getByRole('combobox', { name: '本轮处理方式' }).selectOption('cloud_allowed');
  await page.getByRole('button', { name: '用于下一条消息' }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].close());
  await page.getByRole('heading', { name: '还有没说完的话。', exact: true }).waitFor();
  await shot('17-native-close-drafts');
  await page.getByRole('button', { name: '继续编辑', exact: true }).click();
  await page.getByRole('dialog').waitFor({ state: 'detached' });
  assert.match(await input.inputValue(), /草稿保留检查/);
  await page.getByRole('button', { name: '保存草稿到本机', exact: true }).click();
  await page.getByText('草稿已保存在本机', { exact: true }).waitFor();
  await input.fill('重启恢复检查：这是明确选择保存的草稿。');
  await page.getByRole('button', { name: '关闭在场', exact: true }).click();
  const closed = app.waitForEvent('close');
  await page.getByRole('button', { name: '保存并退出', exact: true }).click();
  await closed;
  const restarted = await electron.launch({ args: [process.cwd()], env, timeout: 30000 });
  try {
    const restored = await restarted.firstWindow();
    await restored.getByRole('textbox', { name: '和在场说说' }).waitFor();
    assert.equal(
      await restored.getByRole('textbox', { name: '和在场说说' }).inputValue(),
      '重启恢复检查：这是明确选择保存的草稿。',
    );
    const state = await restored.evaluate(() => window.zaichang.state());
    assert.equal(
      state.memories.some((m) => m.text.includes('背景声')),
      true,
    );
    assert.equal(state.agenda.length, 1);
    await restored.screenshot({
      path: path.join(out, '18-restart-restored.png'),
      animations: 'disabled',
      scale: 'css',
    });
    report.screenshots.push('18-restart-restored.png');
  } finally {
    await restarted.evaluate(({ app }) => app.exit(0)).catch(() => {});
  }
  report.checks.push(
    'Native window close shows recoverable draft review; cancel preserves input; explicit save/close restores original draft after real restart',
  );
  assert.deepEqual(report.errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.failure = String(error);
  await shot('failure').catch(() => {});
  throw error;
} finally {
  await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ status: report.status, checks: report.checks, failure: report.failure }));
  await app.evaluate(({ app }) => app.exit(0)).catch(() => {});
}

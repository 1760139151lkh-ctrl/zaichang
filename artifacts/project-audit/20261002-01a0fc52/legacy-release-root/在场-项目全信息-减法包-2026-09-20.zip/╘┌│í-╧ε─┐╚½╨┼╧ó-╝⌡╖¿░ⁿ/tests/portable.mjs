import { chromium } from '@playwright/test';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdir, writeFile, mkdtemp } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { isolatedEnvironment } from '../scripts/test-environment.mjs';

// NSIS portable does not expose Electron's main-process inspector to _electron.launch.
// Launch the actual self-extracting EXE and inspect only its own new renderer via CDP.
const exe = path.resolve('release/astra-redesign/Zaichang-0.3.0-Astra-Frontend-Windows.exe');
const env = isolatedEnvironment('portable-cdp');
delete env.ZAICHANG_MODEL_TRANSPORT;
delete env.ZAICHANG_PROJECT_DEEPSEEK_KEY;
const cwd = await mkdtemp(path.join(os.tmpdir(), 'zaichang-portable-cdp-'));
const out = path.resolve('artifacts/understanding-action/astra-portable-final');
await mkdir(out, { recursive: true });
const portOwner = createServer();
await new Promise(resolve => portOwner.listen(0, '127.0.0.1', resolve));
const port = portOwner.address().port;
await new Promise(resolve => portOwner.close(resolve));
const processHandle = spawn(exe, [`--remote-debugging-port=${port}`], { cwd, env, stdio: 'ignore', windowsHide: true });
let exited = false;
processHandle.on('exit', () => { exited = true; });
let browser;
const report = { kind: 'actual_portable_executable_ui', executable: exe, cwd, isolatedDataDirectory: env.ZAICHANG_DATA_DIR, status: 'running', checks: [], limitation: 'This checks the portable launcher and local UI. Real Luna engine evidence is recorded separately from packaged Electron.' };
try {
  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    try { const r = await fetch(`http://127.0.0.1:${port}/json/version`); if (r.ok) break; } catch {}
    if (exited) throw new Error('Portable process exited before its renderer became available.');
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`, { timeout: 10000 });
  const context = browser.contexts()[0];
  const page = context.pages()[0] || await context.waitForEvent('page');
  page.setDefaultTimeout(15000);
  await page.getByRole('heading', { name: /把眼前的事/ }).waitFor();
  assert.match(page.url(), /^app:\/\/zaichang/);
  await page.emulateMedia({ colorScheme: 'light' });
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: path.join(out, '01-portable-home.png'), animations: 'disabled', scale: 'css' });
  await page.getByRole('button', { name: '安排一下今天', exact: true }).click();
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await page.getByRole('button', { name: '加入我的安排', exact: true }).waitFor();
  await page.getByRole('button', { name: '加入我的安排', exact: true }).click();
  await page.locator('.saved-action-receipt').waitFor();
  assert.equal((await page.evaluate(() => window.zaichang.state())).agenda.length, 1);
  await page.screenshot({ path: path.join(out, '02-portable-local-action.png'), animations: 'disabled', scale: 'css' });
  report.checks.push('Self-extracting portable EXE launched outside checkout', 'Bundled renderer loaded', 'Original input and native SQLite action succeeded');
  await page.evaluate(() => window.zaichang.window('close'));
  report.status = 'passed';
} catch (error) { report.status = 'failed'; report.failure = String(error); throw error; }
finally {
  await browser?.close().catch(() => {});
  if (!exited) processHandle.kill();
  await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
}

import { _electron as electron } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { isolatedEnvironment } from '../scripts/test-environment.mjs';

if (process.env.ZAICHANG_MODEL_TRANSPORT !== 'luna-app-server-test')
  throw new Error('Use the explicitly authorized Luna test wrapper.');
const env = isolatedEnvironment('astra-live');
const out = path.resolve(
  process.env.ZAICHANG_REDESIGN_LIVE_REPORT || 'artifacts/understanding-action/astra-redesign-live',
);
await mkdir(out, { recursive: true });
const app = await electron.launch({ args: [process.cwd()], env, timeout: 30000 });
const page = await app.firstWindow();
page.setDefaultTimeout(15000);
const report = {
  kind: 'real_model_electron_actions_and_draft',
  providerId: 'openai-app-server',
  model: 'gpt-5.6-luna',
  temporaryTestSubstitute: true,
  checks: [],
  errors: [],
  screenshots: [],
  status: 'running',
};
page.on('pageerror', (error) => report.errors.push(String(error)));
const shot = async (name) => {
  await page.screenshot({ path: path.join(out, name + '.png'), animations: 'disabled', scale: 'css' });
  report.screenshots.push(name + '.png');
};
try {
  await page.getByRole('textbox', { name: '和在场说说' }).waitFor();
  await page.emulateMedia({ colorScheme: 'light' });
  await app.evaluate(() => {
    globalThis.__redesignModels = [];
    const original = globalThis.fetch;
    globalThis.fetch = async (url, init) => {
      if (String(url) === 'https://chatgpt.com/backend-api/codex/responses') {
        const input = JSON.parse(String(init?.body || '{}'));
        globalThis.__redesignModels.push(input.model);
      }
      return original(url, init);
    };
  });
  const text =
    '这是合成体验验收：今天有点累，先简单回应一句就好。另外请直接在本机登记一件待办，标题是「核对分享提纲」，不设时间、不设提醒。再给讨论课老师准备一段未发送的草稿，公开内容只包括：我周四下午有空，想约十分钟讨论。语气自然礼貌，不提疲惫，不要发送。';
  await page.getByRole('textbox', { name: '和在场说说' }).fill(text);
  await page.getByRole('button', { name: '发送', exact: true }).click();
  await page.getByRole('button', { name: '停止回复' }).waitFor({ state: 'detached', timeout: 300000 });
  const state = await page.evaluate(() => window.zaichang.state());
  const messages = await page.evaluate((id) => window.zaichang.messages(id), state.conversations[0].id);
  const reply = messages.filter((m) => m.role === 'assistant').at(-1);
  assert.equal(reply.status, 'done');
  assert.equal(state.agenda.filter((a) => a.title === '核对分享提纲').length, 1);
  assert.ok(reply.releaseArtifacts?.length);
  const artifact = reply.releaseArtifacts[0];
  assert.equal(artifact.delivery, 'not_sent');
  assert.match(artifact.body, /周四/);
  assert.doesNotMatch(artifact.body, /疲惫|有点累/);
  const draft = page.locator('.release-card').first();
  await draft.scrollIntoViewIfNeeded();
  await shot('01-real-draft');
  assert.equal((await draft.locator('.release-body').textContent()).trim(), artifact.body.trim());
  assert.equal(
    (await page.locator('.assistant-message .markdown').textContent()).includes(artifact.body),
    false,
  );
  await draft.getByRole('button', { name: '复制草稿', exact: true }).click();
  assert.equal(await app.evaluate(({ clipboard }) => clipboard.readText()), artifact.body);
  report.checks.push(
    'Real mixed request: exactly one native todo, independent not-sent artifact, owner answer rendered separately, exact draft copy',
  );
  await draft.getByRole('button', { name: '继续修改', exact: true }).click();
  assert.match(await page.getByRole('textbox', { name: '和在场说说' }).inputValue(), /草稿.*修改/);
  await page.emulateMedia({ colorScheme: 'dark' });
  await draft.scrollIntoViewIfNeeded();
  await shot('02-real-draft-dark');
  await page.getByRole('button', { name: /^我的安排/ }).click();
  await page.locator('.agenda-item').filter({ hasText: '核对分享提纲' }).waitFor();
  await shot('03-real-todo');
  await page.getByRole('button', { name: '回到对话', exact: true }).click();
  const saved = page.locator('.saved-action').filter({ hasText: '核对分享提纲' });
  await saved.getByRole('button', { name: /撤销本机登记/ }).click();
  await page.getByText('这项本机安排已移除。', { exact: true }).waitFor();
  assert.equal((await page.evaluate(() => window.zaichang.state())).agenda.length, 0);
  await saved.scrollIntoViewIfNeeded();
  await shot('04-real-undo');
  report.checks.push(
    'Revise draft preserves editing context; real native todo visible in schedule and removed by its original chat control',
  );
  const models = await app.evaluate(() => globalThis.__redesignModels);
  assert.ok(models.length > 0);
  assert.ok(models.every((model) => model === 'gpt-5.6-luna'));
  report.modelCallsObserved = models.length;
  report.totalCalls = models.length;
  report.accountCost = null;
  report.usageNote =
    'Account cost unknown; no DeepSeek prices applied. Model usage also remains in the isolated host usage journal.';
  report.answer = reply.responseText;
  report.artifact = { body: artifact.body, revision: artifact.revision, delivery: artifact.delivery };
  assert.deepEqual(report.errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.failure = String(error);
  await shot('failure').catch(() => {});
  throw error;
} finally {
  await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
  await app.evaluate(({ app }) => app.exit(0)).catch(() => {});
}

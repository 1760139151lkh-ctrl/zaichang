import test from 'node:test';
import assert from 'node:assert/strict';
import { z } from 'zod';
import { structuredResult } from '../../src/main/runtime/structured-result';
import type { DeepSeekClient, ToolSpec } from '../../src/main/provider';
import { ProviderError } from '../../src/main/provider';
import { reviewCompletion } from '../../src/main/runtime/completion-review';

test('a structured review length failure gets one clean attempt without dropping thinking or masking access errors', async () => {
  const schema = z.object({ allowed: z.boolean() }).strict();
  const tool: ToolSpec = { type: 'function', function: { name: 'verify', description: 'Contract fixture', parameters: { type: 'object' } } };
  const input = { schema, tool, messages: [{ role: 'user' as const, content: 'Same evidence' }], signal: new AbortController().signal, options: { thinking: 'enabled' as const, maxOutputTokens: 16384, phase: 'completion_review' as const }, failureCode: 'bad_result', failureMessage: 'Incomplete' };
  let calls = 0;
  const result = await structuredResult({ ...input, complete: async (messages, tools, _signal, _onText, options) => {
    calls++; assert.equal(messages.filter(m => m.role === 'user')[0].content, 'Same evidence');
    assert.ok(messages.every(m => m.role !== 'assistant')); assert.deepEqual(tools, [tool]); assert.deepEqual(options, input.options);
    if (calls === 1) throw new ProviderError('Incomplete synthetic output', false, 'output_length');
    return { content: '', tool_calls: [{ id: 'verified', type: 'function', function: { name: 'verify', arguments: '{"allowed":false}' } }] };
  } });
  assert.equal(calls, 2); assert.deepEqual(result, { allowed: false });
  let denied = 0;
  await assert.rejects(structuredResult({ ...input, complete: async () => { denied++; throw new ProviderError('Denied', false, 'authentication'); } }), /Denied/);
  assert.equal(denied, 1);
});

test('malformed structured output gets one bounded repair without treating an invalid approval as authority', async () => {
  const schema = z.object({ allowed: z.boolean() }).strict();
  const tool: ToolSpec = { type: 'function', function: { name: 'verify', description: 'Contract fixture', parameters: { type: 'object' } } };
  let calls = 0;
  const complete: DeepSeekClient['complete'] = async messages => {
    calls++; assert.ok(messages.some(message => message.content === '原始资料'));
    return { content: '', tool_calls: [{ id: 'result-' + calls, type: 'function', function: { name: 'verify', arguments: calls === 1 ? '{"allowed":true,}' : '{"allowed":false}' } }] };
  };
  const value = await structuredResult({ schema, tool, messages: [{ role: 'user', content: '原始资料' }], complete, signal: new AbortController().signal, options: { thinking: 'enabled' }, failureCode: 'bad_result', failureMessage: '结果不可靠' });
  assert.equal(calls, 2); assert.deepEqual(value, { allowed: false });
  let invalid = 0;
  await assert.rejects(structuredResult({ schema, tool, messages: [{ role: 'user', content: '原始资料' }], complete: async () => { invalid++; return { content: 'I approve', tool_calls: [] }; }, signal: new AbortController().signal, options: { thinking: 'enabled' }, failureCode: 'bad_result', failureMessage: '结果不可靠' }), /结果不可靠/);
  assert.equal(invalid, 2);
});

test('completion review classifies context restoration as an answer instead of demanding a business-action receipt', async () => {
  const original = '先恢复“周末拍摄”事项，再判断本周六14点能否开始。';
  const request = { id: 'restore-request', status: 'pending', data: { requestKind: 'action' } };
  let sawRule = false;
  const value = await reviewCompletion({ original, reply: '最新规则是15点以后可用，所以14点不能开始。', requests: [request], actions: [], observations: [] }, async (messages, tools) => {
    sawRule = messages.some(message => typeof message.content === 'string' && message.content.includes('上下文恢复') && message.content.includes('answer'));
    return { content: '', tool_calls: [{ id: 'review', type: 'function', function: { name: tools[0].function.name, arguments: JSON.stringify({ missing: [], contradictions: [], requests: [{ id: request.id, status: 'answered', actionIds: [], kind: 'answer', basisQuote: original }] }) } }] };
  }, new AbortController().signal);
  assert.equal(sawRule, true); assert.deepEqual(value.requests, [{ id: request.id, status: 'answered', actionIds: [], kind: 'answer', basisQuote: original }]);
});

test('an honestly explained unavailable external action is retained as blocked without triggering a repair loop', async () => {
  const original = '把刚才的邮件发给老师。';
  const value = await reviewCompletion({ original, reply: '发送通道未连接，邮件没有发出；刚才的草稿仍保留。', requests: [], actions: [], observations: [], hostState: { outboundDelivery: { status: 'not_connected', sent: false }, availableDrafts: [{ id: 'draft-1' }] } }, async (_messages, tools) => ({ content: '', tool_calls: [{ id: 'blocked-review', type: 'function', function: { name: tools[0].function.name, arguments: JSON.stringify({ missing: [{ quote: original, needed: '发送通道尚未连接。', disposition: 'blocked_explained' }], contradictions: [], requests: [] }) } }] }), new AbortController().signal);
  assert.deepEqual(value.missing, []); assert.deepEqual(value.blocked, [{ quote: original, reason: '发送通道尚未连接。' }]);
});

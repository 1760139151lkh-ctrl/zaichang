import { z } from 'zod';
import { HarnessError } from '../../shared/harness';
import type { DeepSeekClient, ToolSpec } from '../provider';
import { structuredResult } from './structured-result';

const reviewSchema = z.object({
  missing: z.array(z.object({ quote: z.string().max(3000), needed: z.string().max(1500), disposition: z.enum(['repairable', 'blocked_explained']).default('repairable').describe('本轮继续调用可补齐时为repairable；外部通道/权限不可用且答复已准确说明未完成时为blocked_explained。') }).strict()).max(12),
  blocked: z.array(z.object({ quote: z.string().max(3000), reason: z.string().max(1500) }).strict()).max(12).default([]),
  contradictions: z.array(z.string().max(1200)).max(12),
  requests: z.array(z.object({ id: z.string().max(160), status: z.enum(['answered', 'succeeded', 'unresolved']), actionIds: z.array(z.string().max(160)).max(8),
    kind: z.enum(['answer', 'action', 'artifact']).optional().describe('按用户实际所需结果核对；请求记录里的分类也是可纠正提案。说明是answer，成稿是artifact，改变业务状态才是action。'),
    basisQuote: z.string().max(3000).optional().describe('修正请求分类时逐字引用该请求原话，不能由成稿推定外发已经完成。'),
    artifactIds: z.array(z.string().max(160)).max(8).optional().describe('实际成稿ID；它们不是动作ID，不放入actionIds。'),
  }).strict()).max(20),
}).strict();
export type CompletionReview = z.infer<typeof reviewSchema>;

/** Long originals are reviewed in bounded overlapping segments so a request in
 * the middle cannot disappear behind repeated background text. The final tail
 * is included only to recognize later corrections that supersede an earlier
 * action; every reported quote must still come from the focused segment. */
export async function reviewLongInputCoverage(original: string, reply: string, complete: DeepSeekClient['complete'], signal: AbortSignal): Promise<CompletionReview> {
  const points = Array.from(original);
  if (points.length <= 8000) return { missing: [], blocked: [], contradictions: [], requests: [] };
  const segmentSchema = z.object({ missing: z.array(z.object({ quote: z.string().min(1).max(3000), needed: z.string().max(1500) }).strict()).max(8), contradictions: z.array(z.string().max(1200)).max(8) }).strict();
  const { $schema: _, ...parameters } = z.toJSONSchema(segmentSchema);
  const tool: ToolSpec = { type: 'function', function: { name: 'report_segment_gaps', description: '核对长原话当前片段中的明确要求是否在最终答复中得到保留。', parameters } };
  const tail = points.slice(-2500).join('');
  const missing: CompletionReview['missing'] = [], contradictions: string[] = [];
  const segments: { index: number; text: string }[] = [];
  for (let start = 0, index = 0; start < points.length; start += 4800, index++) segments.push({ index, text: points.slice(start, Math.min(points.length, start + 5000)).join('') });
  const controller = new AbortController(), reviewSignal = AbortSignal.any([signal, controller.signal]);
  let values: { segment: string; value: z.infer<typeof segmentSchema> }[];
  try {
    values = await Promise.all(segments.map(async ({ index, text: segment }) => ({ segment, value: await structuredResult({ schema: segmentSchema, tool, complete, signal: reviewSignal, failureCode: 'long_review_incomplete', failureMessage: '长内容的覆盖核查没有完成。', options: { thinking: 'enabled', maxOutputTokens: 8192, phase: 'completion_review' }, messages: [
      { role: 'system', content: '只核对focusedSegment中的明确用户要求、问题、禁止条件或要求带回的标识是否被finalReply实质满足。重复背景、叙述材料和没有要求回应的内容不算缺口。finalTail用于识别后来更正：末尾明确撤回或替换了片段中的早期动作时，不要求执行被撤回动作；但与末尾更正兼容的独立回答要求仍须保留。分段只防止要求从中间消失，不负责判定答复事实来自哪个片段：finalReply可能依据其他片段作答；不能因为某个答复事实未出现在当前focusedSegment就报矛盾，也不能因当前片段只有问题、答案在别的片段就说问题不可回答。只有focusedSegment本身明确与finalReply冲突时才报contradiction。不要要求额外解释或固定措辞。missing.quote必须逐字来自focusedSegment；没有缺口就返回空数组。调用指定工具。' },
      { role: 'user', content: JSON.stringify({ segmentIndex: index, focusedSegment: segment, finalTail: tail, finalReply: reply }) },
    ] }) })));
  } catch (error) {
    controller.abort(new DOMException('Sibling long-input review failed', 'AbortError'));
    throw error;
  }
  for (const { segment, value } of values) {
    // finalTail is shown to every reviewer only to understand supersession. A
    // model may mistakenly cite it as if it were in this focused segment; drop
    // that cross-segment proposal. The segment which actually contains the
    // quote reviews it independently. Global completion review owns factual
    // contradictions, so ungrounded segment contradiction prose is not used.
    for (const gap of value.missing.filter(gap => segment.includes(gap.quote)))
      if (!missing.some(item => item.quote === gap.quote && item.needed === gap.needed)) missing.push({ ...gap, disposition: 'repairable' });
  }
  return { missing, blocked: [], contradictions, requests: [] };
}

/** Targeted coverage/receipt review, not a style/personality rewriting agent. */
export async function reviewCompletion(input: {
  original: string; reply: string; requests: unknown[]; actions: unknown[]; observations: unknown[]; hostState?: unknown;
}, complete: DeepSeekClient['complete'], signal: AbortSignal): Promise<CompletionReview> {
  const { $schema: _, ...parameters } = z.toJSONSchema(reviewSchema);
  const tool: ToolSpec = { type: 'function', function: { name: 'report_completion_gaps', description: '只报告实质遗漏、事实/回执不一致，以及各明确请求的实际状态。', parameters } };
  const value = await structuredResult({ schema: reviewSchema, tool, complete, signal, failureCode: 'review_incomplete', failureMessage: '答复还没完成必要核查，已执行结果可在安排中查看。', options: { thinking: 'enabled', maxOutputTokens: 16384, phase: 'completion_review' }, messages: [
    { role: 'system', content: '请求类别补充规则：恢复、回到或接续已存事项，以便继续读取、比较、判断或回答，是answer型上下文恢复，不要求“恢复动作”的业务回执。只有真实改变目标、日程、提醒、外发或其他业务状态才是action。若已有请求记录误标为action，用当前原话basisQuote修正为answer；答复已完成恢复后的实质判断时标answered。缺口只在同一轮继续使用现有工具/资料能够补齐时标repairable。外部发送通道、账号、权限或服务未连接，且答复已明确说明没有执行、实际阻塞和已保留的可用结果时，标blocked_explained；它保留未完成状态，但不能触发重复尝试或要求模型制造成功回执。' },
    { role: 'system', content: '核对原话、实际工具观察、宿主动作回执与拟发答复。检查明确请求是否真正答到或办成、最新纠正是否改变判断、禁止动作是否仍未执行、失败/未知是否诚实、未来提醒是否有实际渠道。不能信答复自报成功，action请求必须对应参数相符的成功回执。manage_goal的confirmed_success回执若同时给出relatedAttention.coverage、remainingQueuedOrLeased=0和remainingActiveWatches=0，就证明该稳定goal_id关联的本地提醒/watch已停止；不能因它不是普通日程Action回执而否认。hostState中的目录是宿主提供的能力说明；搜索结果只覆盖匹配项，没出现在某页中不能证明能力不存在。区分能力存在、连接状态、本轮操作许可和动作已经发生；目录不证明动作完成。hostState.availableDrafts是宿主在当前权限内确认存在的既有成稿元数据；发送通道未连接时不强求再生成一份稿，但答复不得声称稿件不存在或要求用户重贴，应说明未发送并保留已有草稿。若hostState.requireReleaseArtifacts=true，用户实际要求的新对外稿件须有hostState.releaseArtifacts或prepare_release回执；宿主会把成稿原样附在主回复后，应连同成稿判断是否交付，不要求主Agent复写正文。主回复自行写出的对外文稿不能代替独立成稿。只请求私下讨论/说明或当前通道未连接的发送请求不强求新稿。若hostState.writingOnly=true，则本次本身是成稿核验，不需要另一份成稿回执。只报告实质问题，禁止扩张用户目标或按个人风格重写答复；不要将合理简短回答判为缺详细解释。missing.quote必须逐字来自original；没有实质缺口就返回空数组。requests只更新输入提供的请求ID，不自造ID。请求记录在本次核验完成前保持pending/resultRefs为空是预期事务顺序：若实际回执已证明完成，应在requests返回succeeded及actionIds，让宿主随后原子收尾；不得同时把“记录尚未同步”报作missing或contradiction，否则会形成无法完成的循环。原请求类别也是模型提案：私下说明是answer，交付草稿是artifact，实际登记/发送才是action；类别误判时给kind及该请求的逐字basisQuote。成稿引用artifactIds并标answered，业务操作引用actionIds及成功回执，不能用稿件冒充发送回执。调用指定工具提交。' },
    { role: 'user', content: JSON.stringify(input) },
  ] });
  for (const gap of value.missing.filter(gap => gap.disposition === 'blocked_explained')) value.blocked.push({ quote: gap.quote, reason: gap.needed });
  value.missing = value.missing.filter(gap => gap.disposition === 'repairable');
  const replyClaims = value.missing.filter(gap => !input.original.includes(gap.quote) && input.reply.includes(gap.quote));
  value.contradictions.push(...replyClaims.map(gap => gap.needed));
  value.missing = value.missing.filter(gap => !replyClaims.includes(gap));
  if (value.missing.some(gap => !input.original.includes(gap.quote)))
    throw new HarnessError('review_evidence', '核查未能对齐原话，不能据此扩大任务。');
  return value;
}

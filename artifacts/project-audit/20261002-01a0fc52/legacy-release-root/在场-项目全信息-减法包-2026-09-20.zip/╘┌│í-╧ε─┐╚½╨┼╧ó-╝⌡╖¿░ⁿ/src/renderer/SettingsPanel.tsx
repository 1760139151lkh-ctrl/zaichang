import { useEffect, useRef, useState, type MutableRefObject } from 'react';
import { ArrowLeft, Check, ChevronRight, Download, LoaderCircle, Pencil, Trash2, X } from 'lucide-react';
import { IconButton, Modal, PagePanel, Switch } from './ui';
import { MemoryPanelSimple, SourcePermissions } from './HarnessViews';
import type { Settings, State } from '../shared/types';

const api = window.zaichang;
export interface SettingsDraft {
  apiKey?: string;
  guidance?: string;
}
interface Props {
  embedded?: boolean;
  initialTab?: string;
  state: State;
  busy: boolean;
  onState: (s: State) => void;
  onClose: () => void;
  notify: (s: string) => void;
  onClear: () => void;
  draft: MutableRefObject<SettingsDraft>;
}
type Feedback = { action: string; text: string; error?: boolean } | null;
const date = (v: string) =>
  new Date(v).toLocaleString('zh-CN', {
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
const errorText = (e: unknown) =>
  String(e instanceof Error ? e.message : e)
    .replace(/^Error invoking remote method '[^']+': (Error: )?/, '')
    .replace(/^Error: /, '');

export function SettingsPanel({
  state,
  busy,
  onState,
  onClose,
  notify,
  onClear,
  draft,
  embedded,
  initialTab = '连接',
}: Props) {
  const [tab, setTab] = useState(initialTab);
  const tabs = embedded ? ['连接', '偏好'] : ['连接', '记忆', '偏好'];
  const Frame = embedded ? PagePanel : Modal;
  const [key, setKey] = useState(draft.current.apiKey || '');
  const [guidance, setGuidance] = useState(draft.current.guidance ?? state.settings.guidance);
  const [pending, setPending] = useState('');
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [memoryText, setMemoryText] = useState(''),
    [editId, setEditId] = useState<string>();
  const [sourceId, setSourceId] = useState(''),
    [clearConfirm, setClearConfirm] = useState(false);
  const testCancelled = useRef(false),
    pendingRef = useRef('');
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const sourceBackRef = useRef<HTMLButtonElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const disabled = busy || !!pending;
  const lunaSubstitute = state.modelRuntime?.temporaryTestSubstitute === true;
  useEffect(
    () => () => {
      if (pendingRef.current === 'test') void api.cancelConnection();
    },
    [],
  );
  useEffect(() => {
    if (tab !== '资料') return;
    const frame = requestAnimationFrame(() => sourceBackRef.current?.focus({ preventScroll: true }));
    return () => cancelAnimationFrame(frame);
  }, [tab]);
  function changeTab(value: string) {
    if (pendingRef.current === 'test') {
      testCancelled.current = true;
      void api.cancelConnection();
    }
    setTab(value);
    setFeedback(null);
    bodyRef.current?.scrollTo({ top: 0 });
  }
  async function perform(action: string, fn: () => Promise<void>) {
    if (pendingRef.current) return;
    pendingRef.current = action;
    setPending(action);
    setFeedback(null);
    try {
      await fn();
    } catch (e) {
      setFeedback({
        action,
        text:
          action === 'test' && testCancelled.current
            ? '已取消测试'
            : action === 'test' && errorText(e).includes('剩余事项')
              ? '连接暂时中断，请检查网络后重试'
              : errorText(e).replace(/[。.!！]+$/, ''),
        error: !(action === 'test' && testCancelled.current),
      });
    } finally {
      pendingRef.current = '';
      setPending('');
    }
  }
  function result(actions: string[]) {
    return feedback && actions.includes(feedback.action) ? (
      <div
        className={`inline-status ${feedback.error ? 'error' : ''}`}
        role={feedback.error ? 'alert' : 'status'}
      >
        {feedback.text}
      </div>
    ) : null;
  }
  async function update(action: string, settings: Partial<Settings>) {
    await perform(action, async () => {
      onState(await api.saveSettings(settings));
    });
  }
  const connector = state.campusConnector;
  const connectorReady =
    !!connector?.configured && !!connector.available && connector.authStatus === 'verified';
  const connectorStatus = !connector?.configured
    ? '尚未连接'
    : !connector.available
      ? '暂时无法连接'
      : connector.credentialsConfigured === false
        ? '需要登录'
        : connector.authStatus === 'verified'
          ? '已登录'
          : connector.authStatus === 'failed'
            ? '需要重试'
            : '待验证';
  return (
    <Frame
      title={
        tab === '资料' ? '用得上的校园资料。' : tab === '记忆' ? '一点点，了解你。' : '按你的方式，在场。'
      }
      onClose={onClose}
      className={`settings-panel ${initialTab === '记忆' ? 'memory-page' : ''}`}
    >
      {tab === '资料' ? (
        <button ref={sourceBackRef} className="source-back text-button" onClick={() => changeTab('连接')}>
          <ArrowLeft size={14} />
          返回连接
        </button>
      ) : initialTab !== '记忆' ? (
        <div className="panel-tabs" role="tablist" aria-label="在场设置">
          {tabs.map((t, i) => (
            <button
              key={t}
              id={`settings-tab-${i}`}
              ref={(el) => {
                tabRefs.current[i] = el;
              }}
              role="tab"
              aria-selected={tab === t}
              aria-controls={`settings-panel-${i}`}
              tabIndex={tab === t ? 0 : -1}
              onClick={() => changeTab(t)}
              onKeyDown={(e) => {
                let next: number | undefined;
                if (e.key === 'ArrowRight') next = (i + 1) % tabs.length;
                if (e.key === 'ArrowLeft') next = (i + tabs.length - 1) % tabs.length;
                if (e.key === 'Home') next = 0;
                if (e.key === 'End') next = tabs.length - 1;
                if (next !== undefined) {
                  e.preventDefault();
                  changeTab(tabs[next]);
                  tabRefs.current[next]?.focus();
                }
              }}
            >
              {t}
            </button>
          ))}
        </div>
      ) : null}
      <div
        className="panel-body"
        ref={bodyRef}
        role={tab === '资料' || initialTab === '记忆' ? 'region' : 'tabpanel'}
        id={tab === '资料' ? 'settings-source-panel' : `settings-panel-${tabs.indexOf(tab)}`}
        aria-label={tab === '资料' ? '资料来源设置' : initialTab === '记忆' ? '关于你的内容' : undefined}
        aria-labelledby={
          tab === '资料' || initialTab === '记忆' ? undefined : `settings-tab-${tabs.indexOf(tab)}`
        }
      >
        {busy && <p className="busy-note">连接设置需等本轮结束；停用记忆或资料权限会立即生效。</p>}
        {tab === '连接' && (
          <>
            <div className="section-heading">
              <div>
                <h3>{lunaSubstitute ? 'GPT‑5.6‑Luna' : 'DeepSeek'}</h3>
                <p>
                  {lunaSubstitute
                    ? '临时代测 · 生产默认仍为 DeepSeek'
                    : state.settings.mode === 'deepseek' && state.settings.hasKey
                      ? '连接配置已保存'
                      : '连接后即可开始对话'}
                </p>
              </div>
            </div>
            {lunaSubstitute ? (
              <div className="model-runtime-note">
                <p>当前使用临时代测模型。你的资料范围、保存选择与操作权限保持一致。</p>
                <div className="field-buttons">
                  {state.settings.mode === 'demo' && (
                    <button
                      className="primary-button"
                      disabled={disabled}
                      onClick={() => void update('enable-luna', { mode: 'deepseek' })}
                    >
                      启用 Luna 临时代测
                    </button>
                  )}
                  <button
                    className={state.settings.mode === 'demo' ? 'subtle-button' : 'primary-button'}
                    disabled={disabled}
                    onClick={() => {
                      testCancelled.current = false;
                      void perform('test', async () => {
                        const text = await api.testConnection({});
                        setFeedback({ action: 'test', text: text.replace(/[。.!！]+$/, '') });
                      });
                    }}
                  >
                    {pending === 'test' && <LoaderCircle size={14} className="spin" />}
                    {pending === 'test' ? '正在检查…' : '检查临时代测连接'}
                  </button>
                  {pending === 'test' && (
                    <button
                      className="text-button"
                      onClick={() => {
                        testCancelled.current = true;
                        void api.cancelConnection();
                      }}
                    >
                      取消检查
                    </button>
                  )}
                </div>
                {result(['test'])}
                <details className="connection-technical">
                  <summary>临时代测说明</summary>
                  <p>
                    通过 App Server 使用当前登录的 GPT‑5.6‑Luna。生产默认仍为
                    DeepSeek；两者的测试记录与账户用量分开保存。
                  </p>
                </details>
              </div>
            ) : (
              <>
                <label className="field-label">
                  DeepSeek 密钥
                  <input
                    type="password"
                    value={key}
                    autoComplete="off"
                    placeholder={state.settings.hasKey ? '已保存' : '输入密钥'}
                    onChange={(e) => {
                      setKey(e.target.value);
                      draft.current.apiKey = e.target.value;
                    }}
                    disabled={disabled}
                  />
                </label>
                <div className="field-buttons">
                  <button
                    className="primary-button"
                    disabled={disabled || !(key || state.settings.hasKey)}
                    onClick={() =>
                      void perform('save', async () => {
                        onState(
                          await api.saveSettings({ mode: 'deepseek', ...(key ? { apiKey: key } : {}) }),
                        );
                        setKey('');
                        draft.current.apiKey = '';
                        setFeedback({ action: 'save', text: '连接配置已保存' });
                      })
                    }
                  >
                    {pending === 'save' && <LoaderCircle size={14} className="spin" />}连接 DeepSeek
                  </button>
                </div>
                {result(['save', 'remove'])}
                <details className="advanced connection-advanced">
                  <summary>更多连接设置</summary>
                  <div className="advanced-body">
                    <div className="field-buttons">
                      <button
                        className="subtle-button"
                        disabled={disabled || !(key || state.settings.hasKey)}
                        onClick={() => {
                          testCancelled.current = false;
                          void perform('test', async () => {
                            const text = await api.testConnection({ ...(key ? { apiKey: key } : {}) });
                            setFeedback({
                              action: 'test',
                              text:
                                key || state.settings.mode !== 'deepseek'
                                  ? '连接可用'
                                  : `${text.replace(/[。.!！]+$/, '')}，连接可用`,
                            });
                          });
                        }}
                      >
                        {pending === 'test' && <LoaderCircle size={14} className="spin" />}
                        {pending === 'test' ? '正在测试…' : '测试连接'}
                      </button>
                      {pending === 'test' && (
                        <button
                          className="text-button"
                          onClick={() => {
                            testCancelled.current = true;
                            void api.cancelConnection();
                          }}
                        >
                          取消测试
                        </button>
                      )}
                      {state.settings.hasKey && (
                        <button
                          className="text-button"
                          disabled={disabled}
                          onClick={() =>
                            void perform('remove', async () => {
                              onState(await api.deleteKey());
                              setKey('');
                              draft.current.apiKey = '';
                              setFeedback({ action: 'remove', text: '连接密钥已移除' });
                            })
                          }
                        >
                          {pending === 'remove' && <LoaderCircle size={13} className="spin" />}移除密钥
                        </button>
                      )}
                    </div>
                    {result(['test'])}
                  </div>
                </details>
              </>
            )}
            {state.settings.mode === 'deepseek' && (
              <button
                className="text-button use-demo"
                disabled={disabled}
                onClick={() =>
                  void perform('demo', async () => {
                    onState(await api.saveSettings({ mode: 'demo' }));
                    setFeedback({ action: 'demo', text: '已切换到本地示例' });
                  })
                }
              >
                使用本地示例
              </button>
            )}
            {result(['demo'])}
            <button className="settings-navigation" onClick={() => changeTab('资料')}>
              <span>
                <strong>校园资料与天气</strong>
                <small>{connectorReady ? '浙大账号已登录' : '需要时登录'}</small>
              </span>
              <ChevronRight size={16} />
            </button>
          </>
        )}
        {tab === '资料' && (
          <>
            <SourcePermissions onState={onState} />
            <section className="campus-source-block">
              <div className="connector connector-primary">
                <div>
                  <div className="connector-title-line">
                    <strong>浙大校园资料</strong>
                    <span
                      className={`source-status ${connectorReady ? 'connected' : connector?.credentialsConfigured === false ? 'needs-login' : 'unavailable'}`}
                    >
                      {connectorStatus}
                    </span>
                  </div>
                  <p>
                    {connectorReady
                      ? '已用浙大账号连接，提问时会按需读取'
                      : connector?.credentialsConfigured
                        ? '登录信息已安全保存，再验证一次即可使用'
                        : '使用浙大统一身份认证，不需要导入资料文件'}
                  </p>
                </div>
                <button
                  className="subtle-button"
                  disabled={disabled}
                  onClick={() =>
                    void perform('account-connect', async () => {
                      onState(await api.connectCampusAccount());
                      setFeedback({
                        action: 'account-connect',
                        text: '浙大账号已登录，可以按需读取校园资料',
                      });
                    })
                  }
                >
                  {pending === 'account-connect' ? (
                    <LoaderCircle size={14} className="spin" />
                  ) : connectorReady ? (
                    '重新验证'
                  ) : connector?.credentialsConfigured ? (
                    '验证登录'
                  ) : (
                    '登录浙大'
                  )}
                </button>
              </div>
              {connector?.configured && (
                <details className="connector-more">
                  <summary>登录与来源详情</summary>
                  <div className="connector-actions" role="group" aria-label="校园资料连接设置">
                    <button
                      className="connector-action"
                      disabled={disabled}
                      onClick={() =>
                        void perform('credentials', async () => {
                          onState(await api.configureCampusCredentials());
                          setFeedback({ action: 'credentials', text: '登录信息已更新并通过验证' });
                        })
                      }
                    >
                      {connector.credentialsConfigured === false ? '输入登录信息' : '更新登录信息'}
                    </button>
                    {connector.credentialsConfigured && (
                      <button
                        className="connector-action connector-action-danger"
                        disabled={disabled}
                        onClick={() =>
                          void perform('credentials-forget', async () => {
                            onState(await api.forgetCampusCredentials());
                            setFeedback({
                              action: 'credentials-forget',
                              text: '本机保存的浙大登录信息已移除',
                            });
                          })
                        }
                      >
                        移除登录信息
                      </button>
                    )}
                    <button
                      className="connector-action connector-action-danger"
                      disabled={disabled}
                      onClick={() =>
                        void perform('connector-disconnect', async () => {
                          onState(await api.disconnectCampusConnector());
                          setFeedback({
                            action: 'connector-disconnect',
                            text: '校园资料已断开；登录信息仍安全保存在本机',
                          });
                        })
                      }
                    >
                      断开连接
                    </button>
                  </div>
                  <small>
                    登录信息由 Windows
                    当前用户加密保存；回答模型只会收到当前问题所需的资料，不会收到账号或密码。
                    {connector.lastVerifiedAt ? ` 上次验证：${date(connector.lastVerifiedAt)}。` : ''}
                  </small>
                </details>
              )}
            </section>
            {result([
              'account-connect',
              'connector-disconnect',
              'credentials',
              'credentials-forget',
              'import',
              'template',
              'disconnect',
            ])}
            {!connectorReady && (
              <section className="campus-import-block">
                <div className="connector">
                  <div>
                    <strong>备用：导入旧快照</strong>
                    <p>只用于迁移或离线查看，不会冒充浙大账号资料</p>
                  </div>
                  <button
                    className="subtle-button"
                    disabled={disabled}
                    onClick={() =>
                      void perform('import', async () => {
                        const next = await api.importCampus();
                        if (next) {
                          onState(next);
                          setFeedback({
                            action: 'import',
                            text: '离线快照已导入；登录浙大账号后才会用于账号查询',
                          });
                        }
                      })
                    }
                  >
                    {pending === 'import' ? (
                      <LoaderCircle size={14} className="spin" />
                    ) : state.campus ? (
                      '更新'
                    ) : (
                      '导入'
                    )}
                  </button>
                </div>
                {state.campus && (
                  <small className="campus-import-state">
                    离线快照 · 更新于 {date(state.campus.updatedAt)}
                  </small>
                )}
                <details className="campus-more">
                  <summary>更多离线资料操作</summary>
                  <div className="field-buttons">
                    <button
                      className="text-button"
                      disabled={disabled}
                      onClick={() =>
                        void perform('template', async () => {
                          if (await api.campusTemplate())
                            setFeedback({ action: 'template', text: '模板已保存' });
                        })
                      }
                    >
                      <Download size={14} />
                      下载导入模板
                    </button>
                    {state.campus && (
                      <button
                        className="text-button"
                        disabled={disabled}
                        onClick={() =>
                          void perform('disconnect', async () => {
                            onState(await api.disconnectCampus());
                            setFeedback({ action: 'disconnect', text: '离线快照已移除' });
                          })
                        }
                      >
                        移除快照
                      </button>
                    )}
                  </div>
                </details>
              </section>
            )}
            <Switch
              checked={state.settings.weatherEnabled}
              onChange={(v) => void update('weather', { weatherEnabled: v })}
              label="杭州天气"
              detail="使用杭州城市参考坐标，不代表你的精确位置"
              disabled={!!pending || (busy && !state.settings.weatherEnabled)}
            />
            {result(['weather'])}
          </>
        )}
        {tab === '记忆' && <MemoryPanelSimple state={state} onState={onState} busy={busy} />}
        {tab === '偏好' && (
          <>
            <p className="panel-intro">决定在场何时提醒你，以及怎样回应你的请求。</p>
            <section className="preference-section">
              <h3 className="section-title">提醒</h3>
              <Switch
                checked={state.settings.remindersEnabled}
                onChange={(v) => void update('reminders', { remindersEnabled: v })}
                label="提醒安排"
                detail="仅在应用运行时提醒已设定时间的安排"
                disabled={!!pending || (busy && !state.settings.remindersEnabled)}
              />
              {result(['reminders'])}
            </section>
            <section className="preference-section">
              <h3 className="section-title">回复方式</h3>
              <label className="field-label behavior-label">
                回复偏好
                <textarea
                  value={guidance}
                  onChange={(e) => {
                    setGuidance(e.target.value);
                    draft.current.guidance = e.target.value;
                  }}
                  rows={3}
                  maxLength={4000}
                  placeholder="例如：说话简短一些，保留晚上的休息时间"
                />
              </label>
              <div className="field-buttons">
                <button
                  className="primary-button"
                  disabled={disabled || guidance === state.settings.guidance}
                  onClick={() =>
                    void perform('guidance', async () => {
                      onState(await api.saveSettings({ guidance }));
                      setFeedback({ action: 'guidance', text: '回复偏好已保存' });
                    })
                  }
                >
                  {pending === 'guidance' && <LoaderCircle size={14} className="spin" />}保存偏好
                </button>
                {guidance !== state.settings.guidance && <small className="setting-hint">未保存的修改</small>}
              </div>
              {result(['guidance'])}
            </section>
            <details className="data-controls">
              <summary className="section-title">本地资料与导出</summary>
              <div className="data-controls-body">
                <p>对话保存在本机；连接模型时，会发送本轮允许使用的资料。数据库暂未整体加密。</p>
                <button
                  className="text-button"
                  disabled={disabled}
                  onClick={() =>
                    void perform('export', async () => {
                      if (await api.exportData()) setFeedback({ action: 'export', text: '资料已导出' });
                    })
                  }
                >
                  {pending === 'export' ? (
                    <LoaderCircle size={14} className="spin" />
                  ) : (
                    <Download size={15} />
                  )}
                  导出我的资料
                </button>
                {result(['export'])}
                {clearConfirm ? (
                  <div className="clear-confirm">
                    <p>确定清空本机资料？这会删除对话、记忆、安排、校园资料和连接密钥，且无法撤销</p>
                    <button
                      className="danger-button"
                      disabled={disabled}
                      onClick={() =>
                        void perform('clear', async () => {
                          onState(await api.clearData());
                          draft.current = {};
                          onClear();
                          notify('本地资料已清空');
                        })
                      }
                    >
                      确认清空
                    </button>
                    <button className="text-button" onClick={() => setClearConfirm(false)}>
                      取消
                    </button>
                  </div>
                ) : (
                  <button
                    className="text-button danger-text"
                    disabled={disabled}
                    onClick={() => setClearConfirm(true)}
                  >
                    <Trash2 size={14} />
                    清空本地资料
                  </button>
                )}
                {result(['clear'])}
              </div>
            </details>
          </>
        )}
      </div>
    </Frame>
  );
}

// Quiet geography; the active route is the visual priority. Canvas stays transparent.
export const darkMapPalette = {
  water: '#263b3c',
  land: '#242d25',
  building: '#3a4536',
  outline: '#68735f',
  road: '#8d9981',
  minorRoad: '#56634f',
  text: '#eceee0',
  secondaryText: '#c0c9b4',
  halo: '#252e25',
  hover: '#94a77d',
  selected: '#cddcaf',
  route: '#e0efc1',
  location: '#e0efc1',
  barrier: '#66715c',
};
export const lightMapPalette = {
  water: '#dce8e4',
  land: '#edf0e4',
  building: '#d8ddce',
  outline: '#99a28b',
  road: '#858f79',
  minorRoad: '#bcc3ad',
  text: '#2e392d',
  secondaryText: '#56634f',
  halo: '#f8f9f0',
  hover: '#7b9470',
  selected: '#4b6840',
  route: '#264c35',
  location: '#264c35',
  barrier: '#9da58d',
};
export type MapPalette = typeof darkMapPalette;

import { useState } from 'react';
import {
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronRight,
  Circle,
  History,
  MapPinned,
  MessageSquare,
  Plus,
  Search,
  SlidersHorizontal,
  Sprout,
  X,
} from 'lucide-react';
import type { Action, State } from '../shared/types';
import { IconButton, PagePanel, Portal } from './ui';
import { WorkAndReceipts } from './HarnessViews';

export type WorkspaceView = 'chat' | 'agenda' | 'memory' | 'settings';

export function Sidebar({
  state,
  view,
  sessionId,
  busy,
  onView,
  onNew,
  onHistory,
  onConversation,
  onMap,
}: {
  state: State | null;
  view: WorkspaceView;
  sessionId?: string;
  busy: boolean;
  onView: (view: WorkspaceView) => void;
  onNew: () => void;
  onHistory: () => void;
  onConversation: (id: string) => void;
  onMap: () => void;
}) {
  const pending = state?.agenda.filter((a) => !a.done).length || 0;
  const model = !state
    ? '正在打开…'
    : state.settings.mode === 'demo'
      ? '本地示例'
      : state.modelRuntime?.temporaryTestSubstitute
        ? 'Luna · 临时代测'
        : state.settings.hasKey
          ? 'DeepSeek · 已配置'
          : 'DeepSeek · 未连接';
  return (
    <aside className="app-sidebar" aria-label="在场导航">
      <button className="brand" onClick={() => onView('chat')} aria-label="在场，回到对话">
        <Portal size={28} />
        <span>在场</span>
      </button>
      <button className="new-conversation" onClick={onNew} disabled={busy} aria-label="新的对话">
        <Plus size={18} />
        <span>说一件新事</span>
        <kbd>Ctrl N</kbd>
      </button>
      <nav className="workspace-navigation" aria-label="主要页面">
        <button
          className={view === 'chat' ? 'selected' : ''}
          aria-current={view === 'chat' ? 'page' : undefined}
          onClick={() => onView('chat')}
          title="对话"
        >
          <MessageSquare size={19} />
          <span>对话</span>
        </button>
        <button
          className={view === 'agenda' ? 'selected' : ''}
          aria-current={view === 'agenda' ? 'page' : undefined}
          onClick={() => onView('agenda')}
          title="我的安排"
          aria-label={pending ? `我的安排，${pending} 项待完成` : '我的安排'}
        >
          <CalendarDays size={19} />
          <span>安排</span>
          {pending > 0 && <small>{pending}</small>}
        </button>
        <button onClick={onMap} title="校园地图" aria-label="打开校园地图">
          <MapPinned size={19} />
          <span>校园</span>
        </button>
        <button
          className={view === 'memory' ? 'selected' : ''}
          aria-current={view === 'memory' ? 'page' : undefined}
          onClick={() => onView('memory')}
          title="关于你"
        >
          <Sprout size={19} />
          <span>关于你</span>
        </button>
      </nav>
      <div className="sidebar-history">
        <div className="sidebar-section-title">
          <span>最近说过</span>
          <IconButton label="历史对话" onClick={onHistory}>
            <Search size={15} />
          </IconButton>
        </div>
        {state?.conversations.slice(0, 6).map((c) => (
          <button
            key={c.id}
            className={`recent-conversation ${sessionId === c.id && view === 'chat' ? 'current' : ''}`}
            onClick={() => onConversation(c.id)}
            disabled={busy}
            title={c.title}
          >
            <span>{c.title}</span>
          </button>
        ))}
        {!state?.conversations.length && <p className="sidebar-empty">说过的话，可以从这里接着聊。</p>}
        {!!state?.conversations.length && (
          <button className="history-all" onClick={onHistory}>
            全部对话
            <ChevronRight size={12} />
          </button>
        )}
      </div>
      <div className="sidebar-bottom">
        <button className="compact-history" onClick={onHistory} aria-label="历史对话" title="历史对话">
          <History size={19} />
        </button>
        <button
          className={`settings-link ${view === 'settings' ? 'selected' : ''}`}
          onClick={() => onView('settings')}
          title="连接与偏好"
          aria-label="连接与偏好"
        >
          <SlidersHorizontal size={18} />
          <span>连接与偏好</span>
        </button>
        <div className="runtime-identity" title={model}>
          <i aria-hidden="true" />
          <span>{model}</span>
        </div>
      </div>
    </aside>
  );
}

function dayKey(value?: string) {
  if (!value) return '没有指定时间';
  const d = new Date(value);
  return Number.isNaN(d.getTime())
    ? '时间需要核对'
    : d.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });
}

export function AgendaView({
  state,
  onAction,
  onResume,
  onChanged,
  onClose,
  onCompose,
}: {
  state: State;
  onAction: (item: Action, action: 'done' | 'delete') => void;
  onResume: (id: string) => void;
  onChanged: () => void;
  onClose: () => void;
  onCompose: () => void;
}) {
  const [query, setQuery] = useState('');
  const [attention, setAttention] = useState(0);
  const pending = state.agenda.filter((a) => !a.done && `${a.title} ${a.detail}`.includes(query));
  const completed = state.agenda.filter((a) => a.done && `${a.title} ${a.detail}`.includes(query));
  const grouped = new Map<string, Action[]>();
  for (const a of [...pending].sort((a, b) =>
    (a.allDayDate || a.startsAt || '9999').localeCompare(b.allDayDate || b.startsAt || '9999'),
  )) {
    const key = dayKey(a.allDayDate ? `${a.allDayDate}T12:00:00` : a.startsAt);
    grouped.set(key, [...(grouped.get(key) || []), a]);
  }
  function row(a: Action) {
    return (
      <article className={`agenda-item ${a.done ? 'done' : ''}`} key={a.id}>
        <IconButton
          label={a.done ? '已标记完成（仅本机）' : `标记完成（仅本机）：${a.title}`}
          disabled={a.done}
          onClick={() => onAction(a, 'done')}
        >
          {a.done ? <Check size={18} /> : <Circle size={20} />}
        </IconButton>
        <div className="agenda-item-content">
          <strong>{a.title}</strong>
          {a.detail && <p>{a.detail}</p>}
          <small>
            {a.allDayDate
              ? '全天'
              : a.startsAt
                ? new Date(a.startsAt).toLocaleTimeString('zh-CN', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: false,
                  })
                : '时间待定'}
            {a.durationMinutes ? ` · ${a.durationMinutes} 分钟` : ''}
            {a.recurrence ? ' · 重复安排' : ''}
            {a.demo ? ' · 示例建议' : ''}
            {a.coverage === 'conditional' ? ' · 条件待核对' : ''}
          </small>
        </div>
        <IconButton label={`移除：${a.title}`} onClick={() => onAction(a, 'delete')}>
          <X size={16} />
        </IconButton>
      </article>
    );
  }
  return (
    <PagePanel title="让事情有个着落。" eyebrow="我的安排" onClose={onClose} className="agenda-page">
      <div className="page-lede">
        <p>已经确认的本地安排。还没决定的建议，留在谈话里。</p>
        <button className="subtle-button" onClick={onCompose}>
          记一件事
          <ArrowUpRight size={15} />
        </button>
      </div>
      {state.agenda.length > 6 && (
        <div className="search-box">
          <Search size={17} />
          <input
            aria-label="搜索安排"
            placeholder="找一件事"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      )}
      {!!pending.length && (
        <div className="agenda-list">
          {[...grouped].map(([day, items]) => (
            <section className="agenda-day" key={day}>
              <h2>{day}</h2>
              {items.map(row)}
            </section>
          ))}
        </div>
      )}
      {!pending.length && (
        <div className="page-empty">
          <CalendarDays size={28} />
          <h2>
            {query
              ? '没有找到这件事。'
              : completed.length
                ? '眼前的安排，都完成了。'
                : '留一点空白，也很好。'}
          </h2>
          <p>{query ? '换一个词试试。' : '有想做的事时，告诉在场，再一起决定时间。'}</p>
          {!query && (
            <button className="text-button" onClick={onCompose}>
              说一件想做的事
              <ArrowUpRight size={14} />
            </button>
          )}
        </div>
      )}
      {!!completed.length && (
        <details className="completed-agenda">
          <summary>
            已经完成 <span>{completed.length}</span>
          </summary>
          {completed.map(row)}
        </details>
      )}
      <details className={`agenda-followup ${attention ? 'needs-attention' : ''}`}>
        <summary>
          {attention ? `${attention} 件事的结果需要核查` : '进行中的事与操作记录'}
          <ChevronRight size={15} />
        </summary>
        <WorkAndReceipts onResume={onResume} onChanged={onChanged} onAttention={setAttention} currentActionIds={state.agenda.map(a => a.effectActionId || a.id)} />
      </details>
      <p className="page-footnote">
        {state.settings.remindersEnabled
          ? '在场运行时，会提醒已设定时间的安排。'
          : '提醒未开启。需要时，可以在偏好中打开。'}
      </p>
    </PagePanel>
  );
}

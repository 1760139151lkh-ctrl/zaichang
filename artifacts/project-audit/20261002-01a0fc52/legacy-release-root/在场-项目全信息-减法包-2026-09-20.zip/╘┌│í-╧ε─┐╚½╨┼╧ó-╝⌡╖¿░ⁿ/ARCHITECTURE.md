# 产品与架构

## 产品主张

帮助学生在课程、个人计划和日常心绪交织时，从一句未整理的原话走到一个可信、可以改变的下一步。系统承担整理和核对成本，用户保留决定、更正、撤销和退出的权利。

## 核心原则

- 用户决定权和明确授权高于自动化数量。
- 只读取与当前任务相称、属于正确用户和用途的资料。
- 事实、来源、新鲜度、建议、执行和未知结果保持真实。
- 对人的理解允许条件、例外、变化、纠正和有边界的遗忘。
- 简洁用于降低负担，同时保留来源、失败、撤销和恢复。

## 运行链

```text
Electron 原输入/附件
  → 宿主生成身份、会话、受众、保留和传输边界
  → 本机禁传/凭据检查与窄控制提案
  → 获准原文、证据、请求项同事务保存
  → ContextCompiler 按需恢复当前事项、相关候选和依赖
  → 固定 Hermes AIAgent 调用模型与受控工具
  → 宿主执行读写、事务、回执、取消与版本复核
  → 必要的完成检查与独立稿件投影
  → 回复、结构化对象和真实状态分别呈现
```

## 真相所有者

| 职责 | 主要实现 |
| --- | --- |
| 对话、页面、草稿、图片、恢复 | `src/renderer/` + preload IPC |
| 可信身份、范围、保留、删除屏障 | `src/main/runtime/policy.ts`、`privacy-control.ts`、repository |
| 用户理解与条件记忆 | memory service/model、证据与原文索引 |
| 共同理解、请求项、目标和设想 | collaboration/work services |
| 上下文编译和长输入 | context/coordinator/completion review |
| 工具和能力目录 | capability broker、builtin provider、tool registry |
| 本地日历、动作、提醒和回执 | actions runtime、local calendar、reminder runtime |
| 校园域、地图、天气、位置 | domain store、ZJU adapter、map service/location provider |
| 模型传输与用量 | DeepSeek provider、Luna adapter、model selection/usage |
| 唯一生产模型工具循环 | 固定 Hermes sidecar；锁与局部补丁在 `vendor/hermes/` |

## 重要边界

模型不能指定用户身份、绕过权限或把文字建议变成外部执行。正文访问在 SQL 前按主体、世界、来源、用途、受众、期限和版本过滤。图片只进入当前图文轮，不进入文字记忆提取。外部超时保留 unknown，先核查后重试。删除立即停止本机使用并清理派生链，但不声称撤回已经外发的副本。

当前生产默认 DeepSeek；Luna 是宿主模型出口的临时替换，不另建决策循环。Hermes 上游由 `runtime/hermes/lock.json` 固定到提交 `d595e636c83aa0b9606d4e914e1140ae9c796897`，本地只保留五处窄适配补丁。

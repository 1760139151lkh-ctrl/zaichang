# 在场 · 项目全信息减法包

这是面向接手开发、审查架构和理解产品的最小完整包。它保留每一种事实的唯一主要载体，同时删除依赖缓存、运行数据库、重复评测、中间截图、历史提示词、Agent 指令和可重新生成的二进制。

建议阅读顺序：

1. [CURRENT-STATE.md](CURRENT-STATE.md)：产品是什么、当前实现处于什么状态。
2. [CAPABILITY-STATUS.md](CAPABILITY-STATUS.md)：逐项区分已接入、部分接入、仅有契约和未接入。
3. [ARCHITECTURE.md](ARCHITECTURE.md)：运行链、职责与真实边界。
4. [DESIGN-SYSTEM.md](DESIGN-SYSTEM.md)：Astra 前端的产品性格、布局和交互规则。
5. [EVIDENCE.md](EVIDENCE.md)：当前证据、分母与不能夸大的结论。
6. [PACKAGE-SCOPE.md](PACKAGE-SCOPE.md)：为什么某些目录没有进入包。
7. `requirements/`：当前理解与行动架构的设计、验收和研究依据；`test-fixtures/` 单列仍被测试读取的历史场景。实现指令本身已去除。
8. `src/`、`scripts/`、`tests/`：第一方产品源码、可复现测试和运行脚本；只服务原仓库索引、快照或本压缩包生成的维护脚本已去除。

常用命令在 [RUNBOOK.md](RUNBOOK.md)。全部文件的来源、大小和 SHA-256 在 `MANIFEST.json`；`MANIFEST.sha256` 校验 manifest 本身。

这个包不包含密钥、Cookie、用户数据库、真实学生资料或系统登录信息。它也不把“存在接口”写成“真实服务已连接”。

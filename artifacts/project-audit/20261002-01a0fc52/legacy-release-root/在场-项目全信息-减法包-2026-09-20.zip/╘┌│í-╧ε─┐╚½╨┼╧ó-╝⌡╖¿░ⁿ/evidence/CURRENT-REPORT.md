# 理解与行动：当前验证记录

Astra前端阶段：implemented_verified。两个设计技能已在后端门槛后完整使用；开发与真实模型身份分别记录。DeepSeek此前402保留为历史事实，Luna只是临时代测。

本页只汇总已有证据，不把不同代码版本的通过记录拼成最新版本全量通过。完整数据见 [CURRENT-REPORT.json](CURRENT-REPORT.json)。

## Luna 临时代测

按用户要求，现在通过 App Server 使用 GPT‑5.6‑Luna，原 Hermes、上下文、工具和业务链保留。生产默认仍是 DeepSeek。替换契约与差异见 [LUNA-TEST-SUBSTITUTE.md](../../LUNA-TEST-SUBSTITUTE.md)。下方 DeepSeek 历史批次不是 Luna 验证结果。

luna-first-harness：2/2 已捕获故事通过，共25次调用。失败和修复批次分别保留。
luna-harness-parity：2/3 已捕获故事通过，共21次调用。失败和修复批次分别保留。
luna-delegation-repair：1/3 已捕获故事通过，共29次调用。失败和修复批次分别保留。
luna-delegation-observations：3/3 已捕获故事通过，共41次调用。失败和修复批次分别保留。
luna-repaired-failures-three-repeat：30/33 已捕获故事通过，共224次调用。失败和修复批次分别保留。
luna-s35-cancel-final：3/3 已捕获故事通过，共23次调用。失败和修复批次分别保留。
luna-s12-final：3/3 已捕获故事通过，共21次调用。失败和修复批次分别保留。
luna-a01-context-restore-final：3/3 已捕获故事通过，共18次调用。失败和修复批次分别保留。
luna-a04-request-finalization：3/3 已捕获故事通过，共26次调用。失败和修复批次分别保留。
luna-sixty-stable-final：65/66 已捕获故事通过，共391次调用。失败和修复批次分别保留。
luna-sixty-definitive-final：179/180 已捕获故事通过，共1097次调用。失败和修复批次分别保留。

原生函数/真实结果续接/视觉探针：passed；真实Electron图文：gpt-5.6-luna，textParts=1、imageParts=1。新的连接页和侧栏明确标注Luna临时代测。

最终Luna180条：原始直接通过179；1条仅评判器超时的原轨迹复判通过，调整审计=180/180。原始失败文件保留，不混改历史分数。

## 离线后端

后端机制 260/260 通过（含92个迁移后的宿主场景）。核心26/26、地图核心22/22、构建与新评估源码类型检查通过。Astra工程版与仓库外成品验收见FRONTEND-REPORT.json；各类证据不互相替代。

## 真实模型开发验证

最新后端候选的三次重复批次只取得 2/180 条记录后遇到官方402，状态为externally_blocked；未把未开始或未判分条目算成通过。

冻结的60故事×3批次已取得 **180/180** 条记录，171 条通过；缺失记录0条、未完整判分1条。具体失败与分类阈值见JSON中的repeatedStoryRun.audit。此批次有固定编译指纹，修复后原例/变体单列，不覆盖这里的失败。

修复批次完整性：long-tail-cancellation：全部记录已收齐，可逐条读取0条；draft-mode-live：全部记录已收齐，可逐条读取6条；missing-draft-variants：全部记录已收齐，可逐条读取6条；source-ambiguity-review-live：全部记录已收齐，可逐条读取3条；output-recovery-original-live：全部记录已收齐，可逐条读取6条；output-source-repair-variants：全部记录已收齐，可逐条读取18条；conditional-memory-repair-live：全部记录已收齐，可逐条读取3条；conditional-memory-variants：全部记录已收齐，可逐条读取6条；capability-coverage-live：全部记录已收齐，可逐条读取3条；capability-coverage-variants：全部记录已收齐，可逐条读取6条；current-audience-live：全部记录已收齐，可逐条读取9条；mixed-release-diagnostic：全部记录已收齐，可逐条读取2条；bounded-closure-guidance-live：全部记录已收齐，可逐条读取6条；release-owner-mixed-live：全部记录已收齐，可逐条读取6条；release-owner-original-r2：全部记录已收齐，可逐条读取9条；release-owner-new-expressions：全部记录已收齐，可逐条读取8条；release-owner-observation-live：全部记录已收齐，可逐条读取6条；retention-effect-diagnostic：全部记录已收齐，可逐条读取2条；retention-safe-answer-live：全部记录已收齐，可逐条读取3条；retention-effects-original-live：全部记录已收齐，可逐条读取6条；retention-effects-variants-live：全部记录已收齐，可逐条读取7条；luna-repaired-failures-three-repeat：全部记录已收齐，可逐条读取33条；luna-s35-cancel-final：全部记录已收齐，可逐条读取3条；luna-s12-final：全部记录已收齐，可逐条读取3条；luna-delegation-observations：全部记录已收齐，可逐条读取3条；luna-a01-context-restore-final：全部记录已收齐，可逐条读取3条；luna-a04-request-finalization：全部记录已收齐，可逐条读取3条。长文本专用夹具的7项记录保留在自己的报告中，不冒充7个独立故事。

40公开故事＋20新增故事的首轮记录为 54/60 通过。后续已逐项修复并留下复测记录；这是DeepSeek历史开发记录。最终Luna批次另见原始/复判审计；新增故事由开发者可见，不能称为盲测。

首个完整回应的观测 p50 为 23.68 秒、p95 为 62.57 秒；不把后台结束时间冒充首答。

其中完整判分 59/60，未判分 1 项；已判分记录的描述性Wilson区间为 81.6%–96.3%。已有三次记录的故事族为 0/60，三次全部通过为 0。开发集不是随机用户样本，此区间不能证明真实总体正确率。

## 同条件基线

| 组 | 环境终态检查 | complete 调用记录 |
| --- | --- | --- |
| B0 | 6/6 | 24 |
| B1 | 4/6 | 10 |
| B2 | 6/6 | 20 |
| B3 | 6/6 | 25 |

B0为诊断工具循环，B1为固定快照中的真实旧代码，B2为轻配置Hermes，B3为当前集成。六个任务使用相同合法业务资料与边界；实际工具可见性和辅助步骤如实记录。B1仅在测试中运行，并显式统一thinking/output额度。这里只做环境检查和保留答复，不冒充人评。

## 四项机制消融

| 机制 | 启用后通过 | 关闭后通过 | 平均调用：启用 / 关闭 |
| --- | --- | --- | --- |
| prefetch | 3/3 | 0/3 | 5.67 / 11.67 |
| currentMatter | 3/3 | 3/3 | 4.00 / 5.33 |
| repairRejudge | 3/3 | 0/3 | 6.00 / 5.67 |
| closure | 3/3 | 0/3 | 9.33 / 3.00 |

A03在读取后修改真实隔离状态；A04在任何副作用发生前注入伪完成输出。它们衡量机制抵抗受控故障的作用，不能充当天然模型成功率。注入记录、机制触发次数和所有失败均保留。

预取在这个小样本中减少了一些调用，尚不能证明普遍质量收益。当前事项提示没有在此样本中证明优势，不能因为架构中有这个对象就宣称它更好。修复重判和收尾检查的失效对照出现了可观察的错误；样本仍只有每组3次。

## 费用与未完成项

本次接续已记录 8218 次complete尝试，其中 8126 次取得usage。其中仅DeepSeek已有usage的调用按历史价格快照估算为 **$4.52–$9.04**；92 次缺失usage，不包含在该金额中。Luna账户费用未知，不套用DeepSeek价格。这不是账户账单，也不含原任务更早的消耗。

另有36次已报告但未捕获逐调用数据；539条旧记录没有全局调用标识，复制证据可能无法完全去重。分阶段成本与覆盖限制见MODEL-USAGE.json，不能把缺数据当零费用。

- 按用户要求继续Luna临时代测；DeepSeek余额恢复后可用原Key复验其生产路径，不要求新Key。
- 原例修复、变体和冻结三次重复分别核验；是否结束以各批次终态报告为准。
- 两个设计技能已使用，Electron全流程与最终成品证据见DESIGN及FRONTEND-REPORT.json。
- 独立人评和真正不可见的留出未完成；不得把开发验证写成这些证据。

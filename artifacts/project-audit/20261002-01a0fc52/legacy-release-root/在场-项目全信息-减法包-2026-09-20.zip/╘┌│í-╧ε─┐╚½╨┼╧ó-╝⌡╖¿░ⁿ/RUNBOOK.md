# 构建与验证

要求：Windows、Node.js 24+、Git 和 uv。先解压到普通目录。

```powershell
npm ci
npm run setup:hermes
npm run build
npm test
npm run check:harness
npm run test:map:core
npm run test:harness:trajectories
npm run test:desktop
npm run test:connection
```

开发启动：

```powershell
npm run dev                 # 本地示例或界面开发
npm run dev:deepseek        # 使用仓库外 DPAPI 项目凭据
npm run dev:luna:test       # 用户授权的 Luna 临时代测
```

真实模型验证必须使用项目已有包装器，不能把密钥放进源码、命令输出或包内配置。DeepSeek 固定模型 ID 为 `deepseek-flash`。Luna 只作临时代测，报告必须单列提供方和模型。

Hermes 用 `scripts/setup-hermes.mjs` 按 `runtime/hermes/lock.json` 获取固定上游，并根据 `vendor/hermes/install-record.json` 核对五个本地补丁。`vendor/hermes/local-changes.patch` 和 `patched-files/` 供离线审查；它们不是第二套 Agent 循环。运行 `npm run package` 前须先执行 `npm run setup:hermes`；打包脚本会重新生成带本机暂存路径的 `build/hermes-builder.json`。

完整场景和真实模型评估会产生大量隔离测试数据。日常接手先运行小型 build/core/map/UI 门槛；需要复现 94 条历史 Harness 场景时使用 `npm run test:harness:scenarios`，其输入在 `requirements/test-fixtures/`。最终 180 条与消融的代表报告已经收录，原始批次未重复打包；重跑前先阅读 `tests/harness/` 和 `scripts/run-understanding-*.mjs`。

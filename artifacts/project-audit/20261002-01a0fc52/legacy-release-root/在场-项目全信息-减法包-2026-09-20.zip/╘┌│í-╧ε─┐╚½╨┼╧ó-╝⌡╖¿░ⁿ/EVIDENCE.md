# 当前证据

本包只保留能够代表当前结论的最终报告和少量互不重复的画面。原始失败仍存在于工作仓库，但数千份中间轨迹、重复截图和旧批次不进入本包。

| 结论 | 代表证据 |
| --- | --- |
| 后端确定性机制 | `evidence/backend/tests.json`：24 套、260/260 |
| 最终 Luna 开发故事 | `evidence/model/final-audit.json`：180 条；179 直接通过，1 条纯评判器超时固定原轨迹复判 |
| 汇总、消融、B0–B3、历史失败和限制 | `evidence/CURRENT-REPORT.json` / `.md` |
| 模型使用量与费用边界 | `evidence/MODEL-USAGE.json`；Luna 费用未知，不套 DeepSeek 价格 |
| 核心宿主回归 | `evidence/core/report.json`：26/26 |
| 前端总览 | `evidence/frontend/FRONTEND-REPORT.json` |
| 真实 Luna 混合登记和独立稿件 | `evidence/frontend/live-action-and-draft.json` |
| 图文全链 | `evidence/frontend/live-multimodal.json`：gpt-5.6-luna，1 text + 1 image |
| 错误、停止、原范围重试和仅本机 | `evidence/frontend/recovery.json` |
| 条件理解、来源、未知和设想采纳 | `evidence/frontend/harness-ui.json` |
| 地图真实 Electron | `evidence/map/report.json`；核心另有 22/22 |
| unpacked / portable 成品 | `evidence/package/unpacked.json`、`portable.json` |
| Luna 原生工具与图像探针 | `evidence/model/transport.json` |
| 长输入与独立委派 | `evidence/model/long-input.json`、`delegation.json` |

## 证据边界

- 开发故事由开发者可见且多次运行相关，不是真正隐藏留出或随机用户样本。
- 模型复判不是独立人类评审；产品没有学生满意度或长期使用研究。
- 合成连接、定位和外部 sink 只能证明状态机与故障路径。
- Luna 是临时代测，不能证明生产 DeepSeek 同样通过。
- 截图证明可见画面；自动操作证明特定任务；二者都不等于完整无障碍合规。

`evidence/screens/` 只保留入口、独立稿件、纠正来源、故障恢复、长阅读、地图路线/未知入口、图文回答和便携成品这几种不同状态。

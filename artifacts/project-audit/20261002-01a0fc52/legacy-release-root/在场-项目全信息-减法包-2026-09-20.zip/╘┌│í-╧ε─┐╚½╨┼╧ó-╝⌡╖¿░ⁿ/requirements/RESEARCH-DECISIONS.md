# 研究依据与决策记录

核查日期：2026-09-12。以下为本轮实际读取的材料和一手公开来源。阅读论文采用摘要/HTML，不声称重现实验、读取未公开内部实现，亦未运行真实应用或云模型。下列链接以代码形式保留，便于查验。

## A. 上传材料的身份与使用方式

### U1｜《在场的记忆讨论(2).txt》与最新研究 ZIP

本轮输入的 ZIP 是《在场-Harness-审查研究与语义重构包(1).zip》，包括00–08的设计文档、旧源码节选、旧函数探针与旧结果，不是完整当前应用仓库。

讨论约 L2273–2281 已明确选择 Hermes，L2295–2317 是上一轮函数隔离复现及其限制，L2385–2395 明确未确认年龄词专用源码分支。不得把这些历史报告写成本轮实测，也不得夸大为全应用实际行为。

讨论 L2621–2751 已给出主模型、控制解析、工具发现、子代理、开放记忆、行动与表达的方案；L2755–2888 已包含反审查和实际改进闭环。新设计是在此基础上细化，不把这些机制冒称首次发现。

尤其 ZIP `04-最终架构与工程决策.md`：F 段已有共同语境、助手承诺与事项恢复；J 段已有误解修复、每轮可观察请求覆盖和按风险的独立核验。本轮对这些内容的贡献是展开运行语义、失效依赖和判分方法，而不是填补一个不存在的空白。

### U2｜前两轮记忆与情境设计

讨论 L51–68 区分六种数据对象；L175–341 给出候选提取、证据核验和事务提交；L394–553 给出任务驱动取证与原文兜底；L603–724 给出前后台一致性、删除与范围。

讨论 L1346–1429 区分话语、主体和现实/假设；L1519–1564 给出 ContextContract 与使用/披露区别；L1626–1718 讨论决定理由、跨模态指代、即时纠正与版本；L1876–1947 要求状态测试和负向个性化测试。

200个输入是设计压力测试的素材，不是200条生产路由，也不是目前已经有标准答案的隐藏基准。

## B. 一手公开资料

### R1｜Hermes Python Library

`https://hermes-agent.nousresearch.com/docs/guides/python-library`

采用：程序化调用真实 Agent、固定源码环境、独立实例与受控工具接入。当前指南明确未提供受支持的普通 wheel/sdist 安装路径，因此 Windows 打包和版本锁是实际成本。

边界：文档提供嵌入能力，不证明在场已集成、满足所有隐私要求或更擅长理解用户。本设计的 adapter/RPC 不是上游现成协议。

### R2｜Hermes Hooks

`https://hermes-agent.nousresearch.com/docs/user-guide/features/hooks`

采用：区分 hook 的真实触发点；pre_llm_call 的回合级触发不能替代覆盖所有内部模型请求的出口检查。

边界：不同 hook 能力不同，不能笼统断言都只能观察或都可阻断。最终以固定版本的实际路径测试为准。

### R3｜DeepSeek Thinking Mode

`https://api-docs.deepseek.com/guides/thinking_mode/`

采用：显式记录实际模式，工具链遵循当前会话字段要求。文档说明带tools时需回传此前各轮 reasoning_content；这与个人记忆不同。

边界：第三方兼容端点和不同接口版本需实测，不能凭接口名称保证兼容。打开thinking不等于任务必然正确；权限缩小时旧链也不能无条件沿用。

### R4｜LLMs Get Lost In Multi-Turn Conversation

`https://arxiv.org/abs/2505.06120`

2025论文。采用：其模拟多轮实验观察到早期假设、过早形成方案和后续恢复不可靠，支持显式区分暂定理解与共同确认、加强纠错测试。

边界：不是本产品或当前所有 DeepSeek 版本的性能结论，不把论文平均降幅直接当本产品损失率。

### R5｜Microsoft Guidelines for Human-AI Interaction

`https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/`

`https://www.microsoft.com/en-us/research/articles/guidelines-for-human-ai-interaction-eighteen-best-practices-for-human-centered-ai-design/`

CHI 2019及作者解读。采用：能力预期、适时参与、易于纠正/取消、谨慎适应与用户控制是独立交互要求。因此本产品要测修复和负担，而不是只测措辞。

边界：这些是跨产品设计指引，不提供一个自动共情模型，不证明某种架构已满足用户体验。

### R6｜Human-AI Collaboration Enables More Empathic Conversations

`https://arxiv.org/abs/2203.15144`

`https://www.nature.com/articles/s42256-022-00593-2`

阅读范围：已读取 arXiv 摘要；Nature 页面本轮访问失败，列出发表页面便于定位，不声称已读其全文。采用：将具体回应与人类评价结合，提醒不能把共情缩成情感分类或固定安慰句。

边界：研究的是 AI 辅助人类同伴支持者的交流，不是独立生活助手的疗效或情感能力证明；本轮不把相关效果数字迁移到在场。

### R7｜LongMemEval-V2

`https://arxiv.org/abs/2605.12493`

2026研究。采用：将环境、操作经验和工作流程相关记忆纳入评价，支持区分个人偏好与领域/工具经验。

边界：不是单纯的个人画像问答扩容，也不意味着装上某种记忆系统就能学会办事。操作经验在本设计中不能变成授权或自动安装的高权限方法。

### R8｜MCP Tools 规范（固定阅读版本）

`https://modelcontextprotocol.io/specification/2025-11-25/server/tools`

采用：标准化工具列举、调用、结果与注解，为可替换连接器提供协议基础。

边界：固定该阅读版本不宣称它是所有部署的最新版本。MCP 不自动提供用户理解、任务完成、业务授权或事实正确性，不能把 annotations 当授权裁决。

### R9｜Agent Skills 官方说明

`https://agentskills.io/home`

采用：按需加载方法、说明和资源，帮助模型掌握某类工作，而不是把全部细节常驻系统提示。

边界：Skill 不是人格模式，更不是提升权限的指令。实际加载须经过来源、版本、许可和资源访问约束。

### R10｜Anthropic: Writing effective tools for AI agents

`https://www.anthropic.com/engineering/writing-tools-for-agents`

采用：按模型实际任务设计工具、返回可理解而高价值的上下文、通过真实任务试验改善描述与粒度。

边界：不照搬工具数量、名称或某模型表现；是否利于 DeepSeek 需实测。本文建议的工具组合不能隐含用户未授权的副作用。

### R11｜tau2-Bench: Dual-Control Environment

`https://arxiv.org/abs/2506.07982`

采用：用户和 Agent 都可改变环境，单测助手动作不足。因此增加用户自行修改、另一设备更新与合作确认等场景。

边界：采用测试问题结构，不照搬其业务规则，也不把该基准成绩当在场的成功率。

### R12｜Anthropic: Demystifying evals for AI agents

`https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents`

采用：轨迹与环境终态分离，多次尝试，以及代码、模型、人类各自判分。假完成需要从真实状态抓出，不能只读回复。

边界：本包40故事、重复次数和发布门槛是项目建议，不是该文规定，也不是本轮通过记录。

### R13｜Anthropic: Building effective agents

`https://www.anthropic.com/engineering/building-effective-agents`

采用：区分预定义工作流与模型动态决定步骤，尽量使用简单可组合机制；不为每条消息安排固定多代理委员会。

边界：不能推导“所有确定性流程都坏”。授权、事务、领域计算与故障恢复仍需要精确控制。

### R14｜Anthropic: Effective context engineering

`https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents`

采用：上下文应有用且可恢复，按需读取而非无边界拼接；过度硬编码与过度空泛都可能失败。

边界：当前具体的情境预取策略是本设计推断，须通过消融验证，不声称文章给出了在场的现成配方。

### R15｜OpenAI: Codex Agent Loop 与 Harness

`https://openai.com/index/unrolling-the-codex-agent-loop/`

`https://openai.com/index/unlocking-the-codex-harness/`

采用：模型—工具—观察循环，以及引擎与客户端通过事件/会话协议分离的公开机制。

边界：用于解释复用运行时与保留产品界面的合理性；不是要求把在场整个改成 Codex，也不声称知道未公开内部实现。

## C. 本轮的关键决策及其反对理由

| 决策 | 为什么这样选 | 反对理由与退出条件 |
|---|---|---|
| 保留 Hermes 默认底座 | 已有设计已完成方向选择，避免反复换框架 | 必需隔离不可实现或适配长成重写循环时重新决策 |
| 原话直达主 Agent | 减少早期标签锁死解释 | 不能因此跳过来源和存储边界 |
| 按需共同理解与请求对象 | 改善多轮恢复和漏办 | 若每句话建表、界面工单化，删掉不必要流程 |
| 允许有限情境预取 | 主模型未必知道遗漏什么 | 预取越权、污染或无收益时缩减；不能取消原文回读 |
| 情绪影响参与，不决定人格 | 尊重混合需要与当前变化 | 不得把“不诊断”变成不愿理解当下处境 |
| 分级自动处理 | 避免越权与无尽确认两端 | 委托有歧义或后果变大时具体确认 |
| 按风险收尾检查 | 降低漏办、虚报和早停 | 不得变成每轮全量复审和无限续跑 |
| 操作经验独立于画像 | 学到工具/领域的真实条件 | 来源污染、版本变更时失效；经验不签发权限 |
| 多维状态与反事实测试 | 检查改变时应变、不该变时不变 | 测试句不得泄漏成生产硬编码 |

## D. 本轮实际完成与未完成

已完成：读取上传讨论与研究包的架构、证据边界和相关文档；核查一手资料；形成架构审查、详细设计、完整 Codex 实施任务书与40个开发验收故事；制作可交接文本文件。

未执行：当前应用源码验收、旧探针复跑、Hermes安装运行、真实DeepSeek API、真实日历/校园/设备连接、独立保留集评测、真实用户体验研究。本轮任务本来是架构与提示词设计，不能把文本交付等同这些实测已经发生。

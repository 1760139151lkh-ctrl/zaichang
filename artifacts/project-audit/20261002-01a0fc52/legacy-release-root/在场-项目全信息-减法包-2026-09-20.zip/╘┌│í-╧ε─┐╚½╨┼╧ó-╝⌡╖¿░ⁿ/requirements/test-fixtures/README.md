# 历史验收夹具

这里保留仍被测试代码读取的高信息密度输入：94 条 Harness 场景与追踪表，以及 32 条人本协作轨迹及其一致性依据。它们来自旧设计包，但已脱离旧提示包目录；其中的状态和断言是回归输入，不是当前产品现状的最高依据。

当前产品事实以包根目录的 `CURRENT-STATE.md`、`CAPABILITY-STATUS.md`、`ARCHITECTURE.md` 和 `requirements/ARCHITECTURE-SPEC.md` 为准。
